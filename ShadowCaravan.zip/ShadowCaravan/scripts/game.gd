extends Node3D
## SHADOW CARAVAN - gameplay scene controller.
## Builds the world, spawns the player / camera / UI, and owns the game rules that tie them together:
## interaction dispatch, the quest chain (Elder -> 3 fragments -> gate -> boss -> relic), the rune puzzle
## door, chests, waystones / fast travel, discovery, death & respawn, autosave and graphics quality.

const WorldBuilder := preload("res://scripts/world/world_builder.gd")
const Areas := preload("res://scripts/world/world_areas.gd")
const Terrain := preload("res://scripts/world/terrain.gd")
const Items := preload("res://scripts/data/items.gd")
const Fx := preload("res://scripts/world/fx.gd")
const Mats := preload("res://scripts/world/mats.gd")
const Pal := preload("res://scripts/data/pal.gd")
const PlayerScript := preload("res://scripts/world/player.gd")
const CameraRig := preload("res://scripts/world/camera_rig.gd")
const UILayer := preload("res://scripts/ui/ui_layer.gd")
const EnemyScript := preload("res://scripts/world/enemy.gd")

const AUTOSAVE_MIN_GAP := 3.0

var refs: Dictionary = {}
var player: PlayerScript
var cam_rig: CameraRig
var ui: UILayer
var boss: Node3D = null

var _spawn_log: Array = []      # {kind, pos, node}
var _disc_t := 0.0
var _save_cd := 0.0
var _save_pending := false
var _ready_done := false
var _temple_queue := false
var _well_cd := 0.0
var _boss_fight := false
var _leaving := false


# ================================================================= setup
func _ready() -> void:
	if not GameState.session_active:
		GameState.new_game()  # running the scene directly (development / tests)
	Fx.particle_scale = [0.4, 0.7, 1.0][clampi(GameState.quality, 0, 2)]
	refs = WorldBuilder.build(self)
	boss = refs.boss
	for i in range(refs.enemies.size()):
		var e: Node3D = refs.enemies[i]
		_spawn_log.append({"kind": e.kind, "pos": e.home, "node": e})
	_build_player()
	ui = UILayer.new()
	add_child(ui)
	ui.setup(self)
	ui.puzzle_solved.connect(_on_puzzle_solved)
	ui.end_choice.connect(_on_end_choice)
	_connect_world()
	apply_quality()
	_refresh_world(false)
	_place_player()
	AudioMgr.play_music("music_world", 2.0)
	AudioMgr.set_ambience(true)
	_ready_done = true
	if GameState.last_load_message != "":
		var msg := GameState.last_load_message
		GameState.last_load_message = ""
		get_tree().create_timer(1.2).timeout.connect(func(): GameState.toast.emit(msg, "warn"))
	elif GameState.quest_stage == 0 and not GameState.has_position:
		get_tree().create_timer(1.5).timeout.connect(func():
			GameState.toast.emit("Left stick: move. Drag the right side: look. Speak with Elder Sahir by the fire.", "info"))


func _build_player() -> void:
	player = PlayerScript.new()
	add_child(player)
	cam_rig = CameraRig.new()
	add_child(cam_rig)
	cam_rig.target = player
	player.cam = cam_rig
	player.died.connect(_on_player_died)
	player.damaged.connect(func(a: float): ui.hud.flash_damage(clampf(a / 30.0, 0.35, 1.0)))
	player.prompt_changed.connect(func(t: String): ui.set_prompt(t))
	Fx.ambient_dust(player)


func _connect_world() -> void:
	for n in get_tree().get_nodes_in_group("interactables"):
		n.activated.connect(_on_interact)
	if boss != null:
		boss.awakened.connect(_on_boss_awake)
		boss.reset_done.connect(_on_boss_reset)
		boss.died.connect(_on_boss_died)
	GameState.location_discovered.connect(_on_discovered)
	GameState.quest_changed.connect(_on_quest_changed)
	GameState.level_up.connect(_on_level_up)
	GameState.settings_changed.connect(apply_quality)


func _exit_tree() -> void:
	for pair in [[GameState.location_discovered, _on_discovered], [GameState.quest_changed, _on_quest_changed],
			[GameState.level_up, _on_level_up], [GameState.settings_changed, apply_quality]]:
		var sig: Signal = pair[0]
		if sig.is_connected(pair[1]):
			sig.disconnect(pair[1])
	GameState.player_ref = null


func _place_player() -> void:
	var pos := Vector3.ZERO
	var yaw := 0.0
	if GameState.has_position:
		pos = GameState.player_pos
		yaw = GameState.player_yaw
		if pos.z < -53.0 and not GameState.gate_open:
			pos = Vector3.ZERO  # saved inside the sealed region: fall back to the checkpoint
	if pos == Vector3.ZERO:
		var cp: String = GameState.checkpoint_id if Items.LOCATIONS.has(GameState.checkpoint_id) else "camp"
		var sp: Vector2 = Items.LOCATIONS[cp].spawn
		pos = Vector3(sp.x, 0.0, sp.y)
		yaw = 0.0
	pos.y = maxf(pos.y, Terrain.height_at(pos.x, pos.z)) + 0.3
	player.respawn(pos, yaw)
	cam_rig.yaw = yaw
	cam_rig.pitch = -0.3
	cam_rig.snap_to_target()


func apply_quality() -> void:
	var q := clampi(GameState.quality, 0, 2)
	var vp := get_viewport()
	vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_DISABLED, Viewport.MSAA_2X][q]
	vp.scaling_3d_scale = [0.7, 0.85, 1.0][q]
	var sun: DirectionalLight3D = refs.sun
	sun.shadow_enabled = q > 0
	sun.directional_shadow_max_distance = [40.0, 60.0, 90.0][q]
	var env: Environment = refs.env
	env.glow_enabled = q == 2
	env.fog_density = [0.0045, 0.004, 0.0036][q]
	Fx.particle_scale = [0.4, 0.7, 1.0][q]
	for l in get_tree().get_nodes_in_group("opt_lights"):
		l.visible = q > 0
	if cam_rig != null and cam_rig.cam != null:
		cam_rig.cam.far = [420.0, 600.0, 700.0][q]


# ================================================================= per-frame
func _process(delta: float) -> void:
	if player == null:
		return
	ui.set_cooldowns(player.cooldown_fraction("attack"), player.cooldown_fraction("dodge"))
	_well_cd = maxf(0.0, _well_cd - delta)
	_save_cd = maxf(0.0, _save_cd - delta)
	_disc_t -= delta
	if _disc_t <= 0.0:
		_disc_t = 0.5
		_check_discovery()
		_cull_enemies()
		_update_pillars()
	if _temple_queue and not ui.is_modal_open():
		_temple_queue = false
		_open_temple(true)
	if _save_pending and _save_cd <= 0.0 and not player.is_dead() and _ready_done:
		_save_now()


func _check_discovery() -> void:
	var pp := player.global_position
	for id in Items.LOCATIONS:
		if GameState.is_discovered(String(id)):
			continue
		var info: Dictionary = Items.LOCATIONS[id]
		var lp: Vector2 = info.pos
		if Vector2(pp.x, pp.z).distance_to(lp) < float(info.radius):
			GameState.discover(String(id))


func _cull_enemies() -> void:
	var pp := player.global_position
	for e in get_tree().get_nodes_in_group("enemies"):
		var far: bool = e.global_position.distance_to(pp) > 85.0
		var idle: bool = e.state == e.S.IDLE or e.state == e.S.DORMANT
		e.process_mode = Node.PROCESS_MODE_DISABLED if (far and idle) else Node.PROCESS_MODE_INHERIT


func _update_pillars() -> void:
	if refs.puzzle.has("pillars"):
		Areas.update_pillars(refs, GameState.puzzle_dials, GameState.puzzle_solved)


# ================================================================= HUD helpers (called by the UI)
func boss_info() -> Dictionary:
	if boss != null and is_instance_valid(boss):
		var i: Dictionary = boss.info()
		return {"active": bool(i.active), "name": String(i.name), "frac": float(i.hp) / maxf(1.0, float(i.max)), "phase": int(i.phase)}
	return {"active": false}


func _objective_vec() -> Variant:
	if player == null:
		return null
	var pp := player.global_position
	var best: Variant = null
	var best_d := INF
	for t in GameState.objective_targets(pp):
		var d := Vector2(t.x - pp.x, t.z - pp.z).length()
		if d < best_d:
			best_d = d
			best = t
	return best


func objective_distance() -> float:
	var t: Variant = _objective_vec()
	if t == null:
		return -1.0
	var pp := player.global_position
	return Vector2(t.x - pp.x, t.z - pp.z).length()


func objective_bearing() -> float:
	var t: Variant = _objective_vec()
	if t == null:
		return -999.0
	var pp := player.global_position
	return fposmod(rad_to_deg(atan2(t.x - pp.x, -(t.z - pp.z))), 360.0)


func camera_bearing() -> float:
	return cam_rig.bearing_deg() if cam_rig != null else 0.0


func can_pause() -> bool:
	return player != null and not player.is_dead() and not Router.busy


func is_at_camp() -> bool:
	if player == null:
		return false
	var c: Vector2 = Items.LOCATIONS.camp.pos
	return Vector2(player.global_position.x, player.global_position.z).distance_to(c) < 20.0


func can_fast_travel() -> bool:
	if player == null or player.is_dead() or Router.busy:
		return false
	if boss_info().active:
		return false
	for e in get_tree().get_nodes_in_group("enemies"):
		if e.state != e.S.IDLE and e.state != e.S.DORMANT and e.state != e.S.RETREAT \
				and e.global_position.distance_to(player.global_position) < 30.0:
			return false
	return true


# ================================================================= interaction
func _on_interact(n: Node3D) -> void:
	if player == null or player.is_dead():
		return
	match String(n.kind):
		"npc":
			_talk_elder()
		"camp":
			ui.open_camp(String(n.id))
		"chest":
			_open_chest(String(n.id))
		"waystone":
			_touch_waystone(String(n.id))
		"tablet":
			_read_tablet()
		"puzzle":
			ui.open_panel("puzzle")
		"fragment":
			_take_fragment(String(n.id))
		"gate":
			_use_gate()
		"relic":
			_claim_relic()
		"moonwell":
			_drink_moonwell()


func _talk_elder() -> void:
	var pages: Array = []
	var label := "Farewell"
	var on_done := func(): pass
	match GameState.quest_stage:
		0:
			pages = [
				"Drifter. You walk like someone who has already decided to go. Good. Sit - the fire is warm and the night is long.",
				"Twelve nights ago our sister caravan vanished on the old road north of the Ancient Gate. No tracks. No bells. Only a lantern, burning where no one lit it.",
				"The gate is sealed by three fragments of the Sunken Idol.\n\nOne sleeps in a hidden alcove east of the Broken Court, ringed by boulders - follow the glowing cairns round to the opening.\nOne lies behind the sealed door of the Temple of Echoes. The Weeping Stone, near the ruins, remembers the rite that wakes it.\nThe last is held by the wraiths of Wraith Hollow, on the raised ground to the west.",
				"Trust your blade, trust your roll - it will turn a claw aside - and come back to rest at my fire whenever you must. The desert is patient. So am I.",
			]
			label = "Accept the quest"
			on_done = func():
				GameState.accept_quest()
				request_save()
		1:
			var lines: Array[String] = []
			if not GameState.opened_ids.has("frag_alcove"):
				lines.append("The alcove: a ring of boulders east of the Broken Court. The way in is on its far side - follow the glowing cairns.")
			if not GameState.opened_ids.has("frag_temple"):
				lines.append("The temple: touch the three rune pillars and turn them in the order the Weeping Stone gives. Then attune them.")
			if not GameState.opened_ids.has("frag_wraith"):
				lines.append("Wraith Hollow: the wraiths keep their distance and throw cold fire. Close in fast, or break their line of sight behind the columns.")
			pages = ["You carry %d of the %d fragments." % [GameState.fragments_found, Items.FRAGMENTS_REQUIRED], "\n\n".join(lines)]
		2:
			pages = ["All three fragments. The idol remembers you.", "The Ancient Gate stands at the end of the northern road. Press the fragments into its sockets and it will open."]
		3:
			pages = ["Beyond the gate waits the Hollow Warden, the caravan's oldest guardian, now hollow.", "Watch its feet: every blow shows a red warning on the sand first. Roll through the charge, jump the slam - and if it crashes into a wall, strike while it is dazed."]
		4:
			pages = ["The Warden is dust. The relic waits on its altar, beyond the wrecked wagons. Go and claim it."]
		_:
			pages = ["Do you hear the bells? Far to the north - the lanterns of the caravan.", "Rest, drifter. You have earned it. The desert will still be here tomorrow."]
	ui.show_dialogue("Elder Sahir", pages, label, on_done, true)


func _open_chest(id: String) -> void:
	if GameState.opened_ids.has(id) or not Items.CHESTS.has(id):
		return
	GameState.opened_ids.append(id)
	var info: Dictionary = Items.CHESTS[id]
	_set_chest_open(id, true)
	AudioMgr.play("chest")
	var c: Dictionary = refs.chests[id]
	var pos: Vector3 = c.root.global_position + Vector3(0, 1.0, 0)
	Fx.burst(self, pos, Color(1.0, 0.85, 0.4, 0.9), 16, 3.5, 0.6, 0.12)
	GameState.add_coins(int(info.coins))
	var its: Dictionary = info.items
	for k in its:
		GameState.add_item(String(k), int(its[k]))
	request_save()


func _set_chest_open(id: String, animate: bool) -> void:
	var c: Dictionary = refs.chests[id]
	var lid: Node3D = c.lid
	var node: Node3D = c.node
	node.enabled = false
	var target := deg_to_rad(110.0)
	if animate:
		var tw := lid.create_tween()
		tw.tween_property(lid, "rotation:x", target, 0.45).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	else:
		lid.rotation.x = target


func _touch_waystone(id: String) -> void:
	GameState.discover(id)
	if GameState.checkpoint_id != id:
		GameState.checkpoint_id = id
		GameState.toast.emit("Checkpoint set: %s" % Items.LOCATIONS[id].name, "quest")
		var w: Dictionary = refs.waystones[id]
		Fx.burst(self, w.root.global_position + Vector3(0, 3.0, 0), Color(0.3, 1.0, 0.95, 0.9), 22, 4.0, 0.9, 0.14, 1.0)
		AudioMgr.play("relic", -6.0)
	GameState.save_game()
	ui.open_map_travel()


func _read_tablet() -> void:
	var first := not GameState.clue_found
	GameState.clue_found = true
	if first:
		GameState.toast.emit("Journal updated: the Weeping Stone's riddle", "quest")
		GameState.quest_changed.emit()
		request_save()
	ui.show_dialogue("The Weeping Stone", [
		"A tablet weeping fine sand from its cracks. The carving is a rhyme, older than the road:",
		Items.PUZZLE_CLUE,
		"Three pillars. Three runes - the Night, the Watcher and the Sun. Name them in the order the stone speaks them, left to right, and the temple will answer.",
	], "Close", func(): pass, true)


func _take_fragment(id: String) -> void:
	if GameState.opened_ids.has(id):
		return
	if id == "frag_temple" and not GameState.puzzle_solved:
		return
	var f: Dictionary = refs.fragments[id]
	GameState.collect_fragment(id)
	AudioMgr.play("relic")
	Fx.burst(self, f.root.global_position, Color(0.4, 1.0, 0.95, 0.9), 26, 4.5, 0.9, 0.14, 1.0)
	_refresh_world(false)
	request_save()


func _use_gate() -> void:
	if GameState.gate_open:
		return
	var have := GameState.count("relic_fragment")
	if have < Items.FRAGMENTS_REQUIRED:
		GameState.toast.emit("The gate has three empty sockets. Relic Fragments: %d / %d." % [have, Items.FRAGMENTS_REQUIRED], "warn")
		AudioMgr.play("puzzle_fail", -4.0)
		return
	if GameState.open_gate():
		_set_gate_open(true)
		request_save()


func _set_gate_open(animate: bool) -> void:
	var g: Dictionary = refs.gate
	if bool(g.open):
		return
	g.open = true
	var node: Node3D = g.node
	node.enabled = false
	var door: StaticBody3D = g.door
	var y0 := float(g.door_y)
	var lit := Mats.glow(Pal.TURQUOISE, 4.0)
	if not animate:
		for s in g.sockets:
			s.material_override = lit
		door.position.y = y0 - 13.5
		door.collision_layer = 0
		return
	player.frozen = true
	var tw := create_tween()
	for k in 3:
		var sock: MeshInstance3D = g.sockets[k]
		tw.tween_callback(func():
			sock.material_override = lit
			AudioMgr.play("pickup", -2.0, 0.8 + 0.2 * float(k))
			Fx.burst(self, sock.global_position + Vector3(0, 0, 1.0), Color(0.4, 1.0, 0.95, 0.9), 14, 3.0, 0.7, 0.12, 1.0))
		tw.tween_interval(0.55)
	tw.tween_callback(func():
		AudioMgr.play("gate_rumble", 2.0)
		player.frozen = false)
	var sink := create_tween()
	sink.tween_interval(1.8)
	sink.tween_property(door, "position:y", y0 - 13.5, 5.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	sink.tween_callback(func(): door.collision_layer = 0)
	var shake := create_tween()
	shake.tween_interval(1.8)
	for i in 11:
		shake.tween_callback(func(): cam_rig.add_shake(0.22))
		shake.tween_interval(0.5)


func _on_puzzle_solved() -> void:
	GameState.toast.emit("The temple's inner door grinds open.", "quest")
	_temple_queue = true
	request_save()


func _open_temple(animate: bool) -> void:
	var p: Dictionary = refs.puzzle
	if bool(p.open):
		return
	p.open = true
	var door: StaticBody3D = p.door
	var y0 := float(p.door_y)
	Areas.update_pillars(refs, GameState.puzzle_dials, true)
	if not animate:
		door.position.y = y0 - 8.0
		door.collision_layer = 0
		return
	AudioMgr.play("gate_rumble", 0.0)
	cam_rig.add_shake(0.4)
	var tw := create_tween()
	tw.tween_property(door, "position:y", y0 - 8.0, 3.2).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_callback(func(): door.collision_layer = 0)
	_refresh_world(false)


func _claim_relic() -> void:
	if GameState.quest_stage != 4 or GameState.quest_completed:
		return
	GameState.complete_quest()
	AudioMgr.play("relic", 2.0)
	var r: Dictionary = refs.relic
	Fx.burst(self, r.root.global_position, Color(1.0, 0.9, 0.5, 1.0), 40, 6.0, 1.2, 0.16, 0.5)
	_refresh_world(false)
	GameState.save_game()
	ui.show_end("quest")


func _drink_moonwell() -> void:
	if _well_cd > 0.0:
		GameState.toast.emit("The water is still. Return in a little while.", "info")
		return
	_well_cd = 60.0
	GameState.hp = GameState.max_hp()
	GameState.stamina = GameState.max_stamina()
	GameState.stats_changed.emit()
	GameState.toast.emit("The cold water restores you.", "item")
	AudioMgr.play("heal")
	Fx.burst(self, player.global_position + Vector3(0, 1.0, 0), Color(0.5, 1.0, 1.0, 0.9), 20, 3.0, 0.9, 0.12, -1.0)


# ================================================================= camp
func rest_at_camp() -> void:
	GameState.hp = GameState.max_hp()
	GameState.stamina = GameState.max_stamina()
	if GameState.camp_level >= 3:
		GameState.add_item("healing_draught", 1)
	GameState.checkpoint_id = "camp"
	GameState.stats_changed.emit()
	AudioMgr.play("rest")
	_respawn_enemies()
	GameState.save_game()


## Enemies that were defeated return after a rest, unless the player is standing next to their spot.
func _respawn_enemies() -> void:
	for entry in _spawn_log:
		var n: Variant = entry.node
		var gone: bool = (not is_instance_valid(n)) or n.is_dead()
		if not gone:
			continue
		var p: Vector3 = entry.pos
		if p.distance_to(player.global_position) < 35.0:
			continue
		entry.node = EnemyScript.spawn(self, String(entry.kind), p)


# ================================================================= world state
func _refresh_world(animate: bool) -> void:
	for id in refs.chests:
		if GameState.opened_ids.has(id):
			_set_chest_open(String(id), false)
	for id in refs.fragments:
		var f: Dictionary = refs.fragments[id]
		var got := GameState.opened_ids.has(id)
		f.root.visible = not got
		var node: Node3D = f.node
		node.enabled = (not got) and (id != "frag_temple" or GameState.puzzle_solved)
	if GameState.gate_open and not bool(refs.gate.open):
		_set_gate_open(false)
	var have := GameState.count("relic_fragment")
	var gnode: Node3D = refs.gate.node
	gnode.prompt = "Place the Relic Fragments in the gate" if have >= Items.FRAGMENTS_REQUIRED else "Inspect the Ancient Gate (%d/%d fragments)" % [have, Items.FRAGMENTS_REQUIRED]
	if GameState.puzzle_solved and not bool(refs.puzzle.open):
		_open_temple(false)
	var show_relic := GameState.quest_stage == 4 and not GameState.quest_completed
	var r: Dictionary = refs.relic
	r.root.visible = show_relic
	var rn: Node3D = r.node
	rn.enabled = show_relic
	_update_pillars()
	if animate:
		pass


# ================================================================= events
func _on_quest_changed() -> void:
	if _ready_done:
		_refresh_world(false)
		request_save()


func _on_discovered(_id: String) -> void:
	if _ready_done:
		request_save()


func _on_level_up(_lv: int) -> void:
	AudioMgr.play("level_up")
	if player != null:
		Fx.burst(self, player.global_position + Vector3(0, 1.0, 0), Color(1.0, 0.9, 0.5, 0.9), 30, 5.0, 1.0, 0.14, -1.0)


func _on_boss_awake() -> void:
	_boss_fight = true
	AudioMgr.play_music("music_boss", 1.0)


func _on_boss_reset() -> void:
	_boss_fight = false
	AudioMgr.play_music("music_world", 2.0)


func _on_boss_died(_e: Node3D) -> void:
	_boss_fight = false
	AudioMgr.play_music("music_world", 3.0)
	GameState.on_boss_defeated()
	_refresh_world(false)
	GameState.save_game()


func _on_player_died() -> void:
	_boss_fight = false
	await get_tree().create_timer(1.8).timeout
	if not is_inside_tree() or _leaving:
		return
	ui.show_end("defeat")


func _on_end_choice(id: String) -> void:
	match id:
		"retry":
			ui.close_all()
			_respawn_at_checkpoint()
		"menu":
			quit_to_menu()
		"victory":
			ui.show_end("victory")
		"explore":
			ui.close_all()
			request_save()


# ================================================================= travel / respawn / scene control
func _teleport_to(spawn: Vector2, yaw: float = 0.0) -> void:
	var pos := Areas.gp(spawn.x, spawn.y, 0.3)
	player.respawn(pos, yaw)
	cam_rig.yaw = yaw
	cam_rig.pitch = -0.3
	cam_rig.snap_to_target()


func _respawn_at_checkpoint() -> void:
	var cp: String = GameState.checkpoint_id if Items.LOCATIONS.has(GameState.checkpoint_id) else "camp"
	var sp: Vector2 = Items.LOCATIONS[cp].spawn
	Router.transition(func():
		GameState.hp = GameState.max_hp()
		GameState.stamina = GameState.max_stamina()
		GameState.stats_changed.emit()
		_teleport_to(sp)
		_save_now(), "You wake at the waystone...")


func travel_to(id: String) -> void:
	if not can_fast_travel() or not Items.LOCATIONS.has(id):
		return
	var loc: Dictionary = Items.LOCATIONS[id]
	if not bool(loc.waystone) or not GameState.is_discovered(id):
		return
	if id == "caravan" and not GameState.gate_open:
		return
	ui.close_all()
	var sp: Vector2 = loc.spawn
	Router.transition(func(): _teleport_to(sp), "Travelling to %s..." % loc.name)


func return_to_camp() -> void:
	if player == null or player.is_dead() or Router.busy:
		return
	ui.close_all()
	var sp: Vector2 = Items.LOCATIONS.camp.spawn
	Router.transition(func(): _teleport_to(sp), "Returning to camp...")


func restart_from_save() -> void:
	if GameState.load_game():
		_leaving = true
		Router.go("res://scenes/game.tscn", "Restoring your last save...")
	else:
		ui.close_all()
		GameState.toast.emit("No save to restore yet. Rest at camp or touch a waystone to save.", "warn")


func quit_to_menu() -> void:
	_leaving = true
	if player != null and not player.is_dead():
		_save_now()
	AudioMgr.stop_music(0.6)
	Router.go("res://scenes/main_menu.tscn")


# ================================================================= saving
func request_save() -> void:
	if _ready_done:
		_save_pending = true


func _save_now() -> void:
	_save_pending = false
	_save_cd = AUTOSAVE_MIN_GAP
	if player == null or player.is_dead():
		return
	GameState.save_game()


func _notification(what: int) -> void:
	match what:
		NOTIFICATION_APPLICATION_PAUSED, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_CLOSE_REQUEST:
			if _ready_done and not _leaving and player != null and not player.is_dead():
				GameState.save_game()
