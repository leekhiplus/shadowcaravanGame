extends CanvasLayer
## Scene transitions with a fade-to-black overlay. Also used for teleports (fast travel, respawn).

const Pal := preload("res://scripts/data/pal.gd")
const UI := preload("res://scripts/ui/ui_kit.gd")

var busy := false
var _rect: ColorRect
var _label: Label


func _ready() -> void:
	layer = 100
	get_tree().root.theme = UI.theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rect = ColorRect.new()
	_rect.color = Pal.OBSIDIAN
	_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rect.modulate.a = 0.0
	add_child(_rect)
	_label = Label.new()
	_label.set_anchors_preset(Control.PRESET_FULL_RECT)
	_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label.add_theme_color_override("font_color", Pal.GOLD_LIGHT)
	_label.add_theme_font_size_override("font_size", 28)
	_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rect.add_child(_label)


func fade_out(time: float = 0.4, text: String = "") -> void:
	_label.text = text
	_rect.mouse_filter = Control.MOUSE_FILTER_STOP
	var tw := create_tween()
	tw.tween_property(_rect, "modulate:a", 1.0, time)
	await tw.finished


func fade_in(time: float = 0.5) -> void:
	var tw := create_tween()
	tw.tween_property(_rect, "modulate:a", 0.0, time)
	await tw.finished
	_label.text = ""
	_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE


## Fade out, switch to another scene file, fade back in.
func go(path: String, text: String = "") -> void:
	if busy:
		return
	busy = true
	await fade_out(0.4, text)
	get_tree().paused = false
	Controls.reset_touch()
	Controls.enabled = true
	var err := get_tree().change_scene_to_file(path)
	if err != OK:
		push_error("Router: could not load %s (error %d)" % [path, err])
	await get_tree().process_frame
	await get_tree().process_frame
	await fade_in(0.5)
	busy = false


## Fade out, run `action` (e.g. teleport the player), fade back in.
func transition(action: Callable, text: String = "") -> void:
	if busy:
		return
	busy = true
	await fade_out(0.35, text)
	action.call()
	await get_tree().create_timer(0.25).timeout
	await fade_in(0.45)
	busy = false
