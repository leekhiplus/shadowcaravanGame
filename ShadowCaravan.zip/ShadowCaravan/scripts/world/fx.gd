extends RefCounted
## Lightweight visual effects: particle bursts, floating damage numbers, telegraph discs, slash arcs,
## ambient dust. Everything uses CPUParticles3D (works on all GLES3 mobile GPUs).

const Mats := preload("res://scripts/world/mats.gd")
const Pal := preload("res://scripts/data/pal.gd")

static var _quad: QuadMesh
static var particle_scale := 1.0  # set from graphics quality


static func _quad_mesh(size: float) -> QuadMesh:
	var q := QuadMesh.new()
	q.size = Vector2(size, size)
	return q


static func burst(parent: Node, pos: Vector3, col: Color, amount: int = 14, speed: float = 4.0, life: float = 0.5, size: float = 0.12, gravity: float = 6.0) -> void:
	var n := maxi(3, int(float(amount) * particle_scale))
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = n
	p.lifetime = life
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 180.0
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, -gravity, 0)
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.2
	p.color = col
	var grad := Gradient.new()
	grad.set_color(0, Color(1, 1, 1, 1))
	grad.set_color(1, Color(1, 1, 1, 0))
	p.color_ramp = grad
	p.mesh = _quad_mesh(size)
	p.material_override = Mats.particle(Color(1, 1, 1, 1))
	parent.add_child(p)
	p.global_position = pos
	p.emitting = true
	var tm := parent.get_tree().create_timer(life + 0.4)
	tm.timeout.connect(func(): if is_instance_valid(p): p.queue_free())


static func floating_text(parent: Node, pos: Vector3, text: String, col: Color = Pal.GOLD_LIGHT, size: int = 56) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = size
	l.pixel_size = 0.0105
	l.modulate = col
	l.outline_size = 14
	l.outline_modulate = Color(0.02, 0.02, 0.05, 0.95)
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.shaded = false
	l.double_sided = true
	parent.add_child(l)
	l.global_position = pos
	var tw := l.create_tween().set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y + 1.3, 0.9).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.9).set_delay(0.35)
	tw.chain().tween_callback(l.queue_free)


## A flat glowing disc on the ground that shows where an attack will land.
static func telegraph_disc(parent: Node, pos: Vector3, radius: float, col: Color = Color(0.9, 0.15, 0.12, 0.35)) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = radius
	c.bottom_radius = radius
	c.height = 0.06
	c.radial_segments = 28
	c.rings = 1
	m.mesh = c
	m.material_override = Mats.unshaded(col)
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(m)
	m.global_position = pos + Vector3(0, 0.08, 0)
	return m


static func slash_arc(radius_in: float = 0.7, radius_out: float = 1.55, arc_deg: float = 130.0, segs: int = 14) -> ArrayMesh:
	var verts := PackedVector3Array()
	var cols := PackedColorArray()
	var idx := PackedInt32Array()
	var a0 := deg_to_rad(-arc_deg * 0.5)
	for i in segs + 1:
		var u := float(i) / float(segs)
		var a := a0 + deg_to_rad(arc_deg) * u
		var dir := Vector3(sin(a), 0.0, -cos(a))
		verts.append(dir * radius_in)
		verts.append(dir * radius_out)
		var al := sin(u * PI)
		cols.append(Color(0.7, 0.95, 1.0, 0.0))
		cols.append(Color(0.75, 1.0, 1.0, al * 0.85))
	for i in segs:
		var b := i * 2
		idx.append_array([b, b + 1, b + 3, b, b + 3, b + 2])
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


static func slash_material() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	return m


## Continuous emitter: embers / glow motes. Returns the node so callers can tune it.
static func emitter(parent: Node, pos: Vector3, col: Color, amount: int, life: float, size: float, velocity: Vector3, spread: float = 20.0, box: Vector3 = Vector3.ZERO, gravity: Vector3 = Vector3.ZERO) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = maxi(2, int(float(amount) * particle_scale))
	p.lifetime = life
	p.preprocess = life
	p.direction = velocity.normalized() if velocity.length() > 0.001 else Vector3.UP
	p.spread = spread
	p.initial_velocity_min = velocity.length() * 0.6
	p.initial_velocity_max = velocity.length()
	p.gravity = gravity
	p.color = col
	if box != Vector3.ZERO:
		p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
		p.emission_box_extents = box
	var grad := Gradient.new()
	grad.set_color(0, Color(1, 1, 1, 0.0))
	grad.add_point(0.15, Color(1, 1, 1, 1.0))
	grad.set_color(grad.get_point_count() - 1, Color(1, 1, 1, 0.0))
	p.color_ramp = grad
	p.mesh = _quad_mesh(size)
	p.material_override = Mats.particle(Color(1, 1, 1, 1))
	p.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(p)
	p.position = pos
	return p


static func ambient_dust(parent: Node) -> CPUParticles3D:
	var p := emitter(parent, Vector3.ZERO, Color(0.95, 0.78, 0.5, 0.28), 90, 6.0, 0.14, Vector3(1.4, 0.15, 0.4), 25.0, Vector3(22, 3.0, 22), Vector3(0.0, 0.02, 0.0))
	p.local_coords = false
	return p
