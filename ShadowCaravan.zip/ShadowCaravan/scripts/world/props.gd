extends RefCounted
## Prop builders. Everything is assembled from primitive meshes with shared materials; solid props get
## simple box / cylinder colliders on physics layer 1 ("world").

const Mats := preload("res://scripts/world/mats.gd")
const Fx := preload("res://scripts/world/fx.gd")
const Pal := preload("res://scripts/data/pal.gd")

static var _rock_meshes: Array = []


static func _place(n: Node3D, parent: Node, pos: Vector3, rot_deg: Vector3) -> void:
	parent.add_child(n)
	n.position = pos
	n.rotation_degrees = rot_deg


static func _mi(mesh: Mesh, mat: Material, parent: Node, pos: Vector3, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	m.mesh = mesh
	m.material_override = mat
	_place(m, parent, pos, rot_deg)
	return m


static func _body(parent: Node, pos: Vector3, rot_deg: Vector3) -> StaticBody3D:
	var b := StaticBody3D.new()
	b.collision_layer = 1
	b.collision_mask = 0
	_place(b, parent, pos, rot_deg)
	return b


static func box(parent: Node, size: Vector3, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO, collide: bool = false) -> Node3D:
	var bm := BoxMesh.new()
	bm.size = size
	if collide:
		var body := _body(parent, pos, rot_deg)
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		body.add_child(cs)
		var m := MeshInstance3D.new()
		m.mesh = bm
		m.material_override = mat
		body.add_child(m)
		return body
	return _mi(bm, mat, parent, pos, rot_deg)


static func cyl(parent: Node, r_top: float, r_bot: float, height: float, pos: Vector3, mat: Material, collide: bool = false, rot_deg: Vector3 = Vector3.ZERO, segs: int = 12) -> Node3D:
	var cm := CylinderMesh.new()
	cm.top_radius = r_top
	cm.bottom_radius = r_bot
	cm.height = height
	cm.radial_segments = segs
	cm.rings = 1
	if collide:
		var body := _body(parent, pos, rot_deg)
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = maxf(r_top, r_bot)
		sh.height = height
		cs.shape = sh
		body.add_child(cs)
		var m := MeshInstance3D.new()
		m.mesh = cm
		m.material_override = mat
		body.add_child(m)
		return body
	return _mi(cm, mat, parent, pos, rot_deg)


static func sphere(parent: Node, r: float, pos: Vector3, mat: Material, scale: Vector3 = Vector3.ONE, segs: int = 12, rings: int = 6) -> MeshInstance3D:
	var sm := SphereMesh.new()
	sm.radius = r
	sm.height = r * 2.0
	sm.radial_segments = segs
	sm.rings = rings
	var m := _mi(sm, mat, parent, pos)
	m.scale = scale
	return m


static func rock_mesh(variant: int) -> ArrayMesh:
	while _rock_meshes.size() <= variant:
		_rock_meshes.append(null)
	if _rock_meshes[variant] != null:
		return _rock_meshes[variant]
	var sph := SphereMesh.new()
	sph.radius = 1.0
	sph.height = 2.0
	sph.radial_segments = 8
	sph.rings = 5
	var arrays := sph.get_mesh_arrays()
	var verts: PackedVector3Array = arrays[Mesh.ARRAY_VERTEX]
	var idxs: PackedInt32Array = arrays[Mesh.ARRAY_INDEX]
	var fv := float(variant)
	for i in verts.size():
		var v := verts[i]
		var k := 1.0 + 0.30 * sin(v.x * 5.0 + fv * 1.3) * cos(v.z * 4.0 + fv * 1.7) + 0.16 * sin(v.y * 6.0 + fv * 2.3)
		verts[i] = Vector3(v.x * k * (1.0 + 0.12 * float(variant % 3)), v.y * k * 0.78, v.z * k)
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for t in range(0, idxs.size(), 3):
		for j in 3:
			st.add_vertex(verts[idxs[t + j]])
	st.generate_normals()
	var mesh := st.commit()
	_rock_meshes[variant] = mesh
	return mesh


static func rock(parent: Node, pos: Vector3, scale: Vector3, variant: int, collide: bool, col: Color = Color(0.42, 0.34, 0.29)) -> Node3D:
	var mat := Mats.solid(col, 1.0)
	var m := MeshInstance3D.new()
	m.mesh = rock_mesh(variant % 5)
	m.material_override = mat
	if collide:
		var body := _body(parent, pos + Vector3(0, scale.y * 0.25, 0), Vector3(0, float(variant) * 47.0, 0))
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = maxf(scale.x, scale.z) * 0.85
		sh.height = scale.y * 1.5
		cs.shape = sh
		body.add_child(cs)
		m.scale = scale
		m.position = Vector3(0, -scale.y * 0.25, 0)
		body.add_child(m)
		return body
	m.scale = scale
	_place(m, parent, pos, Vector3(0, float(variant) * 47.0, 0))
	return m


static func column(parent: Node, pos: Vector3, height: float, r: float, broken: bool, mat: Material = null) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3.ZERO)
	var mt: Material = mat if mat != null else Mats.sandstone()
	var h := height * (0.45 if broken else 1.0)
	box(root, Vector3(r * 2.5, 0.3, r * 2.5), Vector3(0, 0.15, 0), Mats.sandstone_dark())
	var shaft := cyl(root, r * 0.9, r, h, Vector3(0, 0.3 + h * 0.5, 0), mt, true, Vector3.ZERO, 10)
	if not broken:
		box(root, Vector3(r * 2.7, 0.35, r * 2.7), Vector3(0, 0.3 + h + 0.17, 0), Mats.sandstone_dark())
	else:
		box(root, Vector3(r * 1.5, h * 0.25, r * 1.1), Vector3(0, 0.3 + h + 0.05, 0), mt, Vector3(14, 20, 8))
		# fallen drum lying next to the stump
		cyl(root, r * 0.9, r * 0.9, height * 0.4, Vector3(r * 2.2, r * 0.9, r * 0.8), mt, true, Vector3(0, 30, 90), 10)
	return root if shaft != null else root


static func wall(parent: Node, a: Vector3, b: Vector3, height: float, thick: float, mat: Material = null) -> Node3D:
	var d := b - a
	var len := d.length()
	var mid := (a + b) * 0.5
	var yaw := rad_to_deg(atan2(d.x, d.z))
	var mt: Material = mat if mat != null else Mats.sandstone_dark()
	return box(parent, Vector3(thick, height, len), mid + Vector3(0, height * 0.5, 0), mt, Vector3(0, yaw, 0), true)


static func crate(parent: Node, pos: Vector3, size: Vector3, yaw_deg: float = 0.0) -> Node3D:
	var root := box(parent, size, pos + Vector3(0, size.y * 0.5, 0), Mats.wood(), Vector3(0, yaw_deg, 0), true)
	box(root, Vector3(size.x * 1.02, 0.07, size.z * 1.02), Vector3(0, size.y * 0.3, 0), Mats.solid(Color(0.2, 0.13, 0.08), 1.0))
	return root


static func barrel(parent: Node, pos: Vector3) -> Node3D:
	var b := cyl(parent, 0.4, 0.42, 0.9, pos + Vector3(0, 0.45, 0), Mats.wood(), true, Vector3.ZERO, 10)
	cyl(b, 0.43, 0.43, 0.06, Vector3(0, 0.2, 0), Mats.solid(Color(0.25, 0.25, 0.28), 0.6, 0.6), false, Vector3.ZERO, 10)
	cyl(b, 0.43, 0.43, 0.06, Vector3(0, -0.2, 0), Mats.solid(Color(0.25, 0.25, 0.28), 0.6, 0.6), false, Vector3.ZERO, 10)
	return b


static func tent(parent: Node, pos: Vector3, yaw_deg: float) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(0, yaw_deg, 0))
	var pm := PrismMesh.new()
	pm.size = Vector3(3.4, 2.4, 4.0)
	_mi(pm, Mats.cloth(Color(0.58, 0.33, 0.2)), root, Vector3(0, 1.2, 0))
	var pm2 := PrismMesh.new()
	pm2.size = Vector3(3.5, 0.5, 4.1)
	_mi(pm2, Mats.cloth(Color(0.82, 0.68, 0.45)), root, Vector3(0, 2.1, 0))
	# dark entrance on the +X facing side (door faces the fire)
	box(root, Vector3(0.05, 1.5, 1.0), Vector3(0.0, 0.8, -2.02), Mats.solid(Color(0.05, 0.04, 0.04), 1.0))
	for sx in [-1.0, 1.0]:
		cyl(root, 0.05, 0.05, 2.9, Vector3(1.7 * sx, 1.1, -2.05), Mats.wood(), false, Vector3(0, 0, 14.0 * -sx), 6)
	# collision: a simple box
	var body := _body(root, Vector3(0, 1.1, 0), Vector3.ZERO)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(3.2, 2.2, 3.9)
	cs.shape = bs
	body.add_child(cs)
	return root


static func chest(parent: Node, pos: Vector3, yaw_deg: float = 0.0) -> Dictionary:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(0, yaw_deg, 0))
	var gold := Mats.solid(Color(0.76, 0.6, 0.22), 0.4, 0.7)
	box(root, Vector3(1.0, 0.5, 0.62), Vector3(0, 0.25, 0), Mats.wood(), Vector3.ZERO, true)
	box(root, Vector3(1.04, 0.1, 0.66), Vector3(0, 0.05, 0), gold)
	box(root, Vector3(0.1, 0.52, 0.66), Vector3(-0.35, 0.25, 0), gold)
	box(root, Vector3(0.1, 0.52, 0.66), Vector3(0.35, 0.25, 0), gold)
	var hinge := Node3D.new()
	root.add_child(hinge)
	hinge.position = Vector3(0, 0.5, 0.31)
	box(hinge, Vector3(1.0, 0.2, 0.62), Vector3(0, 0.1, -0.31), Mats.wood())
	box(hinge, Vector3(0.1, 0.22, 0.66), Vector3(-0.35, 0.1, -0.31), gold)
	box(hinge, Vector3(0.1, 0.22, 0.66), Vector3(0.35, 0.1, -0.31), gold)
	box(hinge, Vector3(0.14, 0.16, 0.05), Vector3(0, 0.0, -0.64), gold)
	return {"root": root, "lid": hinge}


static func campfire(parent: Node, pos: Vector3) -> Dictionary:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3.ZERO)
	for i in 3:
		cyl(root, 0.09, 0.09, 1.1, Vector3(0, 0.14, 0), Mats.solid(Color(0.16, 0.1, 0.06), 1.0), false, Vector3(78, i * 60.0, 0), 6)
	for i in 8:
		var a := TAU * float(i) / 8.0
		rock(root, Vector3(cos(a) * 0.95, 0.0, sin(a) * 0.95), Vector3(0.22, 0.2, 0.22), i, false, Color(0.32, 0.28, 0.26))
	# a collider so you cannot walk through the flames
	var body := _body(root, Vector3(0, 0.4, 0), Vector3.ZERO)
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 1.0
	sh.height = 0.8
	cs.shape = sh
	body.add_child(cs)
	Fx.emitter(root, Vector3(0, 0.3, 0), Color(1.0, 0.55, 0.15, 0.9), 26, 0.9, 0.55, Vector3(0, 1.3, 0), 10.0, Vector3(0.15, 0, 0.15))
	Fx.emitter(root, Vector3(0, 0.5, 0), Color(1.0, 0.85, 0.4, 0.9), 12, 1.4, 0.07, Vector3(0, 2.0, 0), 25.0, Vector3(0.1, 0, 0.1), Vector3(0, -0.6, 0))
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.6, 0.28)
	light.light_energy = 2.4
	light.omni_range = 16.0
	light.omni_attenuation = 1.3
	root.add_child(light)
	light.position = Vector3(0, 1.4, 0)
	return {"root": root, "light": light}


static func brazier(parent: Node, pos: Vector3, col: Color = Color(0.25, 0.9, 0.85), light: bool = true) -> Dictionary:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3.ZERO)
	cyl(root, 0.12, 0.2, 0.9, Vector3(0, 0.45, 0), Mats.black_stone(), true, Vector3.ZERO, 8)
	cyl(root, 0.42, 0.25, 0.3, Vector3(0, 1.0, 0), Mats.black_stone(), false, Vector3.ZERO, 10)
	Fx.emitter(root, Vector3(0, 1.15, 0), Color(col.r, col.g, col.b, 0.85), 14, 0.9, 0.4, Vector3(0, 1.0, 0), 12.0, Vector3(0.12, 0, 0.12))
	var l: OmniLight3D = null
	if light:
		l = OmniLight3D.new()
		l.light_color = col
		l.light_energy = 1.4
		l.omni_range = 10.0
		root.add_child(l)
		l.position = Vector3(0, 1.6, 0)
	return {"root": root, "light": l}


static func anvil(parent: Node, pos: Vector3, yaw_deg: float) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(0, yaw_deg, 0))
	var iron := Mats.solid(Color(0.2, 0.21, 0.24), 0.45, 0.8)
	box(root, Vector3(0.9, 0.5, 0.6), Vector3(0, 0.25, 0), Mats.wood(), Vector3.ZERO, true)
	box(root, Vector3(0.5, 0.3, 0.3), Vector3(0, 0.65, 0), iron)
	box(root, Vector3(1.1, 0.22, 0.4), Vector3(0, 0.9, 0), iron)
	cyl(root, 0.0, 0.17, 0.5, Vector3(0.78, 0.9, 0), iron, false, Vector3(0, 0, -90), 8)
	# forge: glowing coals
	box(root, Vector3(0.9, 0.4, 0.7), Vector3(-1.4, 0.2, 0), Mats.black_stone(), Vector3.ZERO, true)
	box(root, Vector3(0.7, 0.06, 0.5), Vector3(-1.4, 0.42, 0), Mats.glow(Color(1.0, 0.4, 0.1), 3.0))
	Fx.emitter(root, Vector3(-1.4, 0.5, 0), Color(1.0, 0.6, 0.2, 0.9), 8, 1.0, 0.06, Vector3(0, 1.0, 0), 20.0, Vector3(0.25, 0, 0.18))
	return root


static func waystone(parent: Node, pos: Vector3) -> Dictionary:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3.ZERO)
	cyl(root, 1.5, 1.7, 0.25, Vector3(0, 0.12, 0), Mats.black_stone(), false, Vector3.ZERO, 16)
	cyl(root, 1.1, 1.2, 0.12, Vector3(0, 0.3, 0), Mats.glow(Color(0.2, 0.75, 0.72), 0.8), false, Vector3.ZERO, 16)
	box(root, Vector3(0.9, 2.6, 0.55), Vector3(0, 1.55, 0), Mats.black_stone(), Vector3.ZERO, true)
	var rune := Mats.glow(Pal.TURQUOISE, 2.5)
	box(root, Vector3(0.08, 0.9, 0.04), Vector3(0, 1.5, -0.29), rune)
	box(root, Vector3(0.5, 0.08, 0.04), Vector3(0, 1.9, -0.29), rune)
	box(root, Vector3(0.5, 0.08, 0.04), Vector3(0, 1.2, -0.29), rune)
	var crystal := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.3
	sm.height = 0.9
	sm.radial_segments = 4
	sm.rings = 2
	crystal.mesh = sm
	crystal.material_override = Mats.glow(Pal.TURQUOISE, 3.0)
	root.add_child(crystal)
	crystal.position = Vector3(0, 3.3, 0)
	var tw := crystal.create_tween().set_loops()
	tw.tween_property(crystal, "position:y", 3.5, 1.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(crystal, "position:y", 3.25, 1.4).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var spin := crystal.create_tween().set_loops()
	spin.tween_property(crystal, "rotation:y", TAU, 6.0).from(0.0)
	Fx.emitter(root, Vector3(0, 0.4, 0), Color(0.3, 0.95, 0.9, 0.7), 10, 2.2, 0.08, Vector3(0, 0.9, 0), 30.0, Vector3(1.0, 0, 1.0))
	return {"root": root, "crystal": crystal}


static func tablet(parent: Node, pos: Vector3, yaw_deg: float) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(0, yaw_deg, 0))
	box(root, Vector3(1.8, 0.4, 1.0), Vector3(0, 0.2, 0), Mats.sandstone_dark(), Vector3.ZERO, true)
	box(root, Vector3(1.3, 2.9, 0.4), Vector3(0, 1.85, 0), Mats.sandstone(), Vector3(0, 0, 2), true)
	var g := Mats.glow(Pal.TURQUOISE, 1.8)
	for i in 5:
		box(root, Vector3(0.7 - 0.08 * float(i % 3), 0.07, 0.03), Vector3(0, 1.0 + float(i) * 0.38, -0.21), g)
	box(root, Vector3(0.07, 1.6, 0.03), Vector3(-0.38, 1.9, -0.21), g)
	box(root, Vector3(0.07, 1.6, 0.03), Vector3(0.38, 1.9, -0.21), g)
	Fx.emitter(root, Vector3(0.0, 2.9, -0.25), Color(0.55, 0.9, 1.0, 0.85), 5, 1.4, 0.08, Vector3(0, -0.2, 0), 5.0, Vector3(0.45, 0, 0.0), Vector3(0, -2.4, 0))
	return root


static func pedestal(parent: Node, pos: Vector3, height: float = 1.0) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3.ZERO)
	cyl(root, 0.7, 0.85, 0.25, Vector3(0, 0.12, 0), Mats.sandstone_dark(), false, Vector3.ZERO, 10)
	cyl(root, 0.45, 0.55, height, Vector3(0, 0.25 + height * 0.5, 0), Mats.sandstone(), true, Vector3.ZERO, 10)
	cyl(root, 0.62, 0.5, 0.18, Vector3(0, 0.25 + height + 0.09, 0), Mats.sandstone_dark(), false, Vector3.ZERO, 10)
	return root


static func wagon(parent: Node, pos: Vector3, yaw_deg: float, tilt: float = 0.0) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(tilt, yaw_deg, tilt * 0.6))
	box(root, Vector3(3.0, 0.5, 1.4), Vector3(0, 0.85, 0), Mats.wood(), Vector3.ZERO, true)
	box(root, Vector3(3.0, 0.5, 0.1), Vector3(0, 1.3, 0.7), Mats.wood())
	box(root, Vector3(3.0, 0.5, 0.1), Vector3(0, 1.3, -0.7), Mats.wood())
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			cyl(root, 0.55, 0.55, 0.1, Vector3(1.0 * sx, 0.55, 0.78 * sz), Mats.wood(), false, Vector3(90, 0, 0), 12)
	for i in 4:
		cyl(root, 0.04, 0.04, 1.6, Vector3(-1.2 + 0.8 * float(i), 2.0, 0), Mats.wood(), false, Vector3(90, 0, 0), 5)
	box(root, Vector3(1.4, 0.04, 1.3), Vector3(0.9, 2.05, 0.0), Mats.cloth(Color(0.55, 0.5, 0.4)), Vector3(0, 0, -12))
	return root


static func dead_tree(parent: Node, pos: Vector3, h: float, seed_v: int) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(0, float(seed_v) * 53.0, 0))
	var bark := Mats.solid(Color(0.22, 0.16, 0.12), 1.0)
	cyl(root, 0.1, 0.22, h, Vector3(0, h * 0.5, 0), bark, false, Vector3(0, 0, float(seed_v % 5) - 2.0), 6)
	for i in 4:
		var a := float(i) * 90.0 + float(seed_v) * 31.0
		var bl := h * 0.45
		var br := cyl(root, 0.03, 0.08, bl, Vector3(0, h * (0.55 + 0.1 * float(i)), 0), bark, false, Vector3(0, a, 55.0), 5)
		br.position += Vector3(sin(deg_to_rad(a)), 0, cos(deg_to_rad(a))) * 0.2
	return root


static func bones(parent: Node, pos: Vector3, seed_v: int) -> void:
	var m := Mats.solid(Color(0.86, 0.82, 0.72), 1.0)
	for i in 5:
		var a := float(i) * 71.0 + float(seed_v) * 13.0
		box(parent, Vector3(0.7, 0.07, 0.07), pos + Vector3(sin(a) * 0.5, 0.05, cos(a) * 0.5), m, Vector3(0, a, 5.0))
	sphere(parent, 0.18, pos + Vector3(0.3, 0.12, 0.2), m, Vector3(1, 0.9, 1.1), 8, 4)


static func banner(parent: Node, pos: Vector3, col: Color, h: float = 3.0, yaw_deg: float = 0.0) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(0, yaw_deg, 0))
	cyl(root, 0.05, 0.06, h, Vector3(0, h * 0.5, 0), Mats.wood(), false, Vector3.ZERO, 6)
	cyl(root, 0.04, 0.04, 1.1, Vector3(0.0, h - 0.1, 0), Mats.wood(), false, Vector3(0, 0, 90), 5)
	var cloth_m := Mats.cloth(col)
	var q := box(root, Vector3(0.95, 1.8, 0.03), Vector3(0, h - 1.05, 0), cloth_m, Vector3(0, 0, 3))
	box(q, Vector3(0.3, 0.5, 0.032), Vector3(0.3, -0.75, 0), Mats.solid(Color(0.03, 0.03, 0.04), 1.0), Vector3(0, 0, 25))
	return root


static func moonwell(parent: Node, pos: Vector3) -> Dictionary:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3.ZERO)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 1.5
	tm.outer_radius = 2.2
	tm.rings = 18
	tm.ring_segments = 8
	ring.mesh = tm
	ring.material_override = Mats.sandstone()
	root.add_child(ring)
	ring.position = Vector3(0, 0.3, 0)
	ring.scale = Vector3(1, 0.7, 1)
	var body := _body(root, Vector3(0, 0.4, 0), Vector3.ZERO)
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 2.2
	sh.height = 0.8
	cs.shape = sh
	body.add_child(cs)
	cyl(root, 1.65, 1.65, 0.05, Vector3(0, 0.38, 0), Mats.unshaded(Color(0.55, 0.95, 0.95, 0.85), true), false, Vector3.ZERO, 20)
	Fx.emitter(root, Vector3(0, 0.5, 0), Color(0.6, 1.0, 1.0, 0.8), 14, 2.4, 0.09, Vector3(0, 0.8, 0), 20.0, Vector3(1.2, 0, 1.2))
	var l := OmniLight3D.new()
	l.light_color = Color(0.5, 0.95, 0.95)
	l.light_energy = 1.2
	l.omni_range = 10.0
	root.add_child(l)
	l.position = Vector3(0, 1.2, 0)
	return {"root": root, "light": l}


static func colossus(parent: Node, pos: Vector3) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, pos, Vector3(0, 25, 0))
	var st := Mats.sandstone()
	var dk := Mats.sandstone_dark()
	box(root, Vector3(4.2, 2.6, 2.8), Vector3(0, 1.1, 0), st, Vector3(0, 0, 10), true)          # torso
	box(root, Vector3(4.6, 0.5, 3.2), Vector3(0, 2.5, 0), dk, Vector3(0, 0, 10))                    # collar
	var head := sphere(root, 1.5, Vector3(-5.2, 1.1, 0.4), st, Vector3(1, 1.05, 1), 12, 8)
	box(head, Vector3(2.2, 0.55, 2.2), Vector3(0, 1.3, 0), Mats.solid(Color(0.74, 0.6, 0.25), 0.5, 0.6), Vector3(0, 0, 0))  # crown
	box(head, Vector3(0.9, 0.3, 0.4), Vector3(0.5, 0.2, -1.4), dk)                                  # brow
	var body2 := _body(root, Vector3(-5.2, 1.0, 0.4), Vector3.ZERO)
	var cs := CollisionShape3D.new()
	var sh := SphereShape3D.new()
	sh.radius = 1.4
	cs.shape = sh
	body2.add_child(cs)
	cyl(root, 0.7, 0.8, 4.2, Vector3(3.5, 0.9, 2.6), st, true, Vector3(0, 0, 84), 10)              # arm
	cyl(root, 0.9, 1.0, 4.8, Vector3(5.8, 0.8, -1.6), st, true, Vector3(2, 0, 82), 10)             # leg
	box(root, Vector3(0.5, 1.4, 0.3), Vector3(0.6, 1.9, -1.45), dk, Vector3(0, 0, 35))             # crack
	return root


static func city_silhouette(parent: Node, center: Vector3, width: float, seed_v: int) -> Node3D:
	var root := Node3D.new()
	_place(root, parent, center, Vector3.ZERO)
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_v
	var body := Mats.unshaded(Color(0.07, 0.08, 0.16, 1.0), false, false)
	var x := -width * 0.5
	while x < width * 0.5:
		var w := rng.randf_range(6.0, 16.0)
		var h := rng.randf_range(14.0, 46.0)
		var kind := rng.randi_range(0, 4)
		match kind:
			1:
				box(root, Vector3(w, h * 0.6, w), Vector3(x, h * 0.3, 0), body)
				var dome := sphere(root, w * 0.55, Vector3(x, h * 0.6, 0), body, Vector3(1, 0.9, 1), 12, 6)
				cyl(root, 0.0, 0.25, w * 0.5, Vector3(x, h * 0.6 + w * 0.7, 0), body, false, Vector3.ZERO, 4)
				if dome == null:
					pass
			2:
				cyl(root, w * 0.18, w * 0.22, h * 1.6, Vector3(x, h * 0.8, 0), body, false, Vector3.ZERO, 8)
				cyl(root, 0.0, w * 0.3, w * 0.9, Vector3(x, h * 1.6 + w * 0.4, 0), body, false, Vector3.ZERO, 8)
			3:
				box(root, Vector3(w, h * 0.5, w), Vector3(x, h * 0.25, 0), body)
				box(root, Vector3(w * 0.7, h * 0.3, w * 0.7), Vector3(x, h * 0.65, 0), body)
				box(root, Vector3(w * 0.4, h * 0.2, w * 0.4), Vector3(x, h * 0.9, 0), body)
			_:
				box(root, Vector3(w, h, w), Vector3(x, h * 0.5, 0), body)
		if rng.randf() > 0.55:
			box(root, Vector3(0.7, 0.9, 0.2), Vector3(x + rng.randf_range(-w * 0.3, w * 0.3), rng.randf_range(4.0, h * 0.6), -w * 0.5 - 0.1), Mats.glow(Color(1.0, 0.7, 0.3), 2.0))
		x += w * rng.randf_range(0.8, 1.25)
	return root
