extends RefCounted
## Builds every landmark of the desert level: camp, ruins, Weeping Stone, hidden alcove, Temple of Echoes
## (rune pillars + sliding door), Wraith Hollow, Ancient Gate, the Lost Caravan arena, plus chests,
## waystones, decorations and the enemy / boss placements.
## Returns a `refs` dictionary the game script uses to drive world state (doors, chests, fragments, ...).

const Mats := preload("res://scripts/world/mats.gd")
const Props := preload("res://scripts/world/props.gd")
const Fx := preload("res://scripts/world/fx.gd")
const Terrain := preload("res://scripts/world/terrain.gd")
const Items := preload("res://scripts/data/items.gd")
const Pal := preload("res://scripts/data/pal.gd")
const Interactable := preload("res://scripts/world/interactable.gd")
const Npc := preload("res://scripts/world/npc.gd")
const EnemyScript := preload("res://scripts/world/enemy.gd")
const BossScript := preload("res://scripts/world/boss.gd")

const RUNE_LABELS := ["SUN", "MOON", "EYE", "SERPENT"]
const RUNE_COLORS := [Color(1.0, 0.78, 0.25), Color(0.72, 0.82, 1.0), Color(0.25, 0.9, 0.85), Color(0.45, 0.95, 0.4)]

const WAYSTONE_POS := {
	"camp": Vector2(-60, 67), "ruins": Vector2(-6, 33), "temple": Vector2(36, -2),
	"gate": Vector2(-7, -48), "caravan": Vector2(-9, -63),
}

const TEMPLE := Vector2(52, -12)
const BOSS_HOME := Vector2(0, -78)

# kind, x, z
const SPAWNS := [
	["scarab", -10, 13], ["scarab", 3, 15], ["scarab", -13, 31], ["scarab", 5, 29],
	["scarab", 14, 12], ["scarab", 27, 0],
	["scarab", 46, -3], ["scarab", 61, -21], ["wraith", 50, -23],
	["wraith", -56, -21], ["wraith", -47, -30], ["wraith", -53, -34], ["scarab", -44, -14], ["scarab", -61, -14],
	["scarab", -27, -34], ["scarab", -35, -50],
	["scarab", -10, -38], ["scarab", 10, -36],
	["scarab", -77, 15], ["scarab", -90, 29],
	["scarab", 19, 52], ["wraith", 41, 49],
]


# ------------------------------------------------------------------ helpers
static func gp(x: float, z: float, dy: float = 0.0) -> Vector3:
	return Vector3(x, Terrain.height_at(x, z) + dy, z)


static func yaw_to(from: Vector3, to: Vector3) -> float:
	return rad_to_deg(atan2(-(to.x - from.x), -(to.z - from.z)))


static func itx(parent: Node, kind: String, id: String, pos: Vector3, prompt: String, radius: float = 2.8) -> Node3D:
	var n: Node3D = Interactable.new()
	n.kind = kind
	n.id = id
	n.prompt = prompt
	n.radius = radius
	parent.add_child(n)
	n.position = pos
	return n


static func fragment(parent: Node, id: String, pos: Vector3, refs: Dictionary) -> void:
	var root := Node3D.new()
	parent.add_child(root)
	root.position = pos
	var crystal := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.28
	sm.height = 0.95
	sm.radial_segments = 4
	sm.rings = 2
	crystal.mesh = sm
	crystal.material_override = Mats.glow(Pal.TURQUOISE, 3.5)
	crystal.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(crystal)
	var tw := crystal.create_tween().set_loops()
	tw.tween_property(crystal, "position:y", 0.22, 1.3).from(0.0).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	tw.tween_property(crystal, "position:y", 0.0, 1.3).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var spin := crystal.create_tween().set_loops()
	spin.tween_property(crystal, "rotation:y", TAU, 5.0).from(0.0)
	Fx.emitter(root, Vector3(0, 0.1, 0), Color(0.4, 1.0, 0.95, 0.8), 10, 1.8, 0.07, Vector3(0, 0.7, 0), 40.0, Vector3(0.25, 0.1, 0.25))
	var node := itx(parent, "fragment", id, pos, "Take the Relic Fragment", 2.5)
	refs.fragments[id] = {"root": root, "node": node}


static func cairn(parent: Node, pos: Vector3) -> void:
	var st := Mats.solid(Color(0.45, 0.4, 0.36), 1.0)
	Props.sphere(parent, 0.34, pos + Vector3(0, 0.2, 0), st, Vector3(1.2, 0.7, 1.1), 7, 4)
	Props.sphere(parent, 0.24, pos + Vector3(0.02, 0.52, 0), st, Vector3(1.1, 0.7, 1.0), 7, 4)
	Props.sphere(parent, 0.15, pos + Vector3(0, 0.78, 0.02), Mats.glow(Pal.TURQUOISE, 2.5), Vector3.ONE, 6, 4)


static func build_all(w: Node3D) -> Dictionary:
	var refs := {"chests": {}, "fragments": {}, "waystones": {}, "enemies": [], "boss": null,
		"gate": {}, "puzzle": {}, "relic": {}, "elder": null, "moonwell": null, "campfire_light": null}
	_camp(w, refs)
	_ruins(w, refs)
	_tablet(w, refs)
	_alcove(w, refs)
	_temple(w, refs)
	_wraith_hollow(w, refs)
	_gate(w, refs)
	_caravan(w, refs)
	_misc(w, refs)
	_chests(w, refs)
	_waystones(w, refs)
	_enemies(w, refs)
	return refs


# ------------------------------------------------------------------ camp
static func _camp(w: Node3D, refs: Dictionary) -> void:
	var fire_pos := gp(-62, 55)
	var fire := Props.campfire(w, fire_pos)
	refs.campfire_light = fire.light
	var snd := AudioMgr.make_loop_3d("fire", 16.0, -6.0)
	fire.root.add_child(snd)
	itx(w, "camp", "rest", fire_pos, "Rest at the fire", 3.6)
	for t in [[-70.0, 49.0], [-54.0, 47.0], [-72.0, 61.0]]:
		var tp := gp(t[0], t[1])
		Props.tent(w, tp, yaw_to(tp, fire_pos))
	var anvil_pos := gp(-67.5, 54.5)
	Props.anvil(w, anvil_pos, 90.0)
	itx(w, "camp", "craft", anvil_pos + Vector3(-0.6, 0, 0), "Use the forge and anvil", 3.0)
	# storage
	var sp := gp(-66, 64)
	Props.crate(w, sp, Vector3(1.1, 0.9, 1.1), 10.0)
	Props.crate(w, sp + Vector3(1.3, 0, 0.3), Vector3(0.9, 0.7, 0.9), -20.0)
	Props.crate(w, sp + Vector3(0.2, 0.9, 0.1), Vector3(0.7, 0.6, 0.7), 35.0)
	Props.barrel(w, sp + Vector3(-1.4, 0, 0.6))
	itx(w, "camp", "storage", sp + Vector3(0.6, 0, 1.6), "Open the supply crates", 3.0)
	# upgrade shrine
	var up := gp(-55, 62)
	Props.pedestal(w, up, 1.2)
	var sigil := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.3
	sm.height = 0.9
	sm.radial_segments = 4
	sm.rings = 2
	sigil.mesh = sm
	sigil.material_override = Mats.glow(Pal.GOLD_LIGHT, 3.0)
	sigil.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	w.add_child(sigil)
	sigil.position = up + Vector3(0, 2.2, 0)
	var stw := sigil.create_tween().set_loops()
	stw.tween_property(sigil, "rotation:y", TAU, 5.0).from(0.0)
	Fx.emitter(w, up + Vector3(0, 1.6, 0), Color(1.0, 0.85, 0.4, 0.8), 10, 1.8, 0.07, Vector3(0, 0.8, 0), 30.0, Vector3(0.3, 0.1, 0.3))
	Props.brazier(w, up + Vector3(-2.2, 0, -0.5), Color(1.0, 0.75, 0.3), false)
	Props.brazier(w, up + Vector3(2.2, 0, -0.5), Color(1.0, 0.75, 0.3), false)
	itx(w, "camp", "upgrade", up + Vector3(0, 0, 0.9), "Train at the Wayfarer's Shrine", 3.2)
	# dressing
	Props.wagon(w, gp(-51, 56), 80.0)
	Props.banner(w, gp(-75, 54), Pal.MIDNIGHT_LIGHT, 3.4, 40.0)
	Props.banner(w, gp(-49, 51), Pal.MIDNIGHT_LIGHT, 3.4, -50.0)
	Props.barrel(w, gp(-65, 66.4))
	Props.crate(w, gp(-58, 44), Vector3(1.0, 0.8, 1.0), 15.0)
	for r in [[-76.0, 46.0, 0], [-47.0, 63.0, 1], [-57.0, 41.0, 2], [-78.0, 66.0, 3]]:
		Props.rock(w, gp(r[0], r[1]), Vector3(1.6, 1.2, 1.5), int(r[2]), true)
	# Elder Sahir
	var elder: Node3D = Npc.new()
	w.add_child(elder)
	var ep := gp(-58.8, 57.4)
	elder.position = ep
	elder.setup({"cloak": Color("d9c39a"), "cape": Color("8c7650"), "trim": Color("c9a24b"),
		"scarf": Color("efe6d0"), "skin": Color("8a5a3c"), "sword": false, "staff": true})
	elder.base_yaw = deg_to_rad(yaw_to(ep, fire_pos))
	elder.rotation.y = elder.base_yaw
	var enode := itx(w, "npc", "elder", ep, "Speak with Elder Sahir", 3.4)
	refs.elder = {"npc": elder, "node": enode}


# ------------------------------------------------------------------ ruins (the Broken Court)
static func _ruins(w: Node3D, _refs: Dictionary) -> void:
	var c := Vector3(-4, 0, 22)
	for i in 8:
		var a := TAU * float(i) / 8.0 + 0.2
		var p := gp(c.x + cos(a) * 11.0, c.z + sin(a) * 11.0)
		Props.column(w, p, 6.0 + 1.2 * float(i % 3), 0.7, i % 2 == 1)
	var plat := gp(c.x, c.z)
	Props.box(w, Vector3(7.0, 0.3, 7.0), plat + Vector3(0, 0.15, 0), Mats.sandstone_dark(), Vector3(0, 12, 0), true)
	Props.cyl(w, 0.35, 0.5, 1.3, plat + Vector3(0, 0.95, 0), Mats.sandstone(), true, Vector3.ZERO, 8)
	Props.brazier(w, plat + Vector3(2.4, 0.3, 2.4), Color(0.25, 0.9, 0.85), false)
	Props.brazier(w, plat + Vector3(-2.4, 0.3, -2.4), Color(0.25, 0.9, 0.85), false)
	# broken walls
	Props.wall(w, gp(-17, 12), gp(-12, 10), 2.2, 0.9)
	Props.wall(w, gp(6, 10), gp(11, 13), 1.6, 0.9)
	Props.wall(w, gp(-16, 34), gp(-9, 37), 1.8, 0.9)
	# arch on the north approach
	var l := gp(-8, 3)
	var r := gp(0, 3)
	Props.column(w, l, 7.0, 0.8, false)
	Props.column(w, r, 7.0, 0.8, false)
	Props.box(w, Vector3(9.4, 1.0, 1.8), Vector3(-4, l.y + 7.9, 3), Mats.sandstone_dark(), Vector3.ZERO, false)
	# scarab nests
	for n in [[-10.0, 13.0], [3.0, 15.0], [5.0, 29.0]]:
		var np := gp(n[0], n[1])
		Props.sphere(w, 1.5, np + Vector3(0, 0.2, 0), Mats.solid(Color(0.28, 0.2, 0.15), 1.0), Vector3(1.2, 0.5, 1.2), 8, 4)
		for k in 3:
			var a2 := float(k) * 2.1
			Props.sphere(w, 0.22, np + Vector3(cos(a2) * 0.7, 0.55, sin(a2) * 0.7), Mats.glow(Color(0.5, 0.95, 0.5), 1.4), Vector3(1, 1.3, 1), 6, 4)
	Props.bones(w, gp(-1, 20), 2)
	Props.bones(w, gp(-9, 26), 5)
	Props.dead_tree(w, gp(-18, 24), 4.0, 1)


# ------------------------------------------------------------------ Weeping Stone
static func _tablet(w: Node3D, _refs: Dictionary) -> void:
	var p := gp(24, 38)
	Props.tablet(w, p, 90.0)
	itx(w, "tablet", "tablet", p + Vector3(-1.8, 0, 0), "Read the carved stone", 3.4)
	Props.rock(w, gp(27, 41), Vector3(1.4, 1.1, 1.3), 1, true)
	Props.rock(w, gp(21, 34), Vector3(1.0, 0.8, 1.1), 2, true)
	Props.bones(w, gp(22, 40), 3)


# ------------------------------------------------------------------ hidden alcove
static func _alcove(w: Node3D, refs: Dictionary) -> void:
	var c := Vector2(14, -8)
	var gap_c := deg_to_rad(-135.0)
	for i in 18:
		var a := TAU * float(i) / 18.0 - PI
		var diff := absf(wrapf(a - gap_c, -PI, PI))
		if diff < deg_to_rad(17.0):
			continue
		var p := gp(c.x + cos(a) * 7.0, c.y + sin(a) * 7.0)
		Props.rock(w, p, Vector3(2.2 + 0.4 * float(i % 3), 2.4 + 0.5 * float(i % 2), 2.0), i, true, Color(0.4, 0.33, 0.28))
	# chicane boulder directly in front of the gap
	var cb := gp(c.x + cos(gap_c) * 11.0, c.y + sin(gap_c) * 11.0)
	Props.rock(w, cb, Vector3(2.6, 2.8, 2.4), 7, true, Color(0.38, 0.31, 0.27))
	# trail of glowing cairns from the road round to the gap
	for t in [[22.5, -3.0], [22.0, -11.0], [20.0, -18.5], [13.0, -22.0], [6.0, -19.0]]:
		cairn(w, gp(t[0], t[1]))
	# inside
	var ped := gp(c.x, c.y)
	Props.pedestal(w, ped, 1.0)
	fragment(w, "frag_alcove", ped + Vector3(0, 1.9, 0), refs)
	Props.brazier(w, gp(c.x - 3.2, c.y + 1.5), Pal.TURQUOISE, false)
	Props.brazier(w, gp(c.x + 3.0, c.y + 2.2), Pal.TURQUOISE, false)
	Props.bones(w, gp(c.x + 2.0, c.y - 3.0), 4)


# ------------------------------------------------------------------ Temple of Echoes
static func _temple(w: Node3D, refs: Dictionary) -> void:
	var o := TEMPLE
	var base_y := Terrain.height_at(o.x, o.y)
	var sand := Mats.sandstone()
	var dark := Mats.sandstone_dark()
	# platform and steps (entrance faces west)
	Props.box(w, Vector3(26.0, 1.0, 30.0), Vector3(o.x + 3.0, base_y + 0.5, o.y), dark, Vector3.ZERO, true)
	for j in range(1, 5):  # four 0.2 m risers leading up to the 1.0 m platform
		Props.box(w, Vector3(0.9, 0.2 * float(j), 8.0), Vector3(o.x - 10.0 - 0.9 * float(5 - j) + 0.45, base_y + 0.1 * float(j), o.y), sand, Vector3.ZERO, true)
	# colonnade
	for row: float in [-6.5, 6.5]:
		for k in 4:
			var cx := o.x - 1.0 + float(k) * 4.2
			Props.column(w, Vector3(cx, base_y + 1.0, o.y + row), 7.0, 0.75, k == 3 and row > 0.0)
		Props.box(w, Vector3(13.4, 0.8, 1.6), Vector3(o.x + 5.6, base_y + 8.9, o.y + row), dark, Vector3.ZERO, false)
	# back wall and sanctum
	Props.box(w, Vector3(1.2, 9.0, 18.0), Vector3(o.x + 15.0, base_y + 5.0, o.y), sand, Vector3.ZERO, true)
	for s: float in [-1.0, 1.0]:
		Props.box(w, Vector3(4.2, 8.0, 0.9), Vector3(o.x + 12.9, base_y + 4.5, o.y + 3.0 * s), sand, Vector3.ZERO, true)
	Props.box(w, Vector3(4.6, 0.8, 6.9), Vector3(o.x + 12.9, base_y + 8.9, o.y), dark, Vector3.ZERO, false)
	# sliding door
	var door := Props.box(w, Vector3(0.9, 7.2, 5.1), Vector3(o.x + 10.9, base_y + 4.6, o.y), Mats.black_stone(), Vector3.ZERO, true)
	var rune := Mats.glow(Pal.TURQUOISE, 1.5)
	Props.box(door, Vector3(0.05, 5.0, 0.12), Vector3(-0.47, 0.0, 0.0), rune)
	Props.box(door, Vector3(0.05, 0.12, 3.2), Vector3(-0.47, 1.2, 0.0), rune)
	Props.box(door, Vector3(0.05, 0.12, 2.0), Vector3(-0.47, -1.0, 0.0), rune)
	fragment(w, "frag_temple", Vector3(o.x + 13.3, base_y + 2.2, o.y), refs)
	Props.pedestal(w, Vector3(o.x + 13.3, base_y + 1.0, o.y), 0.9)
	# the three rune pillars
	var pillars: Array = []
	for i in 3:
		var pz := o.y + (float(i) - 1.0) * 6.0
		var pp := Vector3(o.x - 3.2, base_y + 1.0, pz)
		Props.cyl(w, 0.9, 1.05, 0.4, pp + Vector3(0, 0.2, 0), dark, false, Vector3.ZERO, 10)
		Props.cyl(w, 0.7, 0.8, 3.4, pp + Vector3(0, 2.0, 0), Mats.black_stone(), true, Vector3.ZERO, 10)
		var band_mat: StandardMaterial3D = Mats.glow(RUNE_COLORS[0], 2.0).duplicate()
		var band := Props.cyl(w, 0.76, 0.76, 0.22, pp + Vector3(0, 3.5, 0), band_mat, false, Vector3.ZERO, 12)
		band.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		Props.cyl(w, 0.85, 0.7, 0.35, pp + Vector3(0, 4.0, 0), dark, false, Vector3.ZERO, 10)
		var lb := Label3D.new()
		lb.text = RUNE_LABELS[0]
		lb.font_size = 72
		lb.pixel_size = 0.011
		lb.outline_size = 14
		lb.outline_modulate = Color(0.02, 0.02, 0.05, 0.95)
		lb.modulate = RUNE_COLORS[0]
		lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		lb.shaded = false
		w.add_child(lb)
		lb.position = pp + Vector3(0, 5.2, 0)
		pillars.append({"mat": band_mat, "label": lb})
	var pn := itx(w, "puzzle", "runes", Vector3(o.x - 5.0, base_y + 1.0, o.y), "Touch the rune pillars", 7.5)
	refs.puzzle = {"pillars": pillars, "node": pn, "door": door, "door_y": door.position.y, "open": false}
	# braziers and dressing
	Props.brazier(w, Vector3(o.x - 8.5, base_y + 1.0, o.y - 10.0), Pal.TURQUOISE, true)
	Props.brazier(w, Vector3(o.x - 8.5, base_y + 1.0, o.y + 10.0), Pal.TURQUOISE, true)
	for p in [[-6.0, -17.0, 0], [4.0, 18.5, 1], [22.0, -14.0, 2], [24.0, 13.0, 3]]:
		Props.rock(w, Vector3(o.x + p[0], Terrain.height_at(o.x + p[0], o.y + p[1]), o.y + p[1]), Vector3(2.0, 1.6, 1.8), int(p[2]), true)
	Props.banner(w, Vector3(o.x - 10.0, base_y + 1.0, o.y - 4.5), Pal.MIDNIGHT_LIGHT, 4.0, 90.0)
	Props.banner(w, Vector3(o.x - 10.0, base_y + 1.0, o.y + 4.5), Pal.MIDNIGHT_LIGHT, 4.0, 90.0)


## Update the three pillar labels / glow from the dial state.
static func update_pillars(refs: Dictionary, dials: Array, solved: bool) -> void:
	var pil: Array = refs.puzzle.get("pillars", [])
	for i in pil.size():
		var rune := clampi(int(dials[i]), 0, 3)
		var col: Color = RUNE_COLORS[rune]
		var lb: Label3D = pil[i].label
		var mat: StandardMaterial3D = pil[i].mat
		lb.text = RUNE_LABELS[rune]
		lb.modulate = col
		mat.albedo_color = col
		mat.emission = col
		mat.emission_energy_multiplier = 5.0 if solved else 2.0


# ------------------------------------------------------------------ Wraith Hollow
static func _wraith_hollow(w: Node3D, refs: Dictionary) -> void:
	var c := Vector2(-52, -26)
	var ped := gp(c.x, c.y)
	Props.pedestal(w, ped, 1.0)
	fragment(w, "frag_wraith", ped + Vector3(0, 1.9, 0), refs)
	for i in 6:
		var a := TAU * float(i) / 6.0 + 0.3
		var p := gp(c.x + cos(a) * 8.0, c.y + sin(a) * 8.0)
		Props.column(w, p, 5.5, 0.65, i % 3 != 0)
	for i in 4:
		var a2 := TAU * float(i) / 4.0 + 0.8
		Props.brazier(w, gp(c.x + cos(a2) * 4.0, c.y + sin(a2) * 4.0), Color(0.7, 0.35, 1.0), false)
	Props.bones(w, gp(c.x + 3, c.y + 2), 6)
	Props.bones(w, gp(c.x - 4, c.y - 3), 8)
	Props.dead_tree(w, gp(c.x + 12, c.y + 6), 4.5, 3)
	Props.dead_tree(w, gp(c.x - 13, c.y - 4), 3.8, 4)


# ------------------------------------------------------------------ Ancient Gate
static func _gate(w: Node3D, refs: Dictionary) -> void:
	var gy := Terrain.height_at(0, -56)
	var black := Mats.black_stone()
	var gold := Mats.solid(Color(0.76, 0.6, 0.22), 0.4, 0.7)
	for s: float in [-1.0, 1.0]:
		var px := 7.0 * s
		Props.box(w, Vector3(3.4, 14.0, 3.4), Vector3(px, gy + 7.0, -56), black, Vector3.ZERO, true)
		for k in 4:
			Props.box(w, Vector3(3.6, 0.3, 3.6), Vector3(px, gy + 2.0 + float(k) * 3.2, -56), gold)
		var rune := Mats.glow(Pal.TURQUOISE, 2.2)
		Props.box(w, Vector3(0.14, 8.0, 0.1), Vector3(px - 1.74 * s, gy + 7.0, -54.2), rune)
		Props.brazier(w, Vector3(5.2 * s, gy, -50.0), Pal.TURQUOISE, true)
	Props.box(w, Vector3(18.6, 2.4, 3.6), Vector3(0, gy + 13.6, -56), black, Vector3.ZERO, true)
	Props.box(w, Vector3(18.8, 0.3, 3.8), Vector3(0, gy + 12.3, -56), gold)
	# the door (fills the gap between the pylons and sinks into the ground when opened)
	var door := Props.box(w, Vector3(12.8, 12.4, 1.4), Vector3(0, gy + 6.2, -56), black, Vector3.ZERO, true)
	var dim := Mats.solid(Color(0.05, 0.12, 0.13), 0.5, 0.3)
	var sockets: Array = []
	for k in 3:
		var sm := Props.box(door, Vector3(1.2, 1.2, 0.2), Vector3(-2.8 + 2.8 * float(k), 0.6, 0.75), dim)
		sockets.append(sm)
		Props.box(door, Vector3(1.5, 1.5, 0.12), Vector3(-2.8 + 2.8 * float(k), 0.6, 0.68), gold)
	var lines := Mats.glow(Color(0.12, 0.45, 0.43), 1.0)
	Props.box(door, Vector3(0.12, 8.0, 0.1), Vector3(0, 0.6, 0.72), lines)
	Props.box(door, Vector3(9.0, 0.12, 0.1), Vector3(0, 4.2, 0.72), lines)
	Props.box(door, Vector3(9.0, 0.12, 0.1), Vector3(0, -2.6, 0.72), lines)
	var node := itx(w, "gate", "gate", Vector3(0, gy, -52.5), "Approach the Ancient Gate", 5.6)
	refs.gate = {"door": door, "door_y": door.position.y, "sockets": sockets, "node": node, "open": false}
	# the ridge is already a cliff; these invisible blockers make the partition airtight
	for s: float in [-1.0, 1.0]:
		var blk := StaticBody3D.new()
		blk.collision_layer = 1
		blk.collision_mask = 0
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = Vector3(92.0, 40.0, 3.4)
		cs.shape = bs
		blk.add_child(cs)
		w.add_child(blk)
		blk.position = Vector3(8.4 * s + 46.0 * s, 10.0, -56)
	for s: float in [-1.0, 1.0]:
		Props.rock(w, gp(14.0 * s, -46), Vector3(2.4, 2.0, 2.2), 3 + int(s + 1.0), true)
	Props.dead_tree(w, gp(-16, -40), 4.5, 6)
	Props.bones(w, gp(3, -44), 1)


# ------------------------------------------------------------------ Lost Caravan arena
static func _caravan(w: Node3D, refs: Dictionary) -> void:
	for wg in [[-13.0, -70.0, 25.0, 5.0], [11.0, -72.0, -35.0, -4.0], [-7.0, -86.0, 100.0, 3.0], [9.0, -88.0, 160.0, -6.0]]:
		Props.wagon(w, gp(wg[0], wg[1]), wg[2], wg[3])
	for cr in [[-10.0, -66.0], [-15.0, -76.0], [13.0, -77.0], [4.0, -70.0], [-4.0, -90.0]]:
		Props.crate(w, gp(cr[0], cr[1]), Vector3(1.1, 0.9, 1.0), cr[0] * 7.0)
	for bn in [[-16.0, -64.0], [16.0, -64.0], [-14.0, -88.0], [14.0, -86.0]]:
		Props.banner(w, gp(bn[0], bn[1]), Color(0.2, 0.08, 0.1), 3.6, bn[0] * 4.0)
	for i in 6:
		var a := TAU * float(i) / 6.0 + 0.4
		Props.column(w, gp(BOSS_HOME.x + cos(a) * 21.0, BOSS_HOME.y + sin(a) * 15.0), 7.0, 0.8, i % 2 == 0)
	for b in [[-9.0, -66.0], [9.0, -66.0], [-12.0, -84.0], [12.0, -83.0]]:
		Props.brazier(w, gp(b[0], b[1]), Color(1.0, 0.55, 0.2), false)
	Props.bones(w, gp(-2, -74), 9)
	Props.bones(w, gp(6, -80), 10)
	Props.bones(w, gp(-8, -79), 11)
	# relic altar (revealed when the Warden falls)
	var ap := gp(0, -84)
	Props.pedestal(w, ap, 1.2)
	Props.cyl(w, 2.6, 2.8, 0.3, ap + Vector3(0, 0.15, 0), Mats.sandstone_dark(), false, Vector3.ZERO, 16)
	var relic := Node3D.new()
	w.add_child(relic)
	relic.position = ap + Vector3(0, 2.4, 0)
	var body := Props.sphere(relic, 0.4, Vector3.ZERO, Mats.glow(Pal.GOLD_LIGHT, 3.0), Vector3(0.8, 1.3, 0.8), 10, 6)
	body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.6
	tm.outer_radius = 0.7
	tm.rings = 16
	tm.ring_segments = 6
	ring.mesh = tm
	ring.material_override = Mats.glow(Pal.TURQUOISE, 3.0)
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	relic.add_child(ring)
	ring.rotation.x = 1.1
	var rtw := ring.create_tween().set_loops()
	rtw.tween_property(ring, "rotation:y", TAU, 4.0).from(0.0)
	var btw := relic.create_tween().set_loops()
	btw.tween_property(relic, "position:y", ap.y + 2.7, 1.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	btw.tween_property(relic, "position:y", ap.y + 2.3, 1.5).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	Fx.emitter(relic, Vector3.ZERO, Color(1.0, 0.85, 0.4, 0.9), 14, 1.8, 0.09, Vector3(0, 0.8, 0), 60.0, Vector3(0.4, 0.4, 0.4))
	var rn := itx(w, "relic", "relic", ap + Vector3(0, 0, 1.8), "Claim the Ancient Relic", 3.4)
	refs.relic = {"root": relic, "node": rn}
	# the Hollow Warden
	if not GameState.boss_defeated:
		var b: Node3D = BossScript.new()
		b.home = gp(BOSS_HOME.x, BOSS_HOME.y)
		b.position = b.home + Vector3(0, 0.3, 0)
		w.add_child(b)
		refs.boss = b


# ------------------------------------------------------------------ misc landmarks
static func _misc(w: Node3D, refs: Dictionary) -> void:
	# fallen colossus
	Props.colossus(w, gp(-30, -42))
	# moonwell
	var mw := Props.moonwell(w, gp(34, 66))
	var mn := itx(w, "moonwell", "moonwell", gp(34, 66), "Drink from the Moonwell", 4.2)
	refs.moonwell = {"node": mn, "light": mw.light}
	Props.dead_tree(w, gp(40, 70), 4.2, 2)
	Props.rock(w, gp(28, 63), Vector3(1.8, 1.3, 1.6), 4, true)
	# caravan wreck
	Props.wagon(w, gp(-84, 20), 60.0, 6.0)
	Props.wagon(w, gp(-80, 26), -20.0, -8.0)
	Props.wagon(w, gp(-89, 17), 120.0, 12.0)
	Props.crate(w, gp(-82, 21), Vector3(1.0, 0.8, 1.0), 20.0)
	Props.bones(w, gp(-84, 24), 12)
	Props.dead_tree(w, gp(-92, 22), 4.0, 5)


# ------------------------------------------------------------------ chests / waystones / enemies
static func _chests(w: Node3D, refs: Dictionary) -> void:
	var n := 0
	for id in Items.CHESTS:
		var info: Dictionary = Items.CHESTS[id]
		var p: Vector3 = info.pos
		var gpos := gp(p.x, p.z)
		var ch := Props.chest(w, gpos, float(n) * 70.0 + 20.0)
		var node := itx(w, "chest", String(id), gpos, "Open the chest", 2.4)
		refs.chests[id] = {"root": ch.root, "lid": ch.lid, "node": node}
		n += 1


static func _waystones(w: Node3D, refs: Dictionary) -> void:
	for id in WAYSTONE_POS:
		var v: Vector2 = WAYSTONE_POS[id]
		var gpos := gp(v.x, v.y)
		var ws := Props.waystone(w, gpos)
		var node := itx(w, "waystone", String(id), gpos, "Touch the Waystone", 3.0)
		refs.waystones[id] = {"root": ws.root, "crystal": ws.crystal, "node": node}


static func _enemies(w: Node3D, refs: Dictionary) -> void:
	for s in SPAWNS:
		var e: Node3D = EnemyScript.spawn(w, String(s[0]), gp(float(s[1]), float(s[2]), 0.35))
		refs.enemies.append(e)
