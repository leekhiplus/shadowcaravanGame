extends Node3D
## Anything the player can interact with. The game script listens to `activated` and dispatches on `kind`.

signal activated(node: Node3D)

var kind := ""
var id := ""
var prompt := "Interact"
var radius := 2.6
var enabled := true
var data: Dictionary = {}


func _ready() -> void:
	add_to_group("interactables")


func is_available() -> bool:
	return enabled and is_inside_tree() and visible


func activate() -> void:
	activated.emit(self)
