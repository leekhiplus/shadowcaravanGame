extends RefCounted
## Shared, cached materials (keeps draw state low on mobile GPUs).

static var _cache: Dictionary = {}


static func solid(col: Color, rough: float = 0.92, metal: float = 0.0) -> StandardMaterial3D:
	var key := "s%s_%.2f_%.2f" % [col.to_html(), rough, metal]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	m.metallic = metal
	_cache[key] = m
	return m


static func glow(col: Color, energy: float = 2.5) -> StandardMaterial3D:
	var key := "g%s_%.2f" % [col.to_html(), energy]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.emission_enabled = true
	m.emission = col
	m.emission_energy_multiplier = energy
	m.roughness = 0.4
	_cache[key] = m
	return m


static func unshaded(col: Color, additive: bool = false, double_sided: bool = true) -> StandardMaterial3D:
	var key := "u%s_%s_%s" % [col.to_html(true), additive, double_sided]
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if col.a < 0.999 or additive:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	if additive:
		m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	if double_sided:
		m.cull_mode = BaseMaterial3D.CULL_DISABLED
	_cache[key] = m
	return m


static func particle(col: Color) -> StandardMaterial3D:
	var key := "p%s" % col.to_html(true)
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	m.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	m.vertex_color_use_as_albedo = true
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	_cache[key] = m
	return m


static func vertex_colored(rough: float = 1.0) -> StandardMaterial3D:
	var key := "v%.2f" % rough
	if _cache.has(key):
		return _cache[key]
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = rough
	m.metallic_specular = 0.15
	_cache[key] = m
	return m


# Named palette used by props.
static func sandstone() -> StandardMaterial3D:
	return solid(Color(0.66, 0.56, 0.42), 0.95)


static func sandstone_dark() -> StandardMaterial3D:
	return solid(Color(0.48, 0.40, 0.31), 0.95)


static func black_stone() -> StandardMaterial3D:
	return solid(Color(0.13, 0.13, 0.17), 0.8, 0.1)


static func wood() -> StandardMaterial3D:
	return solid(Color(0.34, 0.22, 0.13), 0.95)


static func cloth(col: Color) -> StandardMaterial3D:
	var m := solid(col, 1.0)
	return m
