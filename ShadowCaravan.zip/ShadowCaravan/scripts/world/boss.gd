extends "res://scripts/world/enemy.gd"
## THE HOLLOW WARDEN - boss of the Lost Caravan.
##
## Sleeps (DORMANT) until the player comes close, roars (WAKE), then fights with a telegraphed attack
## pattern. Every attack shows its danger zone first and only hurts inside that zone:
##   swipe  - quick sword sweep in front of it (close range)
##   slam   - shockwave around its feet; jump or roll through it
##   charge - red lane on the ground, then a straight dash; crashing into a wall DAZES it (+30% damage taken)
##   volley - fan of slow orbs (more in phase 2)
##   summon - calls scarabs (once at 70% health, once at 35%)
## Below 50% health it staggers, roars and becomes enraged (phase 2: faster, shorter wind-ups, bigger volleys).
## If the player dies or flees the arena the Warden resets (heals and goes back to sleep).

signal awakened
signal phase_changed(phase: int)
signal reset_done

const ARENA_RADIUS := 18.0
const SLAM_RADIUS := 6.0
const CHARGE_LENGTH := 17.0
const CHARGE_SPEED := 17.0

var _phase := 1
var _rage := 1.0
var _atk := ""
var _last_atk := ""
var _dazed := false
var _summons_done := 0
var _minions: Array = []
var _tele: MeshInstance3D
var _tele_mat: StandardMaterial3D
var _recover_override := -1.0
var _charge_start := Vector3.ZERO
var _wave := 0
var _step_t := 0.0
var _swing := 0
var _core_mat: StandardMaterial3D
var _stagger_len := 0.4
var _crumble_fx := false


func _configure() -> void:
	kind = "boss"
	display_name = "The Hollow Warden"
	max_hp = 380.0
	damage = 24.0
	move_speed = 3.7
	accel = 16.0
	turn_rate = 4.5
	aggro_range = 15.0
	leash_range = 44.0
	attack_trigger = 6.0
	hit_radius = 1.0
	eye_height = 3.0
	bar_height = 5.6
	col_radius = 0.95
	col_height = 3.8
	xp_reward = 0
	ranged = false
	show_world_bar = false


func _build_visual() -> void:
	_body = Node3D.new()
	add_child(_body)
	_rig = Rig.new()
	_body.add_child(_rig)
	_rig.build({"cloak": Color("3a2c14"), "cape": Color("14100a"), "trim": Color("e8c050"),
		"skin": Color("23232b"), "scarf": Color("5a4a22"), "eye": Color("ff6a2a"), "sword": true})
	_body.scale = Vector3.ONE * 2.1
	var gold := Mats.solid(Color(0.8, 0.62, 0.2), 0.4, 0.7)
	var iron := Mats.solid(Color(0.16, 0.15, 0.18), 0.5, 0.6)
	for sx: float in [-1.0, 1.0]:
		Props.cyl(_rig.head, 0.0, 0.05, 0.38, Vector3(0.14 * sx, 0.34, 0.0), gold, false, Vector3(0, 0, -24.0 * sx), 6)
		Props.sphere(_rig.torso, 0.17, Vector3(0.31 * sx, 0.58, 0.0), iron, Vector3(1.3, 0.8, 1.2))
		Props.cyl(_rig.torso, 0.03, 0.06, 0.28, Vector3(0.36 * sx, 0.72, 0.0), gold, false, Vector3(0, 0, -20.0 * sx), 6)
	_core_mat = Mats.glow(Color(1.0, 0.45, 0.15), 2.5).duplicate()
	var core := Props.box(_rig.torso, Vector3(0.13, 0.22, 0.02), Vector3(0, 0.35, -0.145), _core_mat)
	core.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	Fx.emitter(_rig.torso, Vector3(0, 0.4, 0), Color(1.0, 0.55, 0.2, 0.7), 8, 1.4, 0.1, Vector3(0, 0.8, 0), 40.0, Vector3(0.25, 0.1, 0.15))


func _after_ready() -> void:
	_enter(S.DORMANT)
	rotation.y = PI  # facing the gate (+z)


# ================================================================= info for the HUD / game
func info() -> Dictionary:
	var active := state != S.DORMANT and state != S.DEAD
	return {"active": active, "name": display_name, "hp": hp, "max": max_hp, "phase": _phase}


func _facing() -> Vector3:
	return Vector3(-sin(rotation.y), 0.0, -cos(rotation.y))


func _shake_cam(amount: float) -> void:
	var pl: Node = GameState.player_ref
	if pl == null or not is_instance_valid(pl):
		return
	if pl.global_position.distance_to(global_position) > 32.0:
		return
	var c: Variant = pl.get("cam")
	if c != null and is_instance_valid(c) and c.has_method("add_shake"):
		c.add_shake(amount)


# ================================================================= AI
func _ai(delta: float, p: Node3D) -> void:
	match state:
		S.DORMANT:
			_b_dormant(delta, p)
		S.WAKE:
			_b_wake(delta, p)
		S.CHASE:
			_b_chase(delta, p)
		S.WINDUP:
			_b_windup(delta, p)
		S.ATTACK:
			_b_attack(delta, p)
		S.RECOVER:
			_b_recover(delta, p)
		S.HURT:
			_b_stagger(delta)
		S.RETREAT:
			_b_reset(delta)


func _b_dormant(delta: float, p: Node3D) -> void:
	_stop(delta)
	if p != null and _dist < aggro_range and (_los or _dist < 10.0):
		_wake_up()


func _wake_up() -> void:
	if state != S.DORMANT:
		return
	_enter(S.WAKE)
	AudioMgr.play("boss_roar", 2.0)
	awakened.emit()
	GameState.toast.emit("The Hollow Warden awakens!", "warn")


func _b_wake(delta: float, p: Node3D) -> void:
	_stop(delta)
	if p != null:
		_face(_dir_to, delta, 3.0)
	if state_t > 0.9 and state_t - delta <= 0.9:
		_shake_cam(0.6)
		_shockwave(global_position, 7.0, Color(1.0, 0.6, 0.2, 0.6))
	if state_t >= 2.2:
		_cd = 0.5
		_enter(S.CHASE)


func _alive_minions() -> int:
	var n := 0
	for m in _minions:
		if is_instance_valid(m) and not m.is_dead():
			n += 1
	return n


func _pick_attack() -> String:
	if _summons_done < 1 and hp <= max_hp * 0.7 and _alive_minions() < 2:
		return "summon"
	if _summons_done < 2 and hp <= max_hp * 0.35 and _alive_minions() < 2:
		return "summon"
	var opts: Array = []
	if _dist < 4.8:
		opts = ["swipe", "swipe", "slam", "slam"]
		if _phase >= 2:
			opts.append("volley")
	elif _dist < 8.0:
		opts = ["slam", "slam", "charge", "volley"]
	elif _dist < 14.0:
		opts = ["charge", "volley", "", ""]  # "" = keep closing in before attacking
	else:
		opts = ["charge", "", ""]
	if opts.size() > 1 and opts.has(_last_atk):
		var again: Array = []
		for o in opts:
			if o != _last_atk:
				again.append(o)
		if not again.is_empty():
			opts = again
	return String(opts[randi() % opts.size()])


func _b_chase(delta: float, p: Node3D) -> void:
	if p == null or p.global_position.distance_to(home) > leash_range:
		_enter(S.RETREAT)
		return
	_walk(_dir_to, move_speed * _rage, delta)
	if _cd <= 0.0:
		var a := _pick_attack()
		if a == "":
			_cd = 0.8  # walk closer first
		else:
			_begin_attack(a)


func _begin_attack(a: String) -> void:
	_atk = a
	_last_atk = a
	_recover_override = -1.0
	var r := 1.0 + 0.25 * float(_phase - 1)
	match a:
		"slam":
			windup_time = 0.95 / r
			attack_time = 0.4
			recover_time = 1.1
			damage = 26.0
		"swipe":
			windup_time = 0.6 / r
			attack_time = 0.3
			recover_time = 0.7
			damage = 20.0
		"charge":
			windup_time = 0.95 / r
			attack_time = 1.15
			recover_time = 1.0
			damage = 24.0
		"volley":
			windup_time = 0.75 / r
			attack_time = 0.6 if _phase == 1 else 1.0
			recover_time = 0.8
			damage = 13.0
		"summon":
			windup_time = 1.2
			attack_time = 0.25
			recover_time = 0.9
	_wave = 0
	_swing = 1 - _swing
	_rig.swing_variant = 1 if a == "swipe" and _swing == 1 else 0
	_enter(S.WINDUP)
	match a:
		"slam":
			_make_disc(global_position, SLAM_RADIUS)
		"charge":
			_make_lane()
		"summon":
			AudioMgr.play("boss_roar", 0.0)


func _b_windup(delta: float, p: Node3D) -> void:
	_stop(delta)
	var u := clampf(state_t / windup_time, 0.0, 1.0)
	if _tele_mat != null:
		_tele_mat.albedo_color.a = 0.18 + 0.42 * u
	match _atk:
		"charge":
			if u < 0.6 and p != null:
				_face(_dir_to, delta, 6.0)
			_place_lane()
		"slam":
			if _tele != null:
				_tele.global_position = Vector3(global_position.x, _ground_y() + 0.08, global_position.z)
			if p != null and u < 0.5:
				_face(_dir_to, delta, 4.0)
		_:
			if p != null and u < 0.7:
				_face(_dir_to, delta, 7.0)
	if p == null:
		_clear_telegraph()
		_enter(S.RETREAT)
		return
	if state_t >= windup_time:
		_lock_dir = _facing()
		_charge_start = global_position
		_clear_telegraph()
		_enter(S.ATTACK)


func _b_attack(delta: float, p: Node3D) -> void:
	match _atk:
		"slam":
			_stop(delta)
			if not _did_hit:
				_did_hit = true
				_slam_impact(p)
		"swipe":
			_stop(delta)
			if not _did_hit and state_t >= 0.1 and p != null:
				_did_hit = true
				_swipe_hit(p)
		"charge":
			velocity.x = _lock_dir.x * CHARGE_SPEED
			velocity.z = _lock_dir.z * CHARGE_SPEED
			if not _did_hit and p != null:
				_try_melee_hit(p, 2.2)
			var travelled := Vector2(global_position.x - _charge_start.x, global_position.z - _charge_start.z).length()
			var hs := Vector2(velocity.x, velocity.z).length()
			if state_t > 0.25 and hs < CHARGE_SPEED * 0.45:
				_crash()
				return
			if travelled >= CHARGE_LENGTH:
				_finish_attack()
				return
		"volley":
			_stop(delta)
			var times := [0.0] if _phase == 1 else [0.0, 0.5]
			while _wave < times.size() and state_t >= float(times[_wave]):
				_fire_volley(p, 5 if _phase == 1 else 7, 0.0 if _wave == 0 else 0.5)
				_wave += 1
		"summon":
			_stop(delta)
			if not _did_hit:
				_did_hit = true
				_summon()
	if state_t >= attack_time and state == S.ATTACK:
		_finish_attack()


func _finish_attack() -> void:
	_cd = 0.9 if _phase == 1 else 0.45
	if _recover_override > 0.0:
		recover_time = _recover_override
	_enter(S.RECOVER)


func _b_recover(delta: float, p: Node3D) -> void:
	_stop(delta, 22.0)
	if p != null and not _dazed and state_t < recover_time * 0.5:
		_face(_dir_to, delta, 2.0)
	if state_t >= recover_time:
		if _dazed:
			_dazed = false
		if p == null:
			_enter(S.RETREAT)
		else:
			_enter(S.CHASE)


func _b_stagger(delta: float) -> void:
	_stop(delta)
	if state_t >= _stagger_len:
		_cd = 0.5
		_enter(S.CHASE)


func _b_reset(delta: float) -> void:
	_clear_telegraph()
	_dazed = false
	var to_home := home - global_position
	to_home.y = 0.0
	if to_home.length() < 1.8:
		hp = max_hp
		_phase = 1
		_rage = 1.0
		_summons_done = 0
		_enter(S.DORMANT)
		rotation.y = PI
		reset_done.emit()
		return
	_walk(to_home, 5.0, delta)


func _post_move(delta: float) -> void:
	# keep the Warden inside its arena
	var off := global_position - home
	off.y = 0.0
	if off.length() > ARENA_RADIUS:
		var n := off.normalized()
		global_position.x = home.x + n.x * ARENA_RADIUS
		global_position.z = home.z + n.z * ARENA_RADIUS
	# heavy footsteps
	var hs := Vector2(velocity.x, velocity.z).length()
	if hs > 1.5 and state != S.DEAD:
		_step_t -= delta * (hs / 3.5)
		if _step_t <= 0.0:
			_step_t = 0.55
			AudioMgr.play_at("step1", global_position, 45.0, 2.0)
			_shake_cam(0.05)


# ================================================================= attack helpers
func _ground_y() -> float:
	return Terrain.height_at(global_position.x, global_position.z)


func _make_disc(center: Vector3, radius: float) -> void:
	_clear_telegraph()
	_tele = Fx.telegraph_disc(get_parent(), Vector3(center.x, Terrain.height_at(center.x, center.z), center.z), radius)
	_tele_mat = (_tele.material_override as StandardMaterial3D).duplicate()
	_tele.material_override = _tele_mat


func _make_lane() -> void:
	_clear_telegraph()
	_tele = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(2.8, 0.06, CHARGE_LENGTH)
	_tele.mesh = bm
	_tele_mat = Mats.unshaded(Color(0.9, 0.15, 0.12, 0.3)).duplicate()
	_tele.material_override = _tele_mat
	_tele.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_parent().add_child(_tele)
	_place_lane()


func _place_lane() -> void:
	if _tele == null:
		return
	var f := _facing()
	var c := global_position + f * (CHARGE_LENGTH * 0.5 + 0.5)
	_tele.global_position = Vector3(c.x, Terrain.height_at(c.x, c.z) + 0.12, c.z)
	_tele.rotation = Vector3(0, rotation.y, 0)


func _clear_telegraph() -> void:
	if _tele != null and is_instance_valid(_tele):
		_tele.queue_free()
	_tele = null
	_tele_mat = null


func _shockwave(pos: Vector3, radius: float, col: Color) -> void:
	var m := MeshInstance3D.new()
	var c := CylinderMesh.new()
	c.top_radius = 1.0
	c.bottom_radius = 1.0
	c.height = 0.12
	c.radial_segments = 32
	c.rings = 1
	m.mesh = c
	var mat := Mats.unshaded(col, true).duplicate() as StandardMaterial3D
	m.material_override = mat
	m.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	get_parent().add_child(m)
	m.global_position = Vector3(pos.x, Terrain.height_at(pos.x, pos.z) + 0.15, pos.z)
	m.scale = Vector3(0.4, 1.0, 0.4)
	var tw := m.create_tween().set_parallel(true)
	tw.tween_property(m, "scale", Vector3(radius, 1.0, radius), 0.4).set_ease(Tween.EASE_OUT)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.4)
	tw.chain().tween_callback(m.queue_free)
	Fx.burst(get_parent(), m.global_position + Vector3(0, 0.3, 0), Color(0.9, 0.75, 0.5, 0.5), 22, radius * 1.4, 0.7, 0.35, 1.0)


func _slam_impact(p: Node3D) -> void:
	AudioMgr.play_at("boss_slam", global_position, 60.0, 2.0)
	_shake_cam(0.75)
	_shockwave(global_position, SLAM_RADIUS, Color(1.0, 0.65, 0.25, 0.55))
	if p == null:
		return
	var to := p.global_position - global_position
	var dy := p.global_position.y - global_position.y
	to.y = 0.0
	# standing on the ground inside the ring gets hit; a jump clears it, a roll's i-frames ignore it
	if to.length() <= SLAM_RADIUS + 0.3 and dy < 1.0 and _los:
		p.take_damage(damage, global_position, self)


func _swipe_hit(p: Node3D) -> void:
	AudioMgr.play_at("sword_swing", global_position, 40.0, 0.0)
	_shake_cam(0.25)
	var to := p.global_position - global_position
	var dy := absf(to.y)
	to.y = 0.0
	if to.length() > 4.6 or dy > 2.2 or not _los:
		return
	if to.length() > 0.5 and _facing().dot(to.normalized()) < -0.05:
		return
	p.take_damage(damage, global_position, self)


func _crash() -> void:
	_dazed = true
	_recover_override = 2.0
	velocity = Vector3.ZERO
	AudioMgr.play_at("boss_slam", global_position, 60.0, 0.0)
	_shake_cam(0.7)
	Fx.burst(get_parent(), global_position + Vector3(0, 1.5, 0), Color(0.9, 0.8, 0.6, 0.9), 24, 5.0, 0.7, 0.2, 4.0)
	Fx.floating_text(get_parent(), global_position + Vector3(0, 5.2, 0), "DAZED!", Color("ffe08a"), 80)
	_finish_attack()


func _fire_volley(p: Node3D, count: int, angle_offset: float) -> void:
	if p == null:
		return
	var origin := global_position + Vector3(0, 4.0, 0) + _facing() * 1.2
	var target := p.global_position + Vector3(0, 1.1, 0)
	var base := target - origin
	var spread := deg_to_rad(54.0 if count > 5 else 44.0)
	for i in count:
		var t := 0.5 if count == 1 else float(i) / float(count - 1)
		var ang := lerpf(-spread * 0.5, spread * 0.5, t) + deg_to_rad(angle_offset * 12.0)
		var dir := base.rotated(Vector3.UP, ang)
		Projectile.spawn(get_parent(), origin, dir, 9.5, damage, Color(1.0, 0.5, 0.15), self)
	_shake_cam(0.2)


func _summon() -> void:
	_summons_done += 1
	AudioMgr.play_at("boss_roar", global_position, 60.0, -2.0)
	_shake_cam(0.4)
	var f := _facing()
	var side := f.cross(Vector3.UP)
	for k: float in [-1.0, 1.0]:
		var pos := global_position + f * 5.0 + side * 4.5 * k
		pos.y = Terrain.height_at(pos.x, pos.z)
		var e: Node3D = (load("res://scripts/world/enemy.gd") as GDScript).new()
		e.kind = "scarab"
		e.home = pos
		e.position = pos
		get_parent().add_child(e)
		e.engage()
		Fx.burst(get_parent(), pos + Vector3(0, 0.5, 0), Color(0.9, 0.6, 0.3, 0.8), 14, 3.0, 0.5, 0.18)
		_minions.append(e)


# ================================================================= damage / phases
func take_damage(amount: float, from_pos: Vector3, source: Object = null, crit: bool = false) -> void:
	if state == S.DEAD:
		return
	var a := amount * (1.3 if _dazed else 1.0)
	super.take_damage(a, from_pos, source, crit)


func _on_hurt(_from_pos: Vector3) -> void:
	if state == S.DORMANT:
		_wake_up()
		return
	if _phase == 1 and hp <= max_hp * 0.5 and state != S.DEAD:
		_enter_phase2()


func _enter_phase2() -> void:
	_phase = 2
	_rage = 1.25
	_dazed = false
	_clear_telegraph()
	_stagger_len = 1.7
	_enter(S.HURT)
	AudioMgr.play("boss_roar", 3.0)
	_shake_cam(0.8)
	_shockwave(global_position, 9.0, Color(1.0, 0.3, 0.15, 0.6))
	if _core_mat != null:
		_core_mat.emission = Color(1.0, 0.2, 0.1)
		_core_mat.emission_energy_multiplier = 6.0
	Fx.emitter(_rig.torso, Vector3(0, 0.6, 0), Color(1.0, 0.3, 0.1, 0.8), 14, 1.2, 0.14, Vector3(0, 1.4, 0), 50.0, Vector3(0.3, 0.1, 0.2))
	GameState.toast.emit("The Hollow Warden is enraged!", "warn")
	phase_changed.emit(2)


func _on_enter(s: int) -> void:
	super._on_enter(s)
	if s == S.HURT and _phase == 1:
		_stagger_len = 0.4


func _die(from_pos: Vector3) -> void:
	_clear_telegraph()
	_dazed = false
	AudioMgr.play("boss_slam", 3.0)
	_shake_cam(1.0)
	for m in _minions:
		if is_instance_valid(m) and not m.is_dead():
			m.take_damage(9999.0, global_position, self)
	super._die(from_pos)


func _reward() -> void:
	pass  # GameState.on_boss_defeated() (called by the game) grants the XP and counts the kill


func _drop_loot() -> void:
	var parent := get_parent()
	var gy := Terrain.height_at(global_position.x, global_position.z)
	var pos := global_position + Vector3(0, 1.5, 0)
	for i in 5:
		Pickup.spawn(parent, pos, "", 24, gy)
	Pickup.spawn(parent, pos, "sand_glass", 2, gy)
	Pickup.spawn(parent, pos, "wraith_dust", 3, gy)
	Pickup.spawn(parent, pos, "healing_draught", 2, gy)


func _tick_dead(delta: float) -> void:
	velocity.x = 0.0
	velocity.z = 0.0
	if is_on_floor():
		velocity.y = -1.0
	else:
		velocity.y -= 24.0 * delta
	move_and_slide()
	_rig.state = "dead"
	_rig.animate(delta)
	if state_t > 0.5 and not _crumble_fx:
		_crumble_fx = true
		Fx.emitter(get_parent(), global_position + Vector3(0, 0.6, 0), Color(1.0, 0.8, 0.4, 0.8), 18, 2.0, 0.16, Vector3(0, 1.8, 0), 60.0, Vector3(1.4, 0.2, 1.4))
	var u := clampf((state_t - 3.0) / 2.5, 0.0, 1.0)
	_body.scale = Vector3.ONE * 2.1 * maxf(1.0 - u, 0.01)
	if state_t > 5.8:
		queue_free()


# ================================================================= animation
func _animate(delta: float) -> void:
	var hs := Vector2(velocity.x, velocity.z).length()
	match state:
		S.WAKE:
			_rig.state = "jump" if state_t > 0.5 else "idle"
		S.WINDUP, S.ATTACK, S.RECOVER:
			match _atk:
				"charge":
					if state == S.ATTACK:
						_rig.state = "run"
						_rig.speed01 = 1.0
					elif state == S.WINDUP:
						_rig.state = "attack"
						_rig.phase = 0.12
					else:
						_rig.state = "hurt" if _dazed else "idle"
				"volley", "summon":
					_rig.state = "jump" if state != S.RECOVER else "idle"
				_:
					_rig.state = "attack"
					_rig.phase = _phase01()
		S.HURT:
			_rig.state = "hurt"
		S.CHASE, S.RETREAT:
			_rig.state = "walk" if hs > 0.6 else "idle"
		_:
			_rig.state = "idle"
	if not (state == S.ATTACK and _atk == "charge"):
		_rig.speed01 = clampf(hs / 6.0, 0.0, 1.0)
	_rig.animate(delta)
	if _core_mat != null and _phase == 1:
		_core_mat.emission_energy_multiplier = 2.5 + sin(_t * 3.0) * 0.8
