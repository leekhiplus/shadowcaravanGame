extends RefCounted
## Deterministic heightfield terrain: dunes, flattened landmark zones, sand roads, the ridge that the
## Ancient Gate cuts through, border dunes, and a Wraith Hollow plateau. The height grid is computed
## once; runtime queries bilinearly sample it. Also produces the render mesh and the world-map image.

const Items := preload("res://scripts/data/items.gd")

const HALF := 100.0
const STEP := 2.0
const N := 101  # vertices per side (HALF * 2 / STEP + 1)
const WRAITH_CENTER := Vector2(-52, -26)
const GATE_Z := -56.0

# flatten zones: x, z, inner radius (fully flat), outer radius (back to dunes)
const FLAT_ZONES := [
	[-62.0, 55.0, 14.0, 26.0],   # camp
	[-4.0, 22.0, 16.0, 28.0],    # ruins
	[52.0, -12.0, 20.0, 30.0],   # temple
	[0.0, -56.0, 10.0, 20.0],    # gate approach
	[0.0, -80.0, 22.0, 34.0],    # lost caravan
	[14.0, -8.0, 8.0, 14.0],     # hidden alcove
	[-52.0, -26.0, 20.0, 30.0],  # wraith hollow (plateau added on top)
	[24.0, 38.0, 6.0, 12.0],     # weeping stone
	[34.0, 66.0, 8.0, 14.0],     # moonwell
	[-30.0, -42.0, 10.0, 18.0],  # colossus
	[-84.0, 20.0, 10.0, 18.0],   # wreck
]

static var _n1: FastNoiseLite
static var _n2: FastNoiseLite
static var _segs := PackedFloat32Array()  # ax, az, bx, bz, minx, minz, maxx, maxz per segment
static var _grid := PackedFloat32Array()
static var _map_tex: ImageTexture


static func _setup() -> void:
	if _n1 != null:
		return
	_n1 = FastNoiseLite.new()
	_n1.seed = 1337
	_n1.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_n1.frequency = 0.017
	_n1.fractal_type = FastNoiseLite.FRACTAL_FBM
	_n1.fractal_octaves = 3
	_n1.fractal_gain = 0.45
	_n2 = FastNoiseLite.new()
	_n2.seed = 4242
	_n2.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_n2.frequency = 0.05
	_segs = PackedFloat32Array()
	var pad := 7.0
	for path in Items.PATHS:
		for i in range(path.size() - 1):
			var a: Vector2 = path[i]
			var b: Vector2 = path[i + 1]
			_segs.append_array([a.x, a.y, b.x, b.y, minf(a.x, b.x) - pad, minf(a.y, b.y) - pad, maxf(a.x, b.x) + pad, maxf(a.y, b.y) + pad])


## Distance to the nearest sand road (large when far away).
static func path_distance(x: float, z: float) -> float:
	_setup()
	var best := 1.0e9
	var i := 0
	var n := _segs.size()
	while i < n:
		if x >= _segs[i + 4] and x <= _segs[i + 6] and z >= _segs[i + 5] and z <= _segs[i + 7]:
			var ax := _segs[i]
			var az := _segs[i + 1]
			var abx := _segs[i + 2] - ax
			var abz := _segs[i + 3] - az
			var l2 := abx * abx + abz * abz
			var t := 0.0
			if l2 > 0.0001:
				t = clampf(((x - ax) * abx + (z - az) * abz) / l2, 0.0, 1.0)
			var dx := x - (ax + abx * t)
			var dz := z - (az + abz * t)
			var d := sqrt(dx * dx + dz * dz)
			if d < best:
				best = d
		i += 8
	return best


static func path_mask(x: float, z: float) -> float:
	return 1.0 - smoothstep(2.5, 6.5, path_distance(x, z))


static func flat_mask(x: float, z: float) -> float:
	var m := 0.0
	for zn in FLAT_ZONES:
		var dx: float = x - float(zn[0])
		var dz: float = z - float(zn[1])
		var d2 := dx * dx + dz * dz
		var outer: float = zn[3]
		if d2 < outer * outer:
			var v := 1.0 - smoothstep(float(zn[2]), outer, sqrt(d2))
			if v > m:
				m = v
	return m


## The raw analytic height function (slow). Use height_at() at runtime.
static func height_fn(x: float, z: float) -> float:
	_setup()
	var dunes: float = 3.2 * _n1.get_noise_2d(x, z) + 0.8 * _n2.get_noise_2d(x, z)
	dunes += 0.9 * absf(_n1.get_noise_2d(x * 0.6 + 50.0, z * 1.4))
	var pm := path_mask(x, z)
	var h := lerpf(dunes * (1.0 - pm * 0.75), 0.0, flat_mask(x, z))
	var dp := Vector2(x, z).distance_to(WRAITH_CENTER)
	h += 2.6 * (1.0 - smoothstep(10.0, 18.0, dp))
	var band := 1.0 - smoothstep(2.5, 7.0, absf(z - GATE_Z))
	var gap := smoothstep(6.0, 9.5, absf(x))
	h += 11.0 * band * gap
	var e := maxf(absf(x), absf(z))
	h += 16.0 * smoothstep(84.0, 98.0, e)
	return h


static func ensure_grid() -> void:
	if _grid.size() == N * N:
		return
	_setup()
	_grid.resize(N * N)
	for zi in N:
		for xi in N:
			_grid[zi * N + xi] = height_fn(-HALF + float(xi) * STEP, -HALF + float(zi) * STEP)


static func _g(xi: int, zi: int) -> float:
	return _grid[clampi(zi, 0, N - 1) * N + clampi(xi, 0, N - 1)]


## Terrain height at a world position (bilinear sample of the precomputed grid; matches the mesh).
static func height_at(x: float, z: float) -> float:
	ensure_grid()
	var fx := clampf((x + HALF) / STEP, 0.0, float(N - 1) - 0.0001)
	var fz := clampf((z + HALF) / STEP, 0.0, float(N - 1) - 0.0001)
	var xi := int(fx)
	var zi := int(fz)
	var tx := fx - float(xi)
	var tz := fz - float(zi)
	# the mesh splits each quad along the (xi,zi)-(xi+1,zi+1) diagonal
	var h00 := _g(xi, zi)
	var h11 := _g(xi + 1, zi + 1)
	if tx > tz:
		var h10 := _g(xi + 1, zi)
		return h00 + (h10 - h00) * tx + (h11 - h10) * tz
	var h01 := _g(xi, zi + 1)
	return h00 + (h11 - h01) * tx + (h01 - h00) * tz


static func normal_at(x: float, z: float) -> Vector3:
	var e := STEP
	var dx := height_at(x + e, z) - height_at(x - e, z)
	var dz := height_at(x, z + e) - height_at(x, z - e)
	return Vector3(-dx, 2.0 * e, -dz).normalized()


static func is_flat_free(x: float, z: float, margin: float = 0.0) -> bool:
	## true when the spot is outside every landmark zone and off the roads (for scattering props)
	for zn in FLAT_ZONES:
		var d := Vector2(x - float(zn[0]), z - float(zn[1])).length()
		if d < float(zn[3]) + margin:
			return false
	return path_distance(x, z) > 6.0 + margin


static func _vertex_color(x: float, z: float, h: float, n: Vector3) -> Color:
	var sand_dark := Color(0.60, 0.44, 0.29)
	var sand_light := Color(0.87, 0.71, 0.47)
	var rock := Color(0.36, 0.30, 0.28)
	var pathc := Color(0.76, 0.64, 0.46)
	var nv: float = _n2.get_noise_2d(x * 1.7, z * 1.7)
	var t := clampf(0.5 + h * 0.07 + nv * 0.28, 0.0, 1.0)
	var c := sand_dark.lerp(sand_light, t)
	# wind ripples
	c = c.lerp(c.darkened(0.12), 0.5 + 0.5 * sin(x * 0.9 + z * 0.35 + nv * 3.0))
	var slope := 1.0 - n.y
	c = c.lerp(rock, smoothstep(0.22, 0.5, slope))
	c = c.lerp(pathc, path_mask(x, z) * 0.7)
	var e := maxf(absf(x), absf(z))
	c = c.lerp(rock.darkened(0.2), smoothstep(88.0, 98.0, e) * 0.7)
	# worn flagstones around the Broken Court and the temple forecourt
	var dr := Vector2(x + 4.0, z - 22.0).length()
	if dr < 15.0:
		c = c.lerp(Color(0.55, 0.48, 0.38) * (0.85 + 0.15 * nv), 1.0 - smoothstep(9.0, 15.0, dr))
	var dt := Vector2(x - 52.0, z + 12.0).length()
	if dt < 18.0:
		c = c.lerp(Color(0.42, 0.38, 0.34), (1.0 - smoothstep(12.0, 18.0, dt)) * 0.8)
	var dw := Vector2(x, z).distance_to(WRAITH_CENTER)
	if dw < 12.0:
		c = c.lerp(Color(0.62, 0.6, 0.55), 1.0 - smoothstep(6.0, 12.0, dw))
	return c


static func build_mesh() -> ArrayMesh:
	ensure_grid()
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var cols := PackedColorArray()
	var idx := PackedInt32Array()
	verts.resize(N * N)
	norms.resize(N * N)
	cols.resize(N * N)
	for zi in N:
		for xi in N:
			var x := -HALF + float(xi) * STEP
			var z := -HALF + float(zi) * STEP
			var h := _g(xi, zi)
			var nx := _g(xi - 1, zi) - _g(xi + 1, zi)
			var nz := _g(xi, zi - 1) - _g(xi, zi + 1)
			var nrm := Vector3(nx, 2.0 * STEP, nz).normalized()
			var i := zi * N + xi
			verts[i] = Vector3(x, h, z)
			norms[i] = nrm
			cols[i] = _vertex_color(x, z, h, nrm)
	for zi in N - 1:
		for xi in N - 1:
			var a := zi * N + xi
			var b := a + 1
			var c := a + N
			var d := c + 1
			# diagonal a-d (matches height_at); Godot front faces are clockwise as seen from the front (above)
			idx.append_array([a, d, c, a, b, d])
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return mesh


## 128x128 hill-shaded parchment map of the whole world (cached).
static func map_texture() -> ImageTexture:
	if _map_tex != null:
		return _map_tex
	ensure_grid()
	var res := 128
	var img := Image.create(res, res, false, Image.FORMAT_RGBA8)
	var light := Vector3(-0.6, 0.7, -0.4).normalized()
	for py in res:
		for px in res:
			var x := -HALF + (float(px) + 0.5) / float(res) * HALF * 2.0
			var z := -HALF + (float(py) + 0.5) / float(res) * HALF * 2.0
			var h := height_at(x, z)
			var n := normal_at(x, z)
			var shade := clampf(0.55 + 0.6 * (n.dot(light) - 0.7), 0.25, 1.1)
			var base := Color("c8b184").lerp(Color("8a6d48"), clampf(h / 10.0, 0.0, 1.0))
			base = base.lerp(Color("5d4a36"), smoothstep(0.25, 0.55, 1.0 - n.y))
			base = base.lerp(Color("e0cfa2"), path_mask(x, z) * 0.55)
			var c := Color(base.r * shade, base.g * shade, base.b * shade, 1.0)
			img.set_pixel(px, py, c)
	_map_tex = ImageTexture.create_from_image(img)
	return _map_tex


## Collision triangles of the terrain (same triangulation as the render mesh, but built straight from the
## height grid so it does not depend on the renderer).
static func collision_faces() -> PackedVector3Array:
	ensure_grid()
	var f := PackedVector3Array()
	f.resize((N - 1) * (N - 1) * 6)
	var k := 0
	for zi in N - 1:
		for xi in N - 1:
			var x0 := -HALF + float(xi) * STEP
			var z0 := -HALF + float(zi) * STEP
			var a := Vector3(x0, _g(xi, zi), z0)
			var b := Vector3(x0 + STEP, _g(xi + 1, zi), z0)
			var c := Vector3(x0, _g(xi, zi + 1), z0 + STEP)
			var d := Vector3(x0 + STEP, _g(xi + 1, zi + 1), z0 + STEP)
			f[k] = a
			f[k + 1] = c
			f[k + 2] = d
			f[k + 3] = a
			f[k + 4] = d
			f[k + 5] = b
			k += 6
	return f
