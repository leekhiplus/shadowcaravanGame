extends RefCounted
## Procedural vector icons and rune glyphs. Everything is drawn with CanvasItem primitives inside a
## _draw() call, so no image assets (and no unlicensed art) are required and icons scale cleanly.

const Pal := preload("res://scripts/data/pal.gd")

const RUNE_NAMES := ["Sun", "Moon", "Eye", "Serpent"]


static func _pts(c: Vector2, s: float, pts: Array) -> PackedVector2Array:
	var arr := PackedVector2Array()
	for p in pts:
		arr.append(c + (p as Vector2) * s)
	return arr


static func _poly(ci: CanvasItem, c: Vector2, s: float, pts: Array, col: Color) -> void:
	ci.draw_colored_polygon(_pts(c, s, pts), col)


static func _line(ci: CanvasItem, c: Vector2, s: float, pts: Array, col: Color, w: float) -> void:
	ci.draw_polyline(_pts(c, s, pts), col, maxf(1.5, w), true)


static func _dot(ci: CanvasItem, c: Vector2, s: float, p: Vector2, r: float, col: Color) -> void:
	ci.draw_circle(c + p * s, r * s, col)


static func _ellipse(rx: float, ry: float, n: int = 22, off := Vector2.ZERO) -> Array:
	var out: Array = []
	for i in n:
		var a := TAU * float(i) / float(n)
		out.append(off + Vector2(cos(a) * rx, sin(a) * ry))
	return out


static func _star(r_out: float, r_in: float, n: int, off := Vector2.ZERO) -> Array:
	var out: Array = []
	for i in n * 2:
		var a := PI * float(i) / float(n) - PI / 2.0
		var r := r_out if i % 2 == 0 else r_in
		out.append(off + Vector2(cos(a), sin(a)) * r)
	return out


## Draws icon `id` centred at `c` inside a square of half-size `s`.
static func draw_icon(ci: CanvasItem, id: String, c: Vector2, s: float, col: Color = Pal.GOLD_LIGHT) -> void:
	var w := maxf(1.8, s * 0.12)
	match id:
		"coin":
			_dot(ci, c, s, Vector2.ZERO, 0.9, Pal.GOLD_DARK)
			_dot(ci, c, s, Vector2.ZERO, 0.76, Pal.GOLD)
			ci.draw_arc(c, s * 0.52, 0, TAU, 24, Pal.GOLD_DARK, w * 0.8, true)
			_line(ci, c, s, [Vector2(0, -0.28), Vector2(0, 0.28)], Pal.GOLD_DARK, w * 0.9)
		"fragment":
			_poly(ci, c, s, [Vector2(0.05, -0.95), Vector2(0.6, -0.1), Vector2(0.32, 0.9), Vector2(-0.42, 0.72), Vector2(-0.62, -0.25)], Pal.TURQUOISE_DIM)
			_poly(ci, c, s, [Vector2(0.05, -0.95), Vector2(0.6, -0.1), Vector2(0.05, 0.1), Vector2(-0.3, -0.35)], Pal.TURQUOISE)
			_line(ci, c, s, [Vector2(0.05, -0.95), Vector2(0.05, 0.1), Vector2(0.32, 0.9)], Color(1, 1, 1, 0.55), w * 0.6)
		"potion":
			_poly(ci, c, s, [Vector2(-0.16, -0.8), Vector2(0.16, -0.8), Vector2(0.18, -0.25), Vector2(-0.18, -0.25)], Pal.SAND)
			_dot(ci, c, s, Vector2(0, 0.3), 0.58, Pal.BLOOD)
			_dot(ci, c, s, Vector2(-0.2, 0.15), 0.14, Color(1, 1, 1, 0.45))
			_poly(ci, c, s, [Vector2(-0.2, -0.95), Vector2(0.2, -0.95), Vector2(0.17, -0.78), Vector2(-0.17, -0.78)], Pal.SAND_DARK)
		"shell":
			_poly(ci, c, s, _ellipse(0.62, 0.82), Color("1f6168"))
			_poly(ci, c, s, _ellipse(0.46, 0.62, 18, Vector2(-0.05, -0.08)), Color("2b8a8f"))
			_line(ci, c, s, [Vector2(0, -0.8), Vector2(0, 0.8)], Pal.GOLD, w * 0.7)
			_dot(ci, c, s, Vector2(0, -0.86), 0.2, Pal.GOLD_DARK)
		"dust":
			for d in [[Vector2(-0.35, -0.3), 0.42], [Vector2(0.4, 0.05), 0.34], [Vector2(-0.1, 0.55), 0.28]]:
				_poly(ci, c, s, _star(d[1], d[1] * 0.28, 4, d[0]), Color("a9d6ff"))
		"glass":
			_poly(ci, c, s, [Vector2(0, -0.9), Vector2(0.72, -0.4), Vector2(0.72, 0.4), Vector2(0, 0.9), Vector2(-0.72, 0.4), Vector2(-0.72, -0.4)], Color("c98d3c"))
			_poly(ci, c, s, [Vector2(0, -0.9), Vector2(0.72, -0.4), Vector2(0, 0.05), Vector2(-0.72, -0.4)], Color("f0c46e"))
		"scimitar":
			_line(ci, c, s, [Vector2(-0.55, 0.55), Vector2(-0.05, 0.1), Vector2(0.4, -0.35), Vector2(0.62, -0.88)], Color("d8e4ea"), w * 1.5)
			_line(ci, c, s, [Vector2(-0.62, 0.15), Vector2(-0.15, 0.62)], Pal.GOLD, w * 1.5)
			_line(ci, c, s, [Vector2(-0.55, 0.55), Vector2(-0.8, 0.8)], Pal.GOLD_DARK, w * 1.8)
		"sword":
			_line(ci, c, s, [Vector2(-0.15, 0.15), Vector2(0.75, -0.75)], col, w * 1.8)
			_line(ci, c, s, [Vector2(-0.45, -0.05), Vector2(0.05, 0.45)], col, w * 1.6)
			_line(ci, c, s, [Vector2(-0.25, 0.25), Vector2(-0.7, 0.7)], col, w * 2.0)
		"cloak":
			_poly(ci, c, s, [Vector2(-0.34, -0.45), Vector2(0.34, -0.45), Vector2(0.78, 0.85), Vector2(-0.78, 0.85)], Pal.MIDNIGHT_LIGHT)
			_poly(ci, c, s, _ellipse(0.34, 0.34, 16, Vector2(0, -0.55)), Color("2a3b6b"))
			_line(ci, c, s, [Vector2(-0.78, 0.85), Vector2(0.78, 0.85)], Pal.GOLD, w)
			_line(ci, c, s, [Vector2(0, -0.2), Vector2(0, 0.85)], Pal.GOLD_DARK, w * 0.7)
		"heart":
			_dot(ci, c, s, Vector2(-0.3, -0.2), 0.42, Pal.BLOOD)
			_dot(ci, c, s, Vector2(0.3, -0.2), 0.42, Pal.BLOOD)
			_poly(ci, c, s, [Vector2(-0.69, -0.02), Vector2(0.69, -0.02), Vector2(0, 0.85)], Pal.BLOOD)
		"boot", "bolt", "sprint":
			_poly(ci, c, s, [Vector2(0.18, -0.95), Vector2(-0.55, 0.12), Vector2(-0.06, 0.12), Vector2(-0.22, 0.95), Vector2(0.55, -0.22), Vector2(0.06, -0.22)], col if id == "sprint" else Pal.STAMINA)
		"roll":
			ci.draw_arc(c, s * 0.62, deg_to_rad(-40), deg_to_rad(250), 24, col, w * 1.6, true)
			var tip := c + Vector2(cos(deg_to_rad(250)), sin(deg_to_rad(250))) * s * 0.62
			ci.draw_colored_polygon(PackedVector2Array([tip + Vector2(-0.34, 0.18) * s, tip + Vector2(0.3, 0.3) * s, tip + Vector2(0.0, -0.38) * s]), col)
		"jump":
			_line(ci, c, s, [Vector2(-0.6, 0.05), Vector2(0, -0.55), Vector2(0.6, 0.05)], col, w * 1.8)
			_line(ci, c, s, [Vector2(-0.6, 0.65), Vector2(0, 0.05), Vector2(0.6, 0.65)], col, w * 1.8)
		"interact":
			_poly(ci, c, s, _star(0.95, 0.3, 4), col)
			_dot(ci, c, s, Vector2.ZERO, 0.16, Pal.OBSIDIAN)
		"pause":
			_poly(ci, c, s, [Vector2(-0.5, -0.7), Vector2(-0.14, -0.7), Vector2(-0.14, 0.7), Vector2(-0.5, 0.7)], col)
			_poly(ci, c, s, [Vector2(0.14, -0.7), Vector2(0.5, -0.7), Vector2(0.5, 0.7), Vector2(0.14, 0.7)], col)
		"map":
			_poly(ci, c, s, [Vector2(-0.85, -0.55), Vector2(-0.3, -0.7), Vector2(-0.3, 0.65), Vector2(-0.85, 0.8)], col.darkened(0.15))
			_poly(ci, c, s, [Vector2(-0.25, -0.7), Vector2(0.3, -0.55), Vector2(0.3, 0.8), Vector2(-0.25, 0.65)], col)
			_poly(ci, c, s, [Vector2(0.35, -0.55), Vector2(0.9, -0.7), Vector2(0.9, 0.65), Vector2(0.35, 0.8)], col.darkened(0.15))
		"pack":
			# a satchel: strap handle on top, pointed flap with a buckle, front pocket
			_poly(ci, c, s, [Vector2(-0.62, -0.45), Vector2(-0.38, -0.78), Vector2(0.38, -0.78), Vector2(0.62, -0.45), Vector2(0.74, 0.82), Vector2(-0.74, 0.82)], col.darkened(0.25))
			_poly(ci, c, s, [Vector2(-0.52, 0.3), Vector2(0.52, 0.3), Vector2(0.6, 0.72), Vector2(-0.6, 0.72)], col.darkened(0.5))
			_poly(ci, c, s, [Vector2(-0.62, -0.45), Vector2(-0.38, -0.78), Vector2(0.38, -0.78), Vector2(0.62, -0.45), Vector2(0.58, 0.02), Vector2(0, 0.26), Vector2(-0.58, 0.02)], col)
			ci.draw_arc(c + Vector2(0, -0.78) * s, s * 0.24, PI, TAU, 10, col, maxf(1.5, w), true)
			_dot(ci, c, s, Vector2(0, 0.06), 0.13, Pal.OBSIDIAN)
		"joystick":
			ci.draw_arc(c, s * 0.9, 0.0, TAU, 28, col, maxf(1.5, w), true)
			ci.draw_circle(c, s * 0.3, col)
			for d: Vector2 in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
				var pp := Vector2(-d.y, d.x)
				_poly(ci, c, s, [d * 0.5 + pp * 0.13, d * 0.5 - pp * 0.13, d * 0.74], col)
		"eye":
			var top: Array = []
			var bot: Array = []
			for i in 11:
				var x := -0.95 + 1.9 * float(i) / 10.0
				var h := 0.55 * (1.0 - pow(x / 0.95, 2.0))
				top.append(Vector2(x, -h))
				bot.push_front(Vector2(x, h))
			_poly(ci, c, s, top + bot, col)
			_dot(ci, c, s, Vector2.ZERO, 0.34, Pal.OBSIDIAN)
			_dot(ci, c, s, Vector2.ZERO, 0.15, col)
		"scroll":
			_poly(ci, c, s, [Vector2(-0.6, -0.75), Vector2(0.6, -0.75), Vector2(0.6, 0.75), Vector2(-0.6, 0.75)], col.darkened(0.1))
			for yy in [-0.4, -0.1, 0.2, 0.5]:
				_line(ci, c, s, [Vector2(-0.35, yy), Vector2(0.35, yy)], Pal.OBSIDIAN, w * 0.8)
		"book":
			# an open book: dark cover edge, two angled pages with lines of text
			_poly(ci, c, s, [Vector2(-0.96, 0.58), Vector2(-0.05, 0.8), Vector2(0.05, 0.8), Vector2(0.96, 0.58), Vector2(0.96, 0.78), Vector2(0.05, 1.0), Vector2(-0.05, 1.0), Vector2(-0.96, 0.78)], col.darkened(0.5))
			_poly(ci, c, s, [Vector2(-0.92, -0.62), Vector2(-0.04, -0.42), Vector2(-0.04, 0.78), Vector2(-0.92, 0.56)], col)
			_poly(ci, c, s, [Vector2(0.92, -0.62), Vector2(0.04, -0.42), Vector2(0.04, 0.78), Vector2(0.92, 0.56)], col.darkened(0.1))
			for k in [0.0, 0.3, 0.6]:
				_line(ci, c, s, [Vector2(-0.76, -0.3 + k), Vector2(-0.24, -0.17 + k)], Pal.OBSIDIAN, w * 0.7)
				_line(ci, c, s, [Vector2(0.76, -0.3 + k), Vector2(0.24, -0.17 + k)], Pal.OBSIDIAN, w * 0.7)
		"camp", "tent":
			_poly(ci, c, s, [Vector2(0, -0.85), Vector2(0.95, 0.75), Vector2(-0.95, 0.75)], col.darkened(0.15))
			_poly(ci, c, s, [Vector2(0, -0.85), Vector2(0.95, 0.75), Vector2(0.1, 0.75)], col)
			_poly(ci, c, s, [Vector2(0, -0.1), Vector2(0.3, 0.75), Vector2(-0.3, 0.75)], Pal.OBSIDIAN)
		"flame":
			_poly(ci, c, s, [Vector2(0, -0.95), Vector2(0.55, 0.0), Vector2(0.5, 0.55), Vector2(0, 0.9), Vector2(-0.5, 0.55), Vector2(-0.55, 0.0)], Color("e0782f"))
			_poly(ci, c, s, [Vector2(0.05, -0.35), Vector2(0.3, 0.2), Vector2(0.2, 0.6), Vector2(-0.05, 0.75), Vector2(-0.28, 0.5), Vector2(-0.22, 0.15)], Color("f7cf68"))
		"anvil":
			_poly(ci, c, s, [Vector2(-0.95, -0.45), Vector2(0.7, -0.45), Vector2(0.95, -0.2), Vector2(0.4, -0.1), Vector2(0.3, 0.3), Vector2(0.6, 0.7), Vector2(-0.6, 0.7), Vector2(-0.3, 0.3), Vector2(-0.4, -0.1), Vector2(-0.95, -0.2)], col)
		"hammer":
			_line(ci, c, s, [Vector2(-0.6, 0.7), Vector2(0.35, -0.35)], Pal.SAND_DARK, w * 1.8)
			_poly(ci, c, s, [Vector2(0.0, -0.75), Vector2(0.8, -0.2), Vector2(0.5, 0.15), Vector2(-0.3, -0.4)], col)
		"gear":
			_dot(ci, c, s, Vector2.ZERO, 0.62, col)
			for i in 8:
				var a := TAU * float(i) / 8.0
				ci.draw_line(c + Vector2(cos(a), sin(a)) * s * 0.55, c + Vector2(cos(a), sin(a)) * s * 0.9, col, maxf(3.0, s * 0.3))
			_dot(ci, c, s, Vector2.ZERO, 0.26, Pal.OBSIDIAN)
		"close":
			_line(ci, c, s, [Vector2(-0.65, -0.65), Vector2(0.65, 0.65)], col, w * 1.8)
			_line(ci, c, s, [Vector2(0.65, -0.65), Vector2(-0.65, 0.65)], col, w * 1.8)
		"check":
			_line(ci, c, s, [Vector2(-0.7, 0.0), Vector2(-0.2, 0.55), Vector2(0.75, -0.6)], col, w * 1.8)
		"lock":
			_poly(ci, c, s, [Vector2(-0.6, -0.05), Vector2(0.6, -0.05), Vector2(0.6, 0.85), Vector2(-0.6, 0.85)], col)
			ci.draw_arc(c + Vector2(0, -0.05) * s, s * 0.38, PI, TAU, 12, col, w * 1.4, true)
		"note":
			_dot(ci, c, s, Vector2(-0.3, 0.55), 0.35, col)
			_line(ci, c, s, [Vector2(0.02, 0.5), Vector2(0.02, -0.8), Vector2(0.6, -0.55)], col, w * 1.3)
		"speaker":
			_poly(ci, c, s, [Vector2(-0.8, -0.28), Vector2(-0.4, -0.28), Vector2(0.05, -0.7), Vector2(0.05, 0.7), Vector2(-0.4, 0.28), Vector2(-0.8, 0.28)], col)
			ci.draw_arc(c + Vector2(0.05, 0) * s, s * 0.45, deg_to_rad(-45), deg_to_rad(45), 8, col, w, true)
			ci.draw_arc(c + Vector2(0.05, 0) * s, s * 0.8, deg_to_rad(-45), deg_to_rad(45), 8, col, w, true)
		"star":
			_poly(ci, c, s, _star(0.95, 0.4, 5), col)
		"crown":
			_poly(ci, c, s, [Vector2(-0.85, 0.6), Vector2(-0.85, -0.5), Vector2(-0.4, 0.0), Vector2(0, -0.8), Vector2(0.4, 0.0), Vector2(0.85, -0.5), Vector2(0.85, 0.6)], col)
		"skull":
			_dot(ci, c, s, Vector2(0, -0.1), 0.72, col)
			_poly(ci, c, s, [Vector2(-0.4, 0.3), Vector2(0.4, 0.3), Vector2(0.32, 0.85), Vector2(-0.32, 0.85)], col)
			_dot(ci, c, s, Vector2(-0.28, -0.12), 0.2, Pal.OBSIDIAN)
			_dot(ci, c, s, Vector2(0.28, -0.12), 0.2, Pal.OBSIDIAN)
		"home":
			_poly(ci, c, s, [Vector2(0, -0.9), Vector2(0.95, 0.0), Vector2(0.65, 0.0), Vector2(0.65, 0.8), Vector2(-0.65, 0.8), Vector2(-0.65, 0.0), Vector2(-0.95, 0.0)], col)
			_poly(ci, c, s, [Vector2(-0.2, 0.8), Vector2(-0.2, 0.2), Vector2(0.2, 0.2), Vector2(0.2, 0.8)], Pal.OBSIDIAN)
		"waystone", "travel":
			_poly(ci, c, s, [Vector2(0, -0.95), Vector2(0.5, -0.2), Vector2(0.4, 0.85), Vector2(-0.4, 0.85), Vector2(-0.5, -0.2)], col.darkened(0.2))
			_poly(ci, c, s, [Vector2(0, -0.95), Vector2(0.5, -0.2), Vector2(0.0, -0.1), Vector2(-0.5, -0.2)], col)
			_dot(ci, c, s, Vector2(0, 0.3), 0.14, Pal.TURQUOISE)
		"chest":
			_poly(ci, c, s, [Vector2(-0.8, -0.1), Vector2(0.8, -0.1), Vector2(0.8, 0.75), Vector2(-0.8, 0.75)], col.darkened(0.3))
			_poly(ci, c, s, [Vector2(-0.8, -0.1), Vector2(-0.6, -0.65), Vector2(0.6, -0.65), Vector2(0.8, -0.1)], col)
			_dot(ci, c, s, Vector2(0, -0.05), 0.15, Pal.OBSIDIAN)
		"arrow_up":
			_poly(ci, c, s, [Vector2(0, -0.9), Vector2(0.7, 0.0), Vector2(0.28, 0.0), Vector2(0.28, 0.8), Vector2(-0.28, 0.8), Vector2(-0.28, 0.0), Vector2(-0.7, 0.0)], col)
		"relic":
			_poly(ci, c, s, _star(0.95, 0.5, 8), Pal.GOLD)
			_poly(ci, c, s, _ellipse(0.42, 0.42, 20), Pal.TURQUOISE)
			_dot(ci, c, s, Vector2(-0.12, -0.12), 0.14, Color(1, 1, 1, 0.7))
		"person":
			_dot(ci, c, s, Vector2(0, -0.45), 0.34, col)
			_poly(ci, c, s, [Vector2(-0.6, 0.85), Vector2(-0.45, 0.1), Vector2(0.45, 0.1), Vector2(0.6, 0.85)], col)
		_:
			_dot(ci, c, s, Vector2.ZERO, 0.6, col)


## Rune glyphs 0..3 (Sun, Moon, Eye, Serpent), drawn as glowing outlines.
static func draw_rune(ci: CanvasItem, idx: int, c: Vector2, s: float, col: Color = Pal.TURQUOISE) -> void:
	var w := maxf(2.0, s * 0.11)
	match posmod(idx, 4):
		0:  # Sun
			ci.draw_arc(c, s * 0.38, 0, TAU, 28, col, w, true)
			_dot(ci, c, s, Vector2.ZERO, 0.14, col)
			for i in 8:
				var a := TAU * float(i) / 8.0
				ci.draw_line(c + Vector2(cos(a), sin(a)) * s * 0.58, c + Vector2(cos(a), sin(a)) * s * (0.92 if i % 2 == 0 else 0.78), col, w, true)
		1:  # Moon
			var pts := PackedVector2Array()
			for i in 21:
				var a := deg_to_rad(65.0 + 230.0 * float(i) / 20.0)
				pts.append(c + Vector2(cos(a), sin(a)) * s * 0.85)
			for i in 21:
				var a := deg_to_rad(295.0 - 230.0 * float(i) / 20.0)
				pts.append(c + (Vector2(cos(a), sin(a)) * 0.68 + Vector2(0.34, 0.0)) * s)
			ci.draw_polyline(pts, col, w, true)
			ci.draw_line(pts[pts.size() - 1], pts[0], col, w, true)
			_dot(ci, c, s, Vector2(0.45, -0.4), 0.07, col)
		2:  # Eye
			var up := PackedVector2Array()
			var dn := PackedVector2Array()
			for i in 17:
				var t := float(i) / 16.0
				var x := lerpf(-0.92, 0.92, t)
				var y := 0.5 * sin(PI * t)
				up.append(c + Vector2(x, -y) * s)
				dn.append(c + Vector2(x, y) * s)
			ci.draw_polyline(up, col, w, true)
			ci.draw_polyline(dn, col, w, true)
			ci.draw_arc(c, s * 0.26, 0, TAU, 20, col, w, true)
			_dot(ci, c, s, Vector2.ZERO, 0.11, col)
		3:  # Serpent
			var sp := PackedVector2Array()
			for i in 25:
				var t := float(i) / 24.0
				sp.append(c + Vector2(lerpf(-0.8, 0.7, t), 0.38 * sin(t * TAU * 0.95 + 0.4)) * s)
			ci.draw_polyline(sp, col, w * 1.3, true)
			var head := sp[sp.size() - 1]
			ci.draw_colored_polygon(PackedVector2Array([head + Vector2(0.0, -0.2) * s, head + Vector2(0.3, 0.02) * s, head + Vector2(0.0, 0.22) * s]), col)
			ci.draw_circle(head + Vector2(0.02, -0.04) * s, s * 0.05, Pal.OBSIDIAN)
