extends Control
## Animated, fully procedural desert-at-dusk backdrop for menu screens:
## gradient sky, twinkling stars, moon, distant city silhouette, dune layers, a walking caravan, drifting dust.

const Pal := preload("res://scripts/data/pal.gd")

var show_caravan := true
var dim := 0.0  # 0..1 extra darkening (used under intro text)
var _t := 0.0
var _stars: Array = []
var _motes: Array = []
var _city: Array = []


func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var r := RandomNumberGenerator.new()
	r.seed = 90210
	for i in 150:
		_stars.append([r.randf(), r.randf() * 0.62, r.randf_range(0.8, 2.4), r.randf() * TAU, r.randf_range(0.6, 2.2)])
	for i in 38:
		_motes.append([r.randf(), r.randf(), r.randf_range(0.4, 1.6), r.randf_range(8.0, 26.0)])
	var x := 0.0
	while x < 1.05:
		var w := r.randf_range(0.012, 0.034)
		var h := r.randf_range(0.03, 0.12)
		var kind := r.randi_range(0, 4)  # 0 box, 1 dome, 2 minaret, 3 stepped, 4 box
		_city.append([x, w, h, kind, r.randf()])
		x += w * r.randf_range(0.7, 1.15)


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()


func _dune(w: float, base: float, amp: float, f1: float, f2: float, ph: float, off: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	var n := 48
	for i in n + 1:
		var u := float(i) / float(n)
		var x := u * w
		var y := base + sin(u * f1 + ph + off) * amp + sin(u * f2 + ph * 1.7) * amp * 0.45
		pts.append(Vector2(x, y))
	return pts


func _fill_below(pts: PackedVector2Array, h: float, col: Color) -> void:
	var poly := PackedVector2Array(pts)
	poly.append(Vector2(pts[pts.size() - 1].x, h + 4.0))
	poly.append(Vector2(pts[0].x, h + 4.0))
	draw_colored_polygon(poly, col)


func _camel(c: Vector2, s: float, step: float, col: Color) -> void:
	var body := PackedVector2Array([c + Vector2(-0.55, -0.62) * s, c + Vector2(0.5, -0.62) * s, c + Vector2(0.62, -0.38) * s, c + Vector2(-0.6, -0.34) * s])
	draw_colored_polygon(body, col)
	draw_circle(c + Vector2(-0.12, -0.78) * s, 0.2 * s, col)  # hump
	draw_colored_polygon(PackedVector2Array([c + Vector2(0.42, -0.6) * s, c + Vector2(0.62, -0.66) * s, c + Vector2(0.86, -1.08) * s, c + Vector2(0.72, -1.12) * s]), col)  # neck
	draw_colored_polygon(PackedVector2Array([c + Vector2(0.7, -1.1) * s, c + Vector2(0.98, -1.12) * s, c + Vector2(1.06, -1.0) * s, c + Vector2(0.78, -0.98) * s]), col)  # head
	for i in 4:
		var lx: float = [-0.46, -0.3, 0.3, 0.46][i]
		var sw := sin(step + float(i) * 1.6) * 0.1
		draw_line(c + Vector2(lx, -0.36) * s, c + Vector2(lx + sw, 0.0) * s, col, maxf(2.0, 0.07 * s))
	draw_line(c + Vector2(-0.58, -0.5) * s, c + Vector2(-0.72, -0.22) * s, col, maxf(1.5, 0.05 * s))  # tail


func _walker(c: Vector2, s: float, step: float, col: Color) -> void:
	draw_colored_polygon(PackedVector2Array([c + Vector2(-0.18, -0.9) * s, c + Vector2(0.18, -0.9) * s, c + Vector2(0.3, 0.0) * s, c + Vector2(-0.3, 0.0) * s]), col)
	draw_circle(c + Vector2(0, -1.02) * s, 0.14 * s, col)
	draw_line(c + Vector2(0.28, -0.8) * s, c + Vector2(0.34 + sin(step) * 0.04, 0.1) * s, col, maxf(1.5, 0.05 * s))  # staff


func _draw() -> void:
	var w := size.x
	var h := size.y
	if w < 4.0 or h < 4.0:
		return
	# --- sky gradient
	var bands := 36
	for i in bands:
		var u := float(i) / float(bands - 1)
		var col: Color
		if u < 0.5:
			col = Pal.OBSIDIAN.lerp(Pal.MIDNIGHT_LIGHT, u / 0.5)
		elif u < 0.78:
			col = Pal.MIDNIGHT_LIGHT.lerp(Color("5a3a52"), (u - 0.5) / 0.28)
		else:
			col = Color("5a3a52").lerp(Color("d9803a"), (u - 0.78) / 0.22)
		draw_rect(Rect2(0, h * float(i) / float(bands) * 0.78, w, h * 0.78 / float(bands) + 1.0), col)
	draw_rect(Rect2(0, h * 0.78, w, h * 0.22 + 2.0), Color("d9803a"))
	# --- stars
	for s in _stars:
		var tw := 0.55 + 0.45 * sin(_t * float(s[4]) + float(s[3]))
		var a := tw * (1.0 - clampf(float(s[1]) / 0.6, 0.0, 1.0) * 0.7)
		draw_circle(Vector2(float(s[0]) * w, float(s[1]) * h), float(s[2]) * 0.9, Color(0.9, 0.95, 1.0, a))
	# --- moon
	var mc := Vector2(w * 0.86, h * 0.3)
	var mr := h * 0.075
	for k in 6:
		draw_circle(mc, mr * (1.5 + k * 0.55), Color(0.5, 0.82, 0.85, 0.045 - k * 0.006))
	draw_circle(mc, mr, Color("e8f4f2"))
	draw_circle(mc + Vector2(-0.3, -0.2) * mr, mr * 0.2, Color("c6dcdc"))
	draw_circle(mc + Vector2(0.35, 0.25) * mr, mr * 0.28, Color("cfe2e0"))
	draw_circle(mc + Vector2(0.1, -0.5) * mr, mr * 0.12, Color("c6dcdc"))
	draw_arc(mc, mr, 0, TAU, 48, Color(0.25, 0.82, 0.8, 0.5), 2.0, true)
	# --- city silhouette on the horizon
	var hy := h * 0.66
	var cc := Color("151b33")
	for b in _city:
		var bx: float = float(b[0]) * w
		var bw: float = float(b[1]) * w
		var bh: float = float(b[2]) * h
		match int(b[3]):
			1:
				draw_rect(Rect2(bx, hy - bh * 0.6, bw, bh * 0.6 + 2), cc)
				var pts := PackedVector2Array()
				for i in 11:
					var a := PI + PI * float(i) / 10.0
					pts.append(Vector2(bx + bw * 0.5 + cos(a) * bw * 0.55, hy - bh * 0.6 + sin(a) * bw * 0.6))
				draw_colored_polygon(pts, cc)
				draw_line(Vector2(bx + bw * 0.5, hy - bh * 0.6 - bw * 0.6), Vector2(bx + bw * 0.5, hy - bh * 0.6 - bw * 0.95), cc, 2.0)
			2:
				draw_rect(Rect2(bx + bw * 0.3, hy - bh * 1.3, bw * 0.4, bh * 1.3 + 2), cc)
				draw_colored_polygon(PackedVector2Array([Vector2(bx + bw * 0.25, hy - bh * 1.3), Vector2(bx + bw * 0.75, hy - bh * 1.3), Vector2(bx + bw * 0.5, hy - bh * 1.3 - bw * 0.7)]), cc)
			3:
				draw_rect(Rect2(bx, hy - bh * 0.5, bw, bh * 0.5 + 2), cc)
				draw_rect(Rect2(bx + bw * 0.15, hy - bh * 0.8, bw * 0.7, bh * 0.3), cc)
				draw_rect(Rect2(bx + bw * 0.3, hy - bh * 1.0, bw * 0.4, bh * 0.2), cc)
			_:
				draw_rect(Rect2(bx, hy - bh, bw, bh + 2), cc)
		if float(b[4]) > 0.55:
			draw_rect(Rect2(bx + bw * 0.38, hy - bh * 0.42, maxf(2.0, bw * 0.12), maxf(2.0, bw * 0.16)), Color(1.0, 0.72, 0.35, 0.55 + 0.25 * sin(_t * 1.3 + float(b[0]) * 20.0)))
	draw_rect(Rect2(0, hy, w, h - hy), cc)
	# --- far dunes (with a warm rim line)
	var far := _dune(w, h * 0.72, h * 0.035, 7.0, 15.0, 0.6, 0.0)
	_fill_below(far, h, Color("1b1f3a"))
	draw_polyline(far, Color(0.85, 0.5, 0.25, 0.28), 2.0, true)
	# --- mid dunes, with the caravan walking along their crest
	var mid := _dune(w, h * 0.80, h * 0.045, 5.0, 11.0, 2.1, 0.0)
	_fill_below(mid, h, Color("12142a"))
	if show_caravan:
		var span := w * 1.3
		var base_x := fposmod(_t * 14.0, span) - w * 0.15
		var dark := Color("07080d")
		for i in 5:
			var px := base_x - float(i) * h * 0.2
			if px < -60.0 or px > w + 60.0:
				continue
			var u := clampf(px / w, 0.0, 1.0)
			var gy := h * 0.80 + sin(u * 5.0 + 2.1) * h * 0.045 + sin(u * 11.0 + 2.1 * 1.7) * h * 0.045 * 0.45
			var st := _t * 3.2 + float(i)
			if i % 2 == 0:
				_camel(Vector2(px, gy + 2.0), h * 0.085, st, dark)
			else:
				_walker(Vector2(px, gy + 2.0), h * 0.07, st, dark)
	# --- near dunes
	var near := _dune(w, h * 0.90, h * 0.05, 4.0, 9.0, 4.0, 0.0)
	_fill_below(near, h, Color("08090f"))
	# --- dust motes
	for m in _motes:
		var px := fposmod(float(m[0]) * w + _t * float(m[3]), w)
		var py := h * (0.45 + float(m[1]) * 0.5) + sin(_t * 0.7 + float(m[1]) * 9.0) * 6.0
		draw_circle(Vector2(px, py), float(m[2]), Color(0.95, 0.78, 0.5, 0.18))
	# --- vignette + optional dim
	for i in 8:
		var a := 0.07 * float(8 - i) / 8.0
		draw_rect(Rect2(0, 0, w, h * 0.04 * float(i + 1) / 2.0), Color(0, 0, 0, a * 0.5))
	draw_rect(Rect2(0, h - h * 0.06, w, h * 0.06), Color(0, 0, 0, 0.35))
	if dim > 0.0:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.02, 0.04, dim))
