extends Control
## New game flow: story pages, character introduction card, controls primer, then the game.

const Pal := preload("res://scripts/data/pal.gd")
const UI := preload("res://scripts/ui/ui_kit.gd")
const Icons := preload("res://scripts/ui/icons.gd")
const Backdrop := preload("res://scripts/ui/backdrop.gd")
const Frame := preload("res://scripts/ui/frame.gd")

const PAGES := 3

var _page := 0
var _holder: Control
var _next: Button
var _back: Button
var _backdrop: Control
var _busy := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	Controls.enabled = true
	_backdrop = Backdrop.new()
	_backdrop.show_caravan = false
	add_child(_backdrop)
	_holder = Control.new()
	_holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(_holder)

	var bar := HBoxContainer.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	bar.offset_top = -110
	bar.offset_left = 70
	bar.offset_right = -70
	bar.offset_bottom = -26
	bar.add_theme_constant_override("separation", 20)
	add_child(bar)
	_back = UI.button("Back", "", "normal", Vector2(220, 70))
	_back.pressed.connect(func(): _go_page(_page - 1))
	bar.add_child(_back)
	var skip := UI.button("Skip", "", "ghost", Vector2(180, 70))
	skip.pressed.connect(_begin)
	bar.add_child(skip)
	bar.add_child(UI.hfill())
	_next = UI.button("Next", "arrow_up", "primary", Vector2(300, 70))
	_next.pressed.connect(func(): _go_page(_page + 1))
	bar.add_child(_next)
	Controls.back_pressed.connect(_on_back)
	_show_page()


func _exit_tree() -> void:
	if Controls.back_pressed.is_connected(_on_back):
		Controls.back_pressed.disconnect(_on_back)


func _on_back() -> void:
	if _page > 0:
		_go_page(_page - 1)
	else:
		Router.go("res://scenes/main_menu.tscn")


func _go_page(i: int) -> void:
	if _busy:
		return
	if i >= PAGES:
		_begin()
		return
	if i < 0:
		Router.go("res://scenes/main_menu.tscn")
		return
	_page = i
	AudioMgr.play("ui_open", -8.0)
	_show_page()


func _show_page() -> void:
	for c in _holder.get_children():
		c.queue_free()
	_back.text = "Menu" if _page == 0 else "Back"
	_next.text = "Begin Journey" if _page == PAGES - 1 else "Next"
	_backdrop.set("dim", 0.45)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_bottom = -120
	_holder.add_child(center)
	match _page:
		0:
			center.add_child(_story_page())
		1:
			center.add_child(_character_page())
		2:
			center.add_child(_controls_page())
	_holder.modulate.a = 0.0
	create_tween().tween_property(_holder, "modulate:a", 1.0, 0.35)


func _story_page() -> Control:
	var f := UI.frame(0.9, 40)
	f.custom_minimum_size = Vector2(1020, 500)
	var v: VBoxContainer = f.content
	v.add_child(UI.title("The Sunsea Remembers", 54, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UI.divider(20))
	var txt := "For a thousand years the Sunsea has swallowed caravans whole. Wagons, camels, lantern-bearers - gone between one dusk and the next.\n\nYour own caravan vanished three nights ago, leaving only a cold fire and a humming shard of black glass.\n\nElder Sahir says the shards are keys to the Ancient Gate, and beyond the gate lies the road the lost caravans took."
	var l := UI.label(txt, 25, Pal.TEXT, HORIZONTAL_ALIGNMENT_CENTER, true)
	l.size_flags_vertical = Control.SIZE_EXPAND_FILL
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	v.add_child(l)
	return f


func _character_page() -> Control:
	var f := UI.frame(0.9, 36)
	f.custom_minimum_size = Vector2(1000, 520)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 36)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	f.content.add_child(row)
	var portrait := _Portrait.new()
	portrait.custom_minimum_size = Vector2(300, 400)
	portrait.clip_contents = true
	portrait.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(portrait)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(v)
	v.add_child(UI.title("Rahil", 56, Pal.GOLD_LIGHT))
	v.add_child(UI.label("LAST GUARD OF THE SHADOW CARAVAN", 22, Pal.TURQUOISE))
	v.add_child(UI.divider(18))
	v.add_child(UI.label("A scimitar-bearer who walked the night roads before the caravan was lost. Quick on the roll, patient with the blade, and sworn to bring everyone home.", 24, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true))
	var stats := GridContainer.new()
	stats.columns = 2
	stats.add_theme_constant_override("h_separation", 40)
	stats.add_theme_constant_override("v_separation", 6)
	for kv in [["Health", "100"], ["Stamina", "100"], ["Weapon", "Worn Scimitar"], ["Skill", "Dodge roll"]]:
		stats.add_child(UI.label(kv[0], 22, Pal.TEXT_DIM))
		stats.add_child(UI.label(kv[1], 22, Pal.GOLD_LIGHT))
	v.add_child(stats)
	return f


func _controls_page() -> Control:
	var f := UI.frame(0.9, 36)
	f.custom_minimum_size = Vector2(1040, 500)
	var v: VBoxContainer = f.content
	v.add_child(UI.title("How to Survive the Dunes", 50, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UI.divider(20))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 60)
	grid.add_theme_constant_override("v_separation", 10)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(grid)
	var tips := [
		["joystick", "Left thumb: floating joystick to move. Push to the rim to run."],
		["eye", "Right thumb: drag on empty screen to look around."],
		["sword", "Attack: swing the scimitar. Time your hits."],
		["roll", "Dodge: a roll with a brief invulnerable window."],
		["interact", "Interact: chests, relics, tents, gates and people."],
		["sprint", "Sprint (hold): faster, but drains stamina."],
	]
	for t in tips:
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 14)
		h.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(UI.icon(t[0], 52, Pal.GOLD_LIGHT, true))
		var l := UI.label(t[1], 23, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true)
		l.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(l)
		grid.add_child(h)
	var k := UI.label("Keyboard (desktop): WASD move, right-mouse drag look, J attack, K dodge, Space jump, E interact, Esc pause.", 20, Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER, true)
	v.add_child(k)
	return f


func _begin() -> void:
	if _busy:
		return
	_busy = true
	GameState.intro_seen = true
	GameState.save_game()
	Router.go("res://scenes/game.tscn", "The road north begins...")


class _Portrait extends Control:
	func _draw() -> void:
		var r := Rect2(Vector2.ZERO, size)
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color("0f1830")
		sb.border_color = Color("c9a24b")
		sb.set_border_width_all(3)
		sb.set_corner_radius_all(12)
		draw_style_box(sb, r)
		var c := Vector2(size.x * 0.5, size.y * 0.58)
		# moon halo
		draw_circle(Vector2(size.x * 0.5, size.y * 0.33), size.x * 0.28, Color(0.5, 0.85, 0.88, 0.1))
		draw_circle(Vector2(size.x * 0.5, size.y * 0.33), size.x * 0.2, Color(0.9, 0.96, 0.95, 0.9))
		# cloak
		draw_colored_polygon(PackedVector2Array([c + Vector2(-110, 190), c + Vector2(-70, -10), c + Vector2(-34, -60), c + Vector2(34, -60), c + Vector2(70, -10), c + Vector2(110, 190)]), Color("0a0b10"))
		draw_colored_polygon(PackedVector2Array([c + Vector2(0, -50), c + Vector2(70, -10), c + Vector2(110, 190), c + Vector2(30, 190)]), Color("141a30"))
		# head scarf
		draw_circle(c + Vector2(0, -92), 50, Color("0a0b10"))
		draw_circle(c + Vector2(0, -90), 42, Color("d9c39a"))
		draw_colored_polygon(PackedVector2Array([c + Vector2(-46, -92), c + Vector2(46, -92), c + Vector2(40, -62), c + Vector2(-40, -62)]), Color("1b2a50"))
		draw_rect(Rect2(c + Vector2(-26, -102), Vector2(52, 8)), Color("0a0b10"))
		draw_circle(c + Vector2(-12, -98), 4.0, Color("3fd0c9"))
		draw_circle(c + Vector2(12, -98), 4.0, Color("3fd0c9"))
		# gold trim and sword
		draw_line(c + Vector2(-34, -58), c + Vector2(-100, 188), Color("c9a24b"), 3.0)
		draw_line(c + Vector2(34, -58), c + Vector2(100, 188), Color("c9a24b"), 3.0)
		draw_line(c + Vector2(80, 150), c + Vector2(120, 20), Color("d8e4ea"), 6.0)
		draw_line(c + Vector2(66, 132), c + Vector2(96, 144), Color("c9a24b"), 6.0)
