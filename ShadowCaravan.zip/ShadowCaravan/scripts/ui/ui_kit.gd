extends RefCounted
## UI factory: theme, buttons (normal/primary/danger/tab/ghost), labels, dividers, bars.
## All visuals are drawn from StyleBoxFlat + procedural ornaments - no image assets needed.

const Pal := preload("res://scripts/data/pal.gd")
const Ornament := preload("res://scripts/ui/ornament.gd")
const Frame := preload("res://scripts/ui/frame.gd")
const IconView := preload("res://scripts/ui/icon_view.gd")

const TITLE_FONT := "res://assets/fonts/STIXGeneralBol.ttf"
const SERIF_FONT := "res://assets/fonts/STIXGeneral.ttf"

static var _theme: Theme
static var _title_font: Font
static var _serif_font: Font
static var _tex_cache: Dictionary = {}


static func title_font() -> Font:
	if _title_font == null:
		var f: Variant = load(TITLE_FONT)
		_title_font = f if f is Font else ThemeDB.fallback_font
	return _title_font


static func serif_font() -> Font:
	if _serif_font == null:
		var f: Variant = load(SERIF_FONT)
		_serif_font = f if f is Font else ThemeDB.fallback_font
	return _serif_font


static func box(bg: Color, border: Color = Color(0, 0, 0, 0), bw: int = 0, radius: int = 8, shadow: int = 0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	if shadow > 0:
		s.shadow_size = shadow
		s.shadow_color = Color(0, 0, 0, 0.45)
		s.shadow_offset = Vector2(0, 3)
	return s


static func circle_tex(col: Color, px: int = 40) -> Texture2D:
	var key := "c%s_%d" % [col.to_html(), px]
	if _tex_cache.has(key):
		return _tex_cache[key]
	var img := Image.create(px, px, false, Image.FORMAT_RGBA8)
	var c := (px - 1) * 0.5
	for y in px:
		for x in px:
			var d := Vector2(x - c, y - c).length()
			var a := clampf(c + 0.5 - d, 0.0, 1.0)
			var rim := clampf((d - (c - 3.0)) / 3.0, 0.0, 1.0)
			var cc := col.lerp(Pal.GOLD_LIGHT, rim * 0.6)
			img.set_pixel(x, y, Color(cc.r, cc.g, cc.b, a))
	var tex := ImageTexture.create_from_image(img)
	_tex_cache[key] = tex
	return tex


static func theme() -> Theme:
	if _theme != null:
		return _theme
	var t := Theme.new()
	t.default_font_size = 24
	# Labels
	t.set_color("font_color", "Label", Pal.TEXT)
	t.set_color("font_shadow_color", "Label", Color(0, 0, 0, 0.55))
	t.set_constant("shadow_offset_x", "Label", 1)
	t.set_constant("shadow_offset_y", "Label", 2)
	t.set_font_size("font_size", "Label", 24)
	# Buttons (default look == "normal" kind)
	_style_button_theme(t)
	# Sliders
	t.set_stylebox("slider", "HSlider", box(Pal.OBSIDIAN, Pal.GOLD_DARK, 2, 6))
	t.set_stylebox("grabber_area", "HSlider", box(Pal.GOLD_DARK, Color(0, 0, 0, 0), 0, 6))
	t.set_stylebox("grabber_area_highlight", "HSlider", box(Pal.GOLD, Color(0, 0, 0, 0), 0, 6))
	t.set_icon("grabber", "HSlider", circle_tex(Pal.GOLD, 44))
	t.set_icon("grabber_highlight", "HSlider", circle_tex(Pal.GOLD_LIGHT, 44))
	t.set_icon("grabber_disabled", "HSlider", circle_tex(Pal.DISABLED, 44))
	t.set_constant("center_grabber", "HSlider", 0)
	# Scrollbars
	t.set_stylebox("scroll", "VScrollBar", box(Color(0, 0, 0, 0.35), Color(0, 0, 0, 0), 0, 6))
	t.set_stylebox("grabber", "VScrollBar", box(Pal.GOLD_DARK, Color(0, 0, 0, 0), 0, 6))
	t.set_stylebox("grabber_highlight", "VScrollBar", box(Pal.GOLD, Color(0, 0, 0, 0), 0, 6))
	t.set_stylebox("grabber_pressed", "VScrollBar", box(Pal.TURQUOISE_DIM, Color(0, 0, 0, 0), 0, 6))
	# Progress bars
	t.set_stylebox("background", "ProgressBar", box(Pal.OBSIDIAN, Pal.GOLD_DARK, 2, 5))
	t.set_stylebox("fill", "ProgressBar", box(Pal.TURQUOISE_DIM, Color(0, 0, 0, 0), 0, 4))
	_theme = t
	return t


static func _btn_styles(kind: String) -> Dictionary:
	var d := {}
	match kind:
		"primary":
			d["normal"] = box(Color("5a4416"), Pal.GOLD, 2, 9, 8)
			d["hover"] = box(Color("6e5320"), Pal.GOLD_LIGHT, 2, 9, 8)
			d["pressed"] = box(Color("3a2c0d"), Pal.TURQUOISE, 3, 9, 2)
			d["disabled"] = box(Color(0.08, 0.08, 0.09, 0.9), Pal.DISABLED, 2, 9)
			d["font"] = Pal.GOLD_LIGHT
		"danger":
			d["normal"] = box(Color("3b1519"), Pal.BLOOD, 2, 9, 6)
			d["hover"] = box(Color("52191f"), Color("e5605c"), 2, 9, 6)
			d["pressed"] = box(Color("23090c"), Pal.TURQUOISE, 3, 9, 2)
			d["disabled"] = box(Color(0.08, 0.08, 0.09, 0.9), Pal.DISABLED, 2, 9)
			d["font"] = Color("f2b3ae")
		"tab":
			d["normal"] = box(Color(0.06, 0.08, 0.14, 0.9), Pal.GOLD_DARK, 2, 9)
			d["hover"] = box(Color(0.1, 0.14, 0.24, 0.95), Pal.GOLD, 2, 9)
			d["pressed"] = box(Pal.MIDNIGHT_LIGHT, Pal.TURQUOISE, 3, 9, 4)
			d["disabled"] = box(Color(0.08, 0.08, 0.09, 0.9), Pal.DISABLED, 2, 9)
			d["font"] = Pal.TEXT
		"ghost":
			d["normal"] = box(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 0, 9)
			d["hover"] = box(Color(1, 1, 1, 0.06), Color(0, 0, 0, 0), 0, 9)
			d["pressed"] = box(Color(1, 1, 1, 0.12), Color(0, 0, 0, 0), 0, 9)
			d["disabled"] = box(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 0, 9)
			d["font"] = Pal.SAND
		_:
			d["normal"] = box(Color(0.07, 0.10, 0.19, 0.95), Pal.GOLD_DARK, 2, 9, 6)
			d["hover"] = box(Color(0.11, 0.16, 0.29, 0.97), Pal.GOLD, 2, 9, 6)
			d["pressed"] = box(Color(0.04, 0.06, 0.11, 1.0), Pal.TURQUOISE, 3, 9, 2)
			d["disabled"] = box(Color(0.08, 0.08, 0.09, 0.9), Pal.DISABLED, 2, 9)
			d["font"] = Pal.TEXT
	for k in ["normal", "hover", "pressed", "disabled"]:
		var sb: StyleBoxFlat = d[k]
		sb.content_margin_left = 20
		sb.content_margin_right = 20
		sb.content_margin_top = 10
		sb.content_margin_bottom = 12
	return d


static func _style_button_theme(t: Theme) -> void:
	var d := _btn_styles("normal")
	t.set_stylebox("normal", "Button", d["normal"])
	t.set_stylebox("hover", "Button", d["hover"])
	t.set_stylebox("pressed", "Button", d["pressed"])
	t.set_stylebox("disabled", "Button", d["disabled"])
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Pal.TEXT)
	t.set_color("font_hover_color", "Button", Pal.GOLD_LIGHT)
	t.set_color("font_pressed_color", "Button", Pal.TURQUOISE)
	t.set_color("font_disabled_color", "Button", Pal.DISABLED)
	t.set_font_size("font_size", "Button", 26)


## Creates a styled Button. kind: normal | primary | danger | tab | ghost.
static func button(text: String, icon: String = "", kind: String = "normal", min_size: Vector2 = Vector2(220, 68)) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var d := _btn_styles(kind)
	var pad := 62 if icon != "" else 20
	for k in ["normal", "hover", "pressed", "disabled"]:
		var sb: StyleBoxFlat = d[k]
		if icon != "":
			sb.content_margin_left = pad
		b.add_theme_stylebox_override(k, sb)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var fc: Color = d["font"]
	b.add_theme_color_override("font_color", fc)
	b.add_theme_color_override("font_hover_color", Pal.GOLD_LIGHT if kind != "danger" else Color("ffd3cf"))
	b.add_theme_color_override("font_pressed_color", Pal.TURQUOISE)
	b.add_theme_color_override("font_disabled_color", Pal.DISABLED)
	b.add_theme_font_size_override("font_size", 26)
	if kind == "tab":
		b.toggle_mode = true
	if kind != "ghost":
		var o := Ornament.new("button")
		o.icon_id = icon
		o.icon_tint = fc
		b.add_child(o)
	elif icon != "":
		var o2 := Ornament.new("button")
		o2.icon_id = icon
		o2.icon_tint = Pal.SAND
		o2.sheen = false
		b.add_child(o2)
	return b


static func label(text: String, size: int = 24, color: Color = Pal.TEXT, align: int = HORIZONTAL_ALIGNMENT_LEFT, wrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align as HorizontalAlignment
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


static func title(text: String, size: int = 44, color: Color = Pal.GOLD_LIGHT, align: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := label(text, size, color, align)
	l.add_theme_font_override("font", title_font())
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.75))
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 3)
	return l


static func divider(height: float = 18.0, col: Color = Pal.GOLD) -> Control:
	var o := Ornament.new("divider")
	o.tint = col
	o.custom_minimum_size = Vector2(0, height)
	o.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return o


static func spacer(h: float = 8.0) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


static func hfill() -> Control:
	var c := Control.new()
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


static func icon(id: String, size: float = 48.0, col: Color = Pal.GOLD_LIGHT, framed: bool = false) -> Control:
	var v := IconView.new(id, size)
	v.tint = col
	v.framed = framed
	return v


static func scroll() -> ScrollContainer:
	var s := ScrollContainer.new()
	s.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	s.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	s.size_flags_vertical = Control.SIZE_EXPAND_FILL
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return s


static func pad(node: Control, l: int, t: int, r: int, b: int) -> MarginContainer:
	var m := MarginContainer.new()
	m.add_theme_constant_override("margin_left", l)
	m.add_theme_constant_override("margin_top", t)
	m.add_theme_constant_override("margin_right", r)
	m.add_theme_constant_override("margin_bottom", b)
	m.add_child(node)
	return m


static func frame(bg_alpha: float = 0.96, margin: int = 30) -> Control:
	return Frame.new(bg_alpha, margin)
