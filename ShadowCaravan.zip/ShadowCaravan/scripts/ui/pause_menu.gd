extends "res://scripts/ui/panel_base.gd"
## Pause menu: resume, shortcuts to every screen, settings, return to camp, restart, quit.

signal action(id: String)


func _init() -> void:
	super("Paused", Vector2(920, 640))


func _build() -> void:
	var resume := UI.button("Resume", "arrow_up", "primary", Vector2(0, 72))
	resume.pressed.connect(close)
	body.add_child(resume)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 16)
	grid.add_theme_constant_override("v_separation", 12)
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(grid)
	var defs := [
		["inventory", "Inventory", "pack", "normal"],
		["journal", "Quest Journal", "book", "normal"],
		["map", "World Map", "map", "normal"],
		["skills", "Skills & Upgrades", "star", "normal"],
		["settings", "Settings", "gear", "normal"],
		["camp", "Return to Camp", "camp", "normal"],
		["restart", "Restart from Save", "roll", "normal"],
		["menu", "Save & Main Menu", "home", "danger"],
	]
	for d in defs:
		var b := UI.button(String(d[1]), String(d[2]), String(d[3]), Vector2(0, 66))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.add_theme_font_size_override("font_size", 24)
		b.pressed.connect(func(): action.emit(String(d[0])))
		grid.add_child(b)
	body.add_child(UI.hfill())
	body.add_child(UI.label("Progress is saved automatically at waystones, camp, and when the app is backgrounded.", 20, Pal.TEXT_DIM, HORIZONTAL_ALIGNMENT_CENTER, true))
