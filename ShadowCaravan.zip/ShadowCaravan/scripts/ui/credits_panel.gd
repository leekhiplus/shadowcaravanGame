extends "res://scripts/ui/panel_base.gd"
## Credits and licence summary.


func _init() -> void:
	super("Credits", Vector2(980, 640))


func _build() -> void:
	var sc := UI.scroll()
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(v)
	body.add_child(sc)
	var entries := [
		["SHADOW CARAVAN", ""],
		["Design, code, procedural art and audio", "Zafronix Studios"],
		["Engine", "Godot Engine 4.3 (MIT licence) - godotengine.org"],
		["Typeface (titles and serif text)", "STIX General, STI Pub Companies (SIL Open Font License 1.1)"],
		["Body typeface", "The default Godot UI font (Open Sans, SIL OFL / Apache 2.0, bundled in the engine)"],
		["Music, ambience and sound effects", "Synthesised by tools/generate_audio.py. Original works, MIT licence."],
		["3D models, icons, terrain and sky", "Generated in code at runtime. No third-party art is bundled."],
		["Thank you for playing", "May your lanterns stay lit."],
	]
	for e in entries:
		if e[1] == "":
			v.add_child(UI.title(e[0], 40, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER))
			v.add_child(UI.divider(18))
			continue
		v.add_child(UI.label(e[0], 22, Pal.TURQUOISE, HORIZONTAL_ALIGNMENT_CENTER))
		v.add_child(UI.label(e[1], 25, Pal.TEXT, HORIZONTAL_ALIGNMENT_CENTER, true))
		v.add_child(UI.spacer(6))
	var done := UI.button("Close", "check", "primary", Vector2(260, 66))
	done.pressed.connect(close)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_child(done)
	body.add_child(row)
