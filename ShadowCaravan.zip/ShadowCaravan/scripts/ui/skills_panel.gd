extends "res://scripts/ui/panel_base.gd"
## Skill & upgrade screen. Spending is only possible at the camp (game.is_at_camp()).

const UpgradeView := preload("res://scripts/ui/upgrade_view.gd")

var game: Node
var _view: Control


func _init() -> void:
	super("Skills & Upgrades", Vector2(1120, 640))


func _build() -> void:
	_view = UpgradeView.new()
	body.add_child(_view)


func refresh() -> void:
	if _view == null:
		return
	_view.at_camp = game != null and game.has_method("is_at_camp") and game.is_at_camp()
	_view.refresh()
