extends Control
## Base class for every modal screen (inventory, journal, map, settings, ...).
## Subclasses call super("Title", size) in _init() and override _build() / refresh().
## _build() runs once from _ready(); refresh() runs every time the panel opens.

const Pal := preload("res://scripts/data/pal.gd")
const UI := preload("res://scripts/ui/ui_kit.gd")

signal closed

var title_text := ""
var panel_size := Vector2(1060, 620)
var closable := true
var dim_alpha := 0.66

var frame: Control
var body: VBoxContainer
var title_label: Label
var close_button: Button
var is_open := false


func _init(p_title: String = "", p_size: Vector2 = Vector2(1060, 620), p_closable: bool = true) -> void:
	title_text = p_title
	panel_size = p_size
	closable = p_closable
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _ready() -> void:
	var dim := ColorRect.new()
	dim.color = Color(0.01, 0.01, 0.03, dim_alpha)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	frame = UI.frame(0.97, 30)
	frame.custom_minimum_size = panel_size
	frame.pivot_offset = panel_size * 0.5
	center.add_child(frame)
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 12)
	frame.content.add_child(header)
	title_label = UI.title(title_text, 44)
	title_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	header.add_child(title_label)
	header.add_child(UI.hfill())
	_build_header_extra(header)
	if closable:
		close_button = UI.button("", "close", "ghost", Vector2(70, 62))
		close_button.pressed.connect(close)
		header.add_child(close_button)
	frame.content.add_child(UI.divider(18))
	body = VBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	frame.content.add_child(body)
	_build()


func _build_header_extra(_header: HBoxContainer) -> void:
	pass


func _build() -> void:
	pass


func refresh() -> void:
	pass


func open() -> void:
	refresh()
	visible = true
	is_open = true
	frame.modulate.a = 0.0
	frame.scale = Vector2(0.95, 0.95)
	var tw := create_tween().set_parallel(true)
	tw.tween_property(frame, "modulate:a", 1.0, 0.16)
	tw.tween_property(frame, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	AudioMgr.play("ui_open", -8.0)


func close() -> void:
	if not is_open:
		return
	is_open = false
	visible = false
	AudioMgr.play("ui_back", -8.0)
	closed.emit()


## Called by the UI layer for the Android back button / Escape. Return true if handled.
func on_back() -> bool:
	if closable:
		close()
		return true
	return false
