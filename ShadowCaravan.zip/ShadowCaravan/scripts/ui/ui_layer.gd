extends CanvasLayer
## Owns the HUD, the touch controls and every modal screen of the game scene.
## While any modal is open the world is paused and touch controls are disabled.

const Hud := preload("res://scripts/ui/hud.gd")
const TouchControls := preload("res://scripts/ui/touch_controls.gd")
const PauseMenu := preload("res://scripts/ui/pause_menu.gd")
const InventoryPanel := preload("res://scripts/ui/inventory_panel.gd")
const JournalPanel := preload("res://scripts/ui/journal_panel.gd")
const MapPanel := preload("res://scripts/ui/map_panel.gd")
const SkillsPanel := preload("res://scripts/ui/skills_panel.gd")
const SettingsPanel := preload("res://scripts/ui/settings_panel.gd")
const CampPanel := preload("res://scripts/ui/camp_panel.gd")
const PuzzlePanel := preload("res://scripts/ui/puzzle_panel.gd")
const DialoguePanel := preload("res://scripts/ui/dialogue_panel.gd")
const EndScreen := preload("res://scripts/ui/end_screen.gd")
const ConfirmDialog := preload("res://scripts/ui/confirm_dialog.gd")

signal puzzle_solved
signal end_choice(id: String)

var game: Node
var hud: Control
var touch: Control
var panels: Dictionary = {}
var _return_to_pause := false
var _priority := ["confirm", "end", "dialogue", "puzzle", "camp", "settings", "skills", "map", "journal", "inventory", "pause"]


func setup(game_node: Node) -> void:
	game = game_node
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	hud = Hud.new()
	hud.game = game
	add_child(hud)
	touch = TouchControls.new()
	add_child(touch)
	touch.menu_tapped.connect(_on_menu_tapped)
	for pair in [["pause", PauseMenu.new()], ["inventory", InventoryPanel.new()], ["journal", JournalPanel.new()],
			["map", MapPanel.new()], ["skills", SkillsPanel.new()], ["settings", SettingsPanel.new()],
			["camp", CampPanel.new()], ["puzzle", PuzzlePanel.new()], ["dialogue", DialoguePanel.new()],
			["end", EndScreen.new()], ["confirm", ConfirmDialog.new()]]:
		var p: Control = pair[1]
		panels[pair[0]] = p
		if "game" in p:
			p.set("game", game)
		add_child(p)
		p.closed.connect(_on_closed.bind(String(pair[0])))
	panels.pause.action.connect(_on_pause_action)
	panels.settings.set_confirm(panels.confirm)
	panels.settings.save_reset.connect(func(): GameState.toast.emit("Save deleted. Your current session continues.", "warn"))
	panels.map.travel_requested.connect(func(id: String): game.travel_to(id))
	panels.puzzle.solved.connect(func(): puzzle_solved.emit())
	panels.end.choice.connect(func(id: String): end_choice.emit(id))
	Controls.back_pressed.connect(_on_back)
	Controls.map_pressed.connect(_toggle.bind("map"))
	Controls.inventory_pressed.connect(_toggle.bind("inventory"))
	Controls.journal_pressed.connect(_toggle.bind("journal"))


func _exit_tree() -> void:
	for sig in [Controls.back_pressed, Controls.map_pressed, Controls.inventory_pressed, Controls.journal_pressed]:
		for c in sig.get_connections():
			if c.callable.get_object() == self:
				sig.disconnect(c.callable)
	get_tree().paused = false
	Controls.enabled = true
	Controls.reset_touch()


func is_modal_open() -> bool:
	for k in panels:
		if panels[k].is_open:
			return true
	return false


func is_open(id: String) -> bool:
	return panels[id].is_open


func _sync() -> void:
	var any := is_modal_open()
	if any != get_tree().paused:
		get_tree().paused = any
	Controls.enabled = not any
	touch.visible = not any
	if any:
		touch.release_all()
		hud.visible = true


func _hide_others(except: String) -> void:
	for k in panels:
		if k != except and panels[k].is_open:
			panels[k].is_open = false
			panels[k].visible = false


func open_panel(id: String, from_pause: bool = false) -> void:
	_return_to_pause = from_pause
	_hide_others(id)
	match id:
		"map":
			panels.map.open_map(false)
		_:
			panels[id].open()
	_sync()


func open_map_travel() -> void:
	_return_to_pause = false
	_hide_others("map")
	panels.map.open_map(true)
	_sync()


func open_camp(tab: String) -> void:
	_return_to_pause = false
	_hide_others("camp")
	panels.camp.open_tab(tab)
	_sync()


func show_dialogue(speaker: String, pages: Array, final_label: String, on_done: Callable, closable_early: bool = true) -> void:
	_return_to_pause = false
	_hide_others("dialogue")
	panels.dialogue.show_dialogue(speaker, pages, final_label, on_done, closable_early)
	_sync()


func show_end(kind: String) -> void:
	_return_to_pause = false
	_hide_others("end")
	panels.end.show_kind(kind)
	_sync()


func ask(title: String, text: String, yes_label: String, on_yes: Callable, danger: bool = true) -> void:
	panels.confirm.ask(title, text, yes_label, on_yes, danger)
	_sync()


func close_all() -> void:
	for k in panels:
		if panels[k].is_open:
			panels[k].is_open = false
			panels[k].visible = false
	_return_to_pause = false
	_sync()


func _on_closed(id: String) -> void:
	var back_to_pause := _return_to_pause and id != "pause" and id != "confirm" and not is_modal_open()
	if id == "confirm" and panels.pause.visible == false and _return_to_pause:
		back_to_pause = false
	if back_to_pause:
		_return_to_pause = false
		panels.pause.open()
	_sync()


func _toggle(id: String) -> void:
	if not Controls.enabled and not panels[id].is_open:
		return
	if panels[id].is_open:
		panels[id].close()
	else:
		open_panel(id)


func _on_menu_tapped(id: String) -> void:
	match id:
		"pause":
			open_panel("pause")
		"map":
			open_panel("map")
		"pack":
			open_panel("inventory")
		"journal":
			open_panel("journal")


func _on_back() -> void:
	for k in _priority:
		var p: Control = panels[k]
		if p.is_open:
			p.on_back()
			_sync()
			return
	if game != null and game.has_method("can_pause") and game.can_pause():
		open_panel("pause")


func _on_pause_action(id: String) -> void:
	match id:
		"inventory", "journal", "map", "skills", "settings":
			open_panel(id, true)
		"camp":
			ask("Return to camp?", "You will be carried back to the Caravan Camp. Your progress is kept.", "Return to camp", func(): game.return_to_camp(), false)
		"restart":
			ask("Restart from last save?", "Unsaved progress since your last save will be lost.", "Restart", func(): game.restart_from_save())
		"menu":
			game.quit_to_menu()


func set_prompt(text: String) -> void:
	touch.set_prompt(text)


func set_cooldowns(attack: float, dodge: float) -> void:
	touch.set_cooldown("attack", attack)
	touch.set_cooldown("dodge", dodge)
