extends "res://scripts/ui/panel_base.gd"
## Settings: independent music / effects volume, graphics quality, camera sensitivity,
## invert-Y, haptics, and Reset Save. Works from the main menu and from the pause menu.

signal save_reset

var _music: HSlider
var _sfx: HSlider
var _look: HSlider
var _music_val: Label
var _sfx_val: Label
var _look_val: Label
var _quality_btns: Array[Button] = []
var _invert: Button
var _haptics: Button
var _confirm: Control  # confirm dialog host (set by owner)
var _building := true


func _init() -> void:
	super("Settings", Vector2(1000, 640))


func set_confirm(c: Control) -> void:
	_confirm = c


func _slider_row(icon: String, text: String, lo: float, hi: float, step: float, val: Label) -> HSlider:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	row.add_child(UI.icon(icon, 44, Pal.GOLD_LIGHT))
	var l := UI.label(text, 26, Pal.TEXT)
	l.custom_minimum_size = Vector2(230, 0)
	row.add_child(l)
	var s := HSlider.new()
	s.min_value = lo
	s.max_value = hi
	s.step = step
	s.custom_minimum_size = Vector2(360, 54)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(s)
	val.custom_minimum_size = Vector2(80, 0)
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(val)
	body.add_child(row)
	return s


func _build() -> void:
	_music_val = UI.label("", 26, Pal.GOLD_LIGHT)
	_sfx_val = UI.label("", 26, Pal.GOLD_LIGHT)
	_look_val = UI.label("", 26, Pal.GOLD_LIGHT)
	_music = _slider_row("note", "Music volume", 0.0, 1.0, 0.05, _music_val)
	_sfx = _slider_row("speaker", "Effects volume", 0.0, 1.0, 0.05, _sfx_val)
	_look = _slider_row("gear", "Camera sensitivity", 0.4, 2.5, 0.1, _look_val)
	_music.value_changed.connect(func(v: float):
		GameState.music_volume = v
		_changed())
	_sfx.value_changed.connect(func(v: float):
		GameState.sfx_volume = v
		_changed()
		if not _building:
			AudioMgr.play("coin"))
	_look.value_changed.connect(func(v: float):
		GameState.look_sensitivity = v
		_changed())

	var qrow := HBoxContainer.new()
	qrow.add_theme_constant_override("separation", 14)
	qrow.add_child(UI.icon("star", 44, Pal.GOLD_LIGHT))
	var ql := UI.label("Graphics quality", 26, Pal.TEXT)
	ql.custom_minimum_size = Vector2(230, 0)
	qrow.add_child(ql)
	var names := ["Low", "Medium", "High"]
	for i in 3:
		var b := UI.button(names[i], "", "tab", Vector2(170, 62))
		b.pressed.connect(_set_quality.bind(i))
		qrow.add_child(b)
		_quality_btns.append(b)
	body.add_child(qrow)

	var trow := HBoxContainer.new()
	trow.add_theme_constant_override("separation", 14)
	_invert = UI.button("Invert camera Y: Off", "", "tab", Vector2(420, 62))
	_invert.toggled.connect(func(on: bool):
		GameState.invert_y = on
		_invert.text = "Invert camera Y: " + ("On" if on else "Off")
		_changed())
	_haptics = UI.button("Vibration: On", "", "tab", Vector2(420, 62))
	_haptics.toggled.connect(func(on: bool):
		GameState.haptics = on
		_haptics.text = "Vibration: " + ("On" if on else "Off")
		_changed()
		if on:
			Controls.vibrate(40))
	trow.add_child(_invert)
	trow.add_child(_haptics)
	body.add_child(trow)

	body.add_child(UI.hfill())
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	var reset := UI.button("Reset Save Data", "skull", "danger", Vector2(380, 66))
	reset.pressed.connect(_ask_reset)
	row.add_child(reset)
	row.add_child(UI.hfill())
	var done := UI.button("Done", "check", "primary", Vector2(260, 66))
	done.pressed.connect(close)
	row.add_child(done)
	body.add_child(row)
	_building = false


func refresh() -> void:
	_building = true
	_music.value = GameState.music_volume
	_sfx.value = GameState.sfx_volume
	_look.value = GameState.look_sensitivity
	_music_val.text = "%d%%" % int(round(GameState.music_volume * 100.0))
	_sfx_val.text = "%d%%" % int(round(GameState.sfx_volume * 100.0))
	_look_val.text = "%.1fx" % GameState.look_sensitivity
	for i in 3:
		_quality_btns[i].set_pressed_no_signal(i == GameState.quality)
	_invert.set_pressed_no_signal(GameState.invert_y)
	_invert.text = "Invert camera Y: " + ("On" if GameState.invert_y else "Off")
	_haptics.set_pressed_no_signal(GameState.haptics)
	_haptics.text = "Vibration: " + ("On" if GameState.haptics else "Off")
	_building = false


func _changed() -> void:
	_music_val.text = "%d%%" % int(round(GameState.music_volume * 100.0))
	_sfx_val.text = "%d%%" % int(round(GameState.sfx_volume * 100.0))
	_look_val.text = "%.1fx" % GameState.look_sensitivity
	GameState.apply_settings()


func _set_quality(i: int) -> void:
	GameState.quality = i
	for j in 3:
		_quality_btns[j].set_pressed_no_signal(j == i)
	_changed()


func _ask_reset() -> void:
	if _confirm != null and _confirm.has_method("ask"):
		_confirm.ask("Reset save data?", "This permanently deletes your saved progress (quests, inventory, camp upgrades). Settings are kept.", "Delete save", _do_reset)
	else:
		_do_reset()


func _do_reset() -> void:
	GameState.delete_save()
	GameState.toast.emit("Save data deleted.", "warn")
	save_reset.emit()
