extends Control
## Gameplay HUD: health / stamina / xp, level badge, coins, objective tracker, compass,
## boss health bar, toasts, location banner and damage / low-health vignette.

const Pal := preload("res://scripts/data/pal.gd")
const UI := preload("res://scripts/ui/ui_kit.gd")
const Icons := preload("res://scripts/ui/icons.gd")
const Items := preload("res://scripts/data/items.gd")

var game: Node = null          # set by the UI layer; provides camera yaw, player and boss info
var safe := Vector2.ZERO       # left/top inset

var _hp_disp := 100.0
var _st_disp := 100.0
var _xp_disp := 0.0
var _flash := 0.0
var _t := 0.0
var _boss_disp := 1.0
var _level_label: Label
var _coin_label: Label
var _tracker: PanelContainer
var _tracker_title: Label
var _tracker_text: Label
var _tracker_dist: Label
var _toasts: VBoxContainer
var _banner: Label
var _boss_name: Label
var _last_dist := -1
var _last_text := ""


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_level_label = UI.title("1", 32, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER)
	_level_label.position = Vector2(24, 20)
	_level_label.size = Vector2(60, 64)
	_level_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	add_child(_level_label)

	_coin_label = UI.label("0", 28, Pal.GOLD_LIGHT)
	_coin_label.position = Vector2(150, 94)
	add_child(_coin_label)

	_tracker = PanelContainer.new()
	var sb := UI.box(Color(0.03, 0.04, 0.08, 0.72), Color(Pal.GOLD_DARK, 0.9), 2, 10, 8)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 10
	sb.content_margin_bottom = 12
	_tracker.add_theme_stylebox_override("panel", sb)
	_tracker.custom_minimum_size = Vector2(430, 0)
	_tracker.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", 2)
	_tracker.add_child(tv)
	_tracker_title = UI.label("THE LOST CARAVAN", 20, Pal.TURQUOISE)
	_tracker_text = UI.label("", 24, Pal.TEXT, HORIZONTAL_ALIGNMENT_LEFT, true)
	_tracker_dist = UI.label("", 20, Pal.TEXT_DIM)
	tv.add_child(_tracker_title)
	tv.add_child(_tracker_text)
	tv.add_child(_tracker_dist)
	_tracker.position = Vector2(24, 146)
	add_child(_tracker)

	_toasts = VBoxContainer.new()
	_toasts.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toasts.add_theme_constant_override("separation", 6)
	_toasts.alignment = BoxContainer.ALIGNMENT_BEGIN
	_toasts.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_toasts.offset_left = -140
	_toasts.offset_right = 460
	_toasts.offset_top = 130
	add_child(_toasts)

	_banner = UI.title("", 54, Pal.GOLD_LIGHT, HORIZONTAL_ALIGNMENT_CENTER)
	_banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_banner.offset_left = -400
	_banner.offset_right = 400
	_banner.offset_top = 210
	_banner.modulate.a = 0.0
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_banner)

	_boss_name = UI.title("", 28, Pal.BLOOD, HORIZONTAL_ALIGNMENT_CENTER)
	_boss_name.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	_boss_name.offset_left = -330
	_boss_name.offset_right = 330
	_boss_name.offset_top = 66
	_boss_name.visible = false
	_boss_name.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_boss_name)

	GameState.toast.connect(show_toast)
	GameState.location_discovered.connect(_on_discovered)
	GameState.stats_changed.connect(_stats)
	GameState.quest_changed.connect(_quest)
	_hp_disp = GameState.hp
	_st_disp = GameState.stamina
	_stats()
	_quest()


func _exit_tree() -> void:
	for pair in [[GameState.toast, show_toast], [GameState.location_discovered, _on_discovered], [GameState.stats_changed, _stats], [GameState.quest_changed, _quest]]:
		if pair[0].is_connected(pair[1]):
			pair[0].disconnect(pair[1])


func flash_damage(strength: float = 1.0) -> void:
	_flash = clampf(_flash + 0.55 * strength, 0.0, 1.0)


func _stats() -> void:
	if _level_label == null:
		return
	_level_label.text = str(GameState.level)
	_coin_label.text = str(GameState.coins)


func _quest() -> void:
	if _tracker_text == null:
		return
	var txt := GameState.objective_text()
	_tracker_text.text = txt
	_tracker.visible = true


func show_toast(text: String, kind: String = "info") -> void:
	var col := Pal.SAND
	var border := Pal.GOLD_DARK
	match kind:
		"item":
			col = Pal.GOLD_LIGHT
		"quest":
			col = Pal.TURQUOISE
			border = Pal.TURQUOISE_DIM
		"warn":
			col = Color("f0a09c")
			border = Pal.BLOOD
	var p := PanelContainer.new()
	var sb := UI.box(Color(0.03, 0.04, 0.08, 0.84), border, 2, 10)
	sb.content_margin_left = 18
	sb.content_margin_right = 18
	sb.content_margin_top = 6
	sb.content_margin_bottom = 8
	p.add_theme_stylebox_override("panel", sb)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	var l := UI.label(text, 23, col, HORIZONTAL_ALIGNMENT_CENTER, true)
	# an autowrapping label has no natural width, so size it to the text (capped) to get 1-3 tidy lines
	var tw_px := ThemeDB.fallback_font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, 23).x
	l.custom_minimum_size.x = clampf(tw_px + 6.0, 40.0, 540.0)
	p.add_child(l)
	_toasts.add_child(p)
	while _toasts.get_child_count() > 4:
		var old := _toasts.get_child(0)
		_toasts.remove_child(old)
		old.queue_free()
	p.modulate.a = 0.0
	var tw := p.create_tween()
	tw.tween_property(p, "modulate:a", 1.0, 0.18)
	tw.tween_interval(2.6)
	tw.tween_property(p, "modulate:a", 0.0, 0.5)
	tw.tween_callback(p.queue_free)


func _on_discovered(id: String) -> void:
	if id == "camp" and GameState.play_time < 3.0:
		return
	_banner.text = String(Items.LOCATIONS[id].name)
	_banner.modulate.a = 0.0
	var tw := _banner.create_tween()
	tw.tween_property(_banner, "modulate:a", 1.0, 0.5)
	tw.tween_interval(1.8)
	tw.tween_property(_banner, "modulate:a", 0.0, 0.9)
	AudioMgr.play("quest_accept", -10.0)


func _process(delta: float) -> void:
	_t += delta
	var k := minf(1.0, delta * 9.0)
	_hp_disp = lerpf(_hp_disp, GameState.hp, k)
	_st_disp = lerpf(_st_disp, GameState.stamina, k * 1.5)
	var xp_frac := float(GameState.xp) / float(Items.xp_for_next(GameState.level))
	_xp_disp = lerpf(_xp_disp, xp_frac, k)
	_flash = maxf(0.0, _flash - delta * 1.6)
	var boss: Dictionary = game.boss_info() if game != null and game.has_method("boss_info") else {}
	var boss_on: bool = bool(boss.get("active", false))
	_boss_name.visible = boss_on
	if boss_on:
		_boss_name.text = String(boss.get("name", ""))
		_boss_disp = lerpf(_boss_disp, float(boss.get("frac", 1.0)), k)
	# distance readout (only update text when it changes)
	if game != null and game.has_method("objective_distance"):
		var d: int = int(game.objective_distance())
		if d != _last_dist:
			_last_dist = d
			_tracker_dist.text = ("%d m away" % d) if d >= 0 else ""
	queue_redraw()


func _bar(r: Rect2, frac: float, col_a: Color, col_b: Color) -> void:
	draw_rect(r.grow(3.0), Color(Pal.GOLD_DARK, 0.95), true)
	draw_rect(r, Pal.OBSIDIAN, true)
	var f := clampf(frac, 0.0, 1.0)
	if f > 0.002:
		var fr := Rect2(r.position, Vector2(r.size.x * f, r.size.y))
		draw_rect(fr, col_a, true)
		draw_rect(Rect2(fr.position, Vector2(fr.size.x, fr.size.y * 0.5)), col_b, true)
		draw_rect(Rect2(fr.position + Vector2(0, 2), Vector2(fr.size.x, 2)), Color(1, 1, 1, 0.18), true)


func _draw() -> void:
	var font := ThemeDB.fallback_font
	# level badge
	var bc := Vector2(54, 52)
	draw_circle(bc, 33.0, Pal.GOLD_DARK)
	draw_circle(bc, 29.0, Pal.OBSIDIAN)
	draw_arc(bc, 29.0, 0, TAU, 36, Color(Pal.GOLD, 0.8), 2.0, true)
	# bars
	var hp_r := Rect2(104, 28, 290, 26)
	_bar(hp_r, _hp_disp / GameState.max_hp(), Pal.BLOOD_DARK.lerp(Pal.BLOOD, 0.75), Pal.BLOOD)
	var txt := "%d / %d" % [int(ceil(GameState.hp)), int(GameState.max_hp())]
	draw_string(font, Vector2(hp_r.position.x + 12, hp_r.position.y + 21), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Pal.TEXT)
	var st_r := Rect2(104, 66, 230, 14)
	_bar(st_r, _st_disp / GameState.max_stamina(), Color("2f7f66"), Pal.STAMINA)
	var xp_r := Rect2(104, 90, 170, 8)
	_bar(xp_r, _xp_disp, Pal.GOLD_DARK, Pal.GOLD)
	# coin icon
	Icons.draw_icon(self, "coin", Vector2(120, 118), 15.0)
	_draw_compass(font)
	_draw_boss()
	# vignette: damage flash and low-health pulse
	var low := 0.0
	if GameState.hp / GameState.max_hp() < 0.28 and GameState.hp > 0.0:
		low = 0.18 + 0.12 * sin(_t * 5.0)
	var a := maxf(_flash * 0.55, low)
	if a > 0.01:
		var w := size.x
		var h := size.y
		for i in 7:
			var u := float(i) / 7.0
			var al := a * (1.0 - u) * 0.55
			var th := 14.0 + u * 70.0
			var c := Color(0.75, 0.05, 0.08, al)
			draw_rect(Rect2(0, 0, w, th), c)
			draw_rect(Rect2(0, h - th, w, th), c)
			draw_rect(Rect2(0, 0, th, h), c)
			draw_rect(Rect2(w - th, 0, th, h), c)


func _draw_compass(font: Font) -> void:
	var cx := size.x * 0.5
	var r := Rect2(cx - 230.0, 20.0, 460.0, 38.0)
	draw_rect(r, Color(0.03, 0.04, 0.08, 0.62), true)
	draw_rect(r, Color(Pal.GOLD_DARK, 0.9), false, 2.0)
	if game == null or not game.has_method("camera_bearing"):
		return
	var facing: float = game.camera_bearing()  # degrees clockwise from north
	var half := r.size.x * 0.5
	var span := 100.0  # degrees visible each side
	for deg in range(0, 360, 15):
		var d := wrapf(float(deg) - facing + 180.0, 0.0, 360.0) - 180.0
		if absf(d) > span:
			continue
		var x := cx + d / span * half
		var major := deg % 90 == 0
		var fade := 1.0 - pow(absf(d) / span, 3.0)
		draw_line(Vector2(x, r.position.y + (6.0 if major else 22.0)), Vector2(x, r.end.y - 6.0), Color(Pal.GOLD, 0.7 * fade), 2.0 if major else 1.0)
		if major:
			var letter: String = ["N", "E", "S", "W"][deg / 90]
			var col := Pal.BLOOD if letter == "N" else Pal.GOLD_LIGHT
			draw_string(font, Vector2(x - 8.0, r.end.y - 9.0), letter, HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(col, fade))
	# centre pointer
	draw_colored_polygon(PackedVector2Array([Vector2(cx - 7, r.position.y - 2), Vector2(cx + 7, r.position.y - 2), Vector2(cx, r.position.y + 9)]), Pal.GOLD_LIGHT)
	# objective marker
	var tb: float = game.objective_bearing() if game.has_method("objective_bearing") else -999.0
	if tb > -900.0:
		var d2 := wrapf(tb - facing + 180.0, 0.0, 360.0) - 180.0
		var x2 := cx + clampf(d2 / span, -1.0, 1.0) * (half - 12.0)
		var c2 := Vector2(x2, r.position.y + 19.0)
		var edge := absf(d2) > span
		var s := 9.0 + 2.0 * sin(_t * 4.0)
		draw_colored_polygon(PackedVector2Array([c2 + Vector2(0, -s), c2 + Vector2(s, 0), c2 + Vector2(0, s), c2 + Vector2(-s, 0)]), Color(Pal.TURQUOISE, 0.6 if edge else 1.0))
		draw_arc(c2, s + 3.0, 0, TAU, 20, Color(Pal.TURQUOISE, 0.5), 2.0, true)


func _draw_boss() -> void:
	if not _boss_name.visible:
		return
	var cx := size.x * 0.5
	var r := Rect2(cx - 300.0, 102.0, 600.0, 20.0)
	_bar(r, _boss_disp, Color("7a1f24"), Color("c2413f"))
