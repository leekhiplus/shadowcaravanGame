extends Control
## On-screen touch controls: floating virtual joystick (left), look-drag (anywhere else),
## action buttons (bottom right) and quick-menu buttons (top right).
## Hit-testing is done manually per finger index so multi-touch works reliably, and nothing
## here reacts while a menu is open (Controls.enabled == false).

const Pal := preload("res://scripts/data/pal.gd")
const Icons := preload("res://scripts/ui/icons.gd")

signal menu_tapped(id: String)

const JOY_RADIUS := 105.0
const JOY_DEAD := 0.12

class Btn extends RefCounted:
	var id := ""
	var icon := ""
	var mode := "press"   # press: fires on touch-down | hold: held state | release: fires on lift inside
	var corner := "br"    # br = bottom right, tr = top right
	var off := Vector2.ZERO
	var radius := 60.0
	var center := Vector2.ZERO
	var finger := -1
	var cooldown := 0.0
	var visible_now := true
	var label := ""

var buttons: Array[Btn] = []
var prompt_text := ""
var safe := Vector4.ZERO  # left, top, right, bottom insets in logical px

var _joy_finger := -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _look_finger := -1
var _t := 0.0
var _interact: Btn


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_add("attack", "sword", "press", "br", Vector2(150, 150), 84.0)
	_add("jump", "jump", "press", "br", Vector2(122, 322), 54.0)
	_add("dodge", "roll", "press", "br", Vector2(318, 104), 60.0)
	_interact = _add("interact", "interact", "press", "br", Vector2(300, 250), 62.0)
	_add("sprint", "sprint", "hold", "br", Vector2(462, 104), 50.0)
	_add("pause", "pause", "release", "tr", Vector2(62, 62), 40.0)
	_add("map", "map", "release", "tr", Vector2(160, 62), 40.0)
	_add("pack", "pack", "release", "tr", Vector2(258, 62), 40.0)
	_add("journal", "book", "release", "tr", Vector2(356, 62), 40.0)
	resized.connect(_layout)
	_layout()


func _add(id: String, icon: String, mode: String, corner: String, off: Vector2, radius: float) -> Btn:
	var b := Btn.new()
	b.id = id
	b.icon = icon
	b.mode = mode
	b.corner = corner
	b.off = off
	b.radius = radius
	buttons.append(b)
	return b


func _layout() -> void:
	safe = Vector4.ZERO
	if OS.has_feature("mobile"):
		var area := DisplayServer.get_display_safe_area()
		var win := DisplayServer.window_get_size()
		if win.x > 0 and win.y > 0 and area.size.x > 0:
			safe.x = float(area.position.x) / float(win.x) * size.x
			safe.y = float(area.position.y) / float(win.y) * size.y
			safe.z = float(win.x - area.end.x) / float(win.x) * size.x
			safe.w = float(win.y - area.end.y) / float(win.y) * size.y
	for b in buttons:
		if b.corner == "br":
			b.center = Vector2(size.x - b.off.x - safe.z, size.y - b.off.y - safe.w)
		else:
			b.center = Vector2(size.x - b.off.x - safe.z, b.off.y + safe.y)
	queue_redraw()


func get_button(id: String) -> Btn:
	for b in buttons:
		if b.id == id:
			return b
	return null


func set_prompt(text: String) -> void:
	if text != prompt_text:
		prompt_text = text
		queue_redraw()


func set_cooldown(id: String, frac: float) -> void:
	var b := get_button(id)
	if b != null and absf(b.cooldown - frac) > 0.01:
		b.cooldown = frac
		queue_redraw()


func release_all() -> void:
	_joy_finger = -1
	_look_finger = -1
	for b in buttons:
		b.finger = -1
	Controls.reset_touch()
	queue_redraw()


func _process(delta: float) -> void:
	_t += delta
	if not Controls.enabled and (_joy_finger != -1 or _look_finger != -1 or _any_finger()):
		release_all()
	if prompt_text != "" or _joy_finger != -1:
		queue_redraw()


func _any_finger() -> bool:
	for b in buttons:
		if b.finger != -1:
			return true
	return false


func _joy_zone() -> Rect2:
	return Rect2(safe.x, size.y * 0.28, size.x * 0.44 - safe.x, size.y * 0.72)


func _hit_button(p: Vector2) -> Btn:
	for b in buttons:
		if b == _interact and prompt_text == "":
			continue
		if p.distance_to(b.center) <= b.radius * 1.12:
			return b
	return null


func _input(event: InputEvent) -> void:
	if not visible or not Controls.enabled:
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			_press(t.index, t.position)
		else:
			_lift(t.index, t.position)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_drag(d.index, d.position, d.relative)


func _press(idx: int, p: Vector2) -> void:
	var b := _hit_button(p)
	if b != null:
		b.finger = idx
		match b.mode:
			"press":
				_fire(b.id)
			"hold":
				if b.id == "sprint":
					Controls.sprint_held = true
		queue_redraw()
		return
	if _joy_finger == -1 and _joy_zone().has_point(p):
		_joy_finger = idx
		_joy_origin = p
		_joy_pos = p
		Controls.touch_move = Vector2.ZERO
		queue_redraw()
		return
	if _look_finger == -1:
		_look_finger = idx


func _lift(idx: int, p: Vector2) -> void:
	if idx == _joy_finger:
		_joy_finger = -1
		Controls.touch_move = Vector2.ZERO
	if idx == _look_finger:
		_look_finger = -1
	for b in buttons:
		if b.finger == idx:
			b.finger = -1
			if b.mode == "hold" and b.id == "sprint":
				Controls.sprint_held = false
			elif b.mode == "release" and p.distance_to(b.center) <= b.radius * 1.4:
				AudioMgr.play("ui_click")
				menu_tapped.emit(b.id)
	queue_redraw()


func _drag(idx: int, p: Vector2, rel: Vector2) -> void:
	if idx == _joy_finger:
		_joy_pos = p
		var delta := p - _joy_origin
		var v := delta / JOY_RADIUS
		if v.length() > 1.0:
			# the base follows the thumb so the stick never gets "stuck" at the rim
			_joy_origin = p - delta.normalized() * JOY_RADIUS
			v = v.normalized()
		if v.length() < JOY_DEAD:
			v = Vector2.ZERO
		else:
			v = v.normalized() * ((v.length() - JOY_DEAD) / (1.0 - JOY_DEAD))
		Controls.touch_move = v
		queue_redraw()
	elif idx == _look_finger:
		Controls.look_delta += rel


func _fire(id: String) -> void:
	match id:
		"attack":
			Controls.attack_pressed.emit()
		"dodge":
			Controls.dodge_pressed.emit()
		"jump":
			Controls.jump_pressed.emit()
		"interact":
			Controls.interact_pressed.emit()


func _draw() -> void:
	# joystick
	var base := _joy_origin if _joy_finger != -1 else Vector2(safe.x + 175.0, size.y - 170.0 - safe.w)
	var knob := _joy_pos if _joy_finger != -1 else base
	var active := _joy_finger != -1
	draw_circle(base, JOY_RADIUS, Color(0.04, 0.05, 0.09, 0.42 if active else 0.22))
	draw_arc(base, JOY_RADIUS, 0, TAU, 48, Color(Pal.GOLD, 0.75 if active else 0.35), 3.0, true)
	draw_arc(base, JOY_RADIUS * 0.55, 0, TAU, 40, Color(Pal.GOLD_DARK, 0.4 if active else 0.2), 2.0, true)
	var kp := base + (knob - base).limit_length(JOY_RADIUS)
	draw_circle(kp, 44.0, Color(Pal.MIDNIGHT_LIGHT, 0.85 if active else 0.5))
	draw_arc(kp, 44.0, 0, TAU, 32, Color(Pal.TURQUOISE if active else Pal.GOLD, 0.9), 3.0, true)
	# buttons
	for b in buttons:
		if b == _interact and prompt_text == "":
			continue
		var pressed := b.finger != -1 or (b.id == "sprint" and Controls.sprint_held)
		var pulse := 0.0
		if b == _interact:
			pulse = 0.5 + 0.5 * sin(_t * 5.0)
		var fill := Color(0.03, 0.04, 0.08, 0.62)
		if pressed:
			fill = Color(Pal.TURQUOISE_DIM, 0.8)
		draw_circle(b.center, b.radius, fill)
		var ring := Pal.TURQUOISE if pressed else Pal.GOLD
		draw_arc(b.center, b.radius, 0, TAU, 40, Color(ring, 0.95 if b != _interact else 0.6 + 0.4 * pulse), 4.0 if b.radius > 50 else 3.0, true)
		draw_arc(b.center, b.radius - 8.0, 0, TAU, 36, Color(Pal.GOLD_DARK, 0.45), 1.5, true)
		Icons.draw_icon(self, b.icon, b.center, b.radius * 0.5, Pal.TURQUOISE if pressed else Pal.GOLD_LIGHT)
		if b.cooldown > 0.01:
			draw_circle(b.center, b.radius - 2.0, Color(0, 0, 0, 0.45))
			draw_arc(b.center, b.radius - 6.0, -PI * 0.5, -PI * 0.5 + TAU * b.cooldown, 32, Color(Pal.BLOOD, 0.95), 5.0, true)
	if prompt_text != "":
		var f := ThemeDB.fallback_font
		var fs := 24
		var ts := f.get_string_size(prompt_text, HORIZONTAL_ALIGNMENT_CENTER, -1, fs)
		var pos := Vector2(_interact.center.x, _interact.center.y - _interact.radius - 22.0)
		var r := Rect2(pos.x - ts.x * 0.5 - 16.0, pos.y - ts.y + 2.0, ts.x + 32.0, ts.y + 14.0)
		draw_rect(r, Color(0.03, 0.04, 0.08, 0.82), true)
		draw_rect(r, Color(Pal.GOLD, 0.85), false, 2.0)
		draw_string(f, Vector2(pos.x - ts.x * 0.5, pos.y + 8.0), prompt_text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Pal.GOLD_LIGHT)
