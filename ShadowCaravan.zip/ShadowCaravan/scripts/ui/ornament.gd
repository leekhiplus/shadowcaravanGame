extends Control
## Decorative overlay: gold corner brackets/diamonds for panels, a gem line for dividers,
## and an optional procedural icon + end diamonds for buttons. Never intercepts input.

const Pal := preload("res://scripts/data/pal.gd")
const Icons := preload("res://scripts/ui/icons.gd")

var mode := "panel"  # panel | button | divider
var icon_id := ""
var tint := Pal.GOLD
var icon_tint := Pal.GOLD_LIGHT
var icon_size := 17.0
var sheen := true  # faint top highlight on buttons


func _init(m: String = "panel") -> void:
	mode = m
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _diamond(c: Vector2, r: float, col: Color) -> void:
	draw_colored_polygon(PackedVector2Array([c + Vector2(0, -r), c + Vector2(r, 0), c + Vector2(0, r), c + Vector2(-r, 0)]), col)


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	match mode:
		"panel":
			draw_rect(r.grow(-8.0), Color(Pal.GOLD_DARK, 0.5), false, 1.5)
			var L := 30.0
			var inset := 4.0
			var corners := [
				[Vector2(inset, inset), Vector2(1, 0), Vector2(0, 1)],
				[Vector2(r.size.x - inset, inset), Vector2(-1, 0), Vector2(0, 1)],
				[Vector2(inset, r.size.y - inset), Vector2(1, 0), Vector2(0, -1)],
				[Vector2(r.size.x - inset, r.size.y - inset), Vector2(-1, 0), Vector2(0, -1)],
			]
			for cn in corners:
				var o: Vector2 = cn[0]
				draw_line(o, o + cn[1] * L, Pal.GOLD, 2.5, true)
				draw_line(o, o + cn[2] * L, Pal.GOLD, 2.5, true)
				_diamond(o + cn[1] * 7.0 + cn[2] * 7.0, 3.5, Pal.GOLD_LIGHT)
		"button":
			if sheen:
				draw_line(Vector2(10, 3), Vector2(r.size.x - 10, 3), Color(1, 1, 1, 0.07), 2.0)
			if icon_id != "":
				Icons.draw_icon(self, icon_id, Vector2(34, r.size.y * 0.5), icon_size, icon_tint)
		"divider":
			var cy := r.size.y * 0.5
			var half := r.size.x * 0.5
			var n := 24
			for i in n:
				var t0 := float(i) / float(n)
				var t1 := float(i + 1) / float(n)
				var a := 1.0 - t0
				draw_line(Vector2(half - 12.0 - half * t0 * 0.96, cy), Vector2(half - 12.0 - half * t1 * 0.96, cy), Color(tint, a * 0.9), 1.6)
				draw_line(Vector2(half + 12.0 + half * t0 * 0.96, cy), Vector2(half + 12.0 + half * t1 * 0.96, cy), Color(tint, a * 0.9), 1.6)
			_diamond(Vector2(half, cy), 5.0, tint)
			_diamond(Vector2(half - 15.0, cy), 2.5, Color(tint, 0.7))
			_diamond(Vector2(half + 15.0, cy), 2.5, Color(tint, 0.7))
