extends Control
## Main menu: Continue, Play (new game), Settings, Credits (+ Quit on desktop).

const Pal := preload("res://scripts/data/pal.gd")
const UI := preload("res://scripts/ui/ui_kit.gd")
const Items := preload("res://scripts/data/items.gd")
const Backdrop := preload("res://scripts/ui/backdrop.gd")
const SettingsPanel := preload("res://scripts/ui/settings_panel.gd")
const CreditsPanel := preload("res://scripts/ui/credits_panel.gd")
const ConfirmDialog := preload("res://scripts/ui/confirm_dialog.gd")

var _continue: Button
var _info: Label
var _settings: Control
var _credits: Control
var _confirm: Control
var _modal_layer: Control


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	get_tree().paused = false
	Controls.enabled = true
	AudioMgr.set_ambience(false)
	AudioMgr.play_music("music_menu")
	add_child(Backdrop.new())

	var root := MarginContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("margin_left", 80)
	root.add_theme_constant_override("margin_right", 80)
	root.add_theme_constant_override("margin_top", 30)
	root.add_theme_constant_override("margin_bottom", 20)
	add_child(root)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	root.add_child(col)

	col.add_child(UI.title("SHADOW CARAVAN", 84, Pal.GOLD_LIGHT))
	col.add_child(UI.label("A DESERT TALE OF LOST CITIES", 24, Pal.SAND))
	col.add_child(UI.divider(20))
	col.add_child(UI.spacer(2))

	var menu := VBoxContainer.new()
	menu.add_theme_constant_override("separation", 10)
	menu.custom_minimum_size = Vector2(440, 0)
	menu.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	col.add_child(menu)

	_continue = UI.button("Continue", "arrow_up", "primary", Vector2(440, 70))
	_continue.pressed.connect(_on_continue)
	menu.add_child(_continue)
	_info = UI.label("", 20, Pal.TEXT_DIM)
	menu.add_child(_info)
	var play := UI.button("Play", "sword", "normal", Vector2(440, 64))
	play.pressed.connect(_on_play)
	menu.add_child(play)
	var settings := UI.button("Settings", "gear", "normal", Vector2(440, 64))
	settings.pressed.connect(func(): _settings.open())
	menu.add_child(settings)
	var credits := UI.button("Credits", "scroll", "normal", Vector2(440, 64))
	credits.pressed.connect(func(): _credits.open())
	menu.add_child(credits)
	if not OS.has_feature("mobile"):
		var quit := UI.button("Quit", "close", "ghost", Vector2(440, 54))
		quit.pressed.connect(func(): get_tree().quit())
		menu.add_child(quit)

	col.add_child(UI.hfill())
	var version := str(ProjectSettings.get_setting("application/config/version", "")).strip_edges()
	if version == "":
		version = "0.1.0"
	var ver := UI.label("v%s  -  com.zafronix.shadowcaravan" % version, 18, Pal.TEXT_DIM)
	ver.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	col.add_child(ver)

	_modal_layer = Control.new()
	_modal_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_modal_layer)
	_confirm = ConfirmDialog.new()
	_settings = SettingsPanel.new()
	_credits = CreditsPanel.new()
	for p in [_settings, _credits, _confirm]:
		_modal_layer.add_child(p)
	_settings.set_confirm(_confirm)
	_settings.save_reset.connect(_refresh)
	Controls.back_pressed.connect(_on_back)
	_refresh()


func _exit_tree() -> void:
	if Controls.back_pressed.is_connected(_on_back):
		Controls.back_pressed.disconnect(_on_back)


func _refresh() -> void:
	var has := GameState.has_save()
	_continue.disabled = not has
	_info.text = ""
	if has:
		var probe := _peek_summary()
		_info.text = probe if probe != "" else "Saved game found"
	else:
		_info.text = "No saved game yet"


## Reads the save without touching live state to show a one-line summary.
func _peek_summary() -> String:
	var p: Dictionary = GameState._read_envelope(GameState.save_path)
	if p.is_empty():
		p = GameState._read_envelope(GameState.save_path + ".bak")
	if p.is_empty():
		return "Save damaged - Continue may not work"
	var mins := int(float(p.get("play_time", 0.0)) / 60.0)
	var stage := int(p.get("quest_stage", 0))
	var tag := "The Lost Caravan: found" if stage >= 5 else "Level %d  |  %d min" % [int(p.get("level", 1)), mins]
	return tag


func _on_continue() -> void:
	if GameState.load_game():
		if GameState.last_load_message != "":
			GameState.toast.emit(GameState.last_load_message, "warn")
		Router.go("res://scenes/game.tscn", "Returning to the dunes...")
	else:
		_info.text = GameState.last_load_message
		_refresh()


func _on_play() -> void:
	if GameState.has_save():
		_confirm.ask("Start a new game?", "Your existing save will be replaced as soon as you begin the new journey.", "Start new game", _begin_new, false)
	else:
		_begin_new()


func _begin_new() -> void:
	GameState.new_game()
	Router.go("res://scenes/intro.tscn")


func _on_back() -> void:
	for p in [_confirm, _settings, _credits]:
		if p.is_open:
			p.close()
			return
