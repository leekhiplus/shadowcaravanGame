extends RefCounted
## Static game data: items, recipes, upgrades, locations and quest text.

const FRAGMENTS_REQUIRED := 3
const CAMP_MAX_LEVEL := 3
const WORLD_HALF := 100.0  # playable half-extent in metres (x and z)

const ITEMS := {
	"relic_fragment": {"name": "Relic Fragment", "type": "quest", "icon": "fragment",
		"desc": "A humming shard of the Sunken Idol. Three are needed to wake the Ancient Gate."},
	"healing_draught": {"name": "Healing Draught", "type": "consumable", "icon": "potion", "heal": 60,
		"desc": "Desert herbs steeped with wraith dust. Restores 60 health."},
	"scarab_shell": {"name": "Scarab Shell", "type": "material", "icon": "shell",
		"desc": "Glossy and tough. Used in crafting and for sharpening blades."},
	"wraith_dust": {"name": "Wraith Dust", "type": "material", "icon": "dust",
		"desc": "Cold, glittering ash left behind by dune wraiths."},
	"sand_glass": {"name": "Sand Glass", "type": "material", "icon": "glass",
		"desc": "Sand fused by ancient lightning. Prized by smiths."},
	"worn_scimitar": {"name": "Worn Scimitar", "type": "weapon", "icon": "scimitar", "dmg": 12,
		"desc": "Your trusty caravan blade. Damage 12."},
	"sunsteel_blade": {"name": "Sunsteel Blade", "type": "weapon", "icon": "scimitar", "dmg": 20,
		"desc": "Forged at the camp anvil with scarab shell and sand glass. Damage 20."},
	"caravan_blade": {"name": "Caravan Blade", "type": "weapon", "icon": "scimitar", "dmg": 28,
		"desc": "Reward of the Lost Caravan. Its edge hums with moonlight. Damage 28."},
	"travelers_wraps": {"name": "Traveler's Wraps", "type": "armor", "icon": "cloak", "def": 1,
		"desc": "Sun-bleached cloth. Reduces damage taken by 1."},
	"dune_cloak": {"name": "Dune Cloak", "type": "armor", "icon": "cloak", "def": 4,
		"desc": "A heavy cloak woven with wire thread. Reduces damage taken by 4."},
	"ward_mantle": {"name": "Ward Mantle", "type": "armor", "icon": "cloak", "def": 7,
		"desc": "Runed mantle that turns aside claws and curses. Reduces damage taken by 7."},
}

const RECIPES := [
	{"id": "r_draught", "out": "healing_draught", "count": 1, "items": {"scarab_shell": 1, "wraith_dust": 1}, "coins": 0},
	{"id": "r_sunsteel", "out": "sunsteel_blade", "count": 1, "items": {"scarab_shell": 3, "wraith_dust": 2, "sand_glass": 1}, "coins": 50},
	{"id": "r_mantle", "out": "ward_mantle", "count": 1, "items": {"wraith_dust": 3, "sand_glass": 1}, "coins": 40},
]

const UPGRADES := {
	"vitality": {"name": "Iron Constitution", "desc": "+15 maximum health per rank.", "max": 5, "icon": "heart"},
	"blade": {"name": "Whetstone Craft", "desc": "+3 weapon damage per rank.", "max": 5, "icon": "scimitar"},
	"endurance": {"name": "Desert Endurance", "desc": "+10 maximum stamina per rank.", "max": 4, "icon": "boot"},
}

const CAMP_DESC := [
	"Level 1 - A humble tent and a fire. Resting restores health and stamina.",
	"Level 2 - Better cookfires: crafted Healing Draughts yield one extra potion.",
	"Level 3 - A well-stocked camp: every rest also leaves you a free Healing Draught.",
]

# Landmarks. pos = Vector2(x, z). waystone = fast-travel point. hidden = not shown on the map until found.
const LOCATIONS := {
	"camp": {"name": "Caravan Camp", "pos": Vector2(-62, 55), "spawn": Vector2(-62, 61), "radius": 20.0, "waystone": true,
		"desc": "Your home camp. Rest, craft and upgrade here."},
	"ruins": {"name": "The Broken Court", "pos": Vector2(-4, 22), "spawn": Vector2(-4, 30), "radius": 22.0, "waystone": true,
		"desc": "Toppled columns and scarab nests. A road to the temple starts here."},
	"tablet": {"name": "Weeping Stone", "pos": Vector2(24, 38), "spawn": Vector2(24, 34), "radius": 9.0, "waystone": false,
		"desc": "A carved tablet that remembers an old rite."},
	"alcove": {"name": "Hidden Alcove", "pos": Vector2(14, -8), "spawn": Vector2(14, -3), "radius": 8.0, "waystone": false,
		"desc": "A secret pocket of stone, sealed by a ring of boulders."},
	"temple": {"name": "Temple of Echoes", "pos": Vector2(52, -12), "spawn": Vector2(32, -8), "radius": 22.0, "waystone": true,
		"desc": "A buried temple whose rune pillars still answer."},
	"wraith": {"name": "Wraith Hollow", "pos": Vector2(-52, -26), "spawn": Vector2(-52, -10), "radius": 18.0, "waystone": false,
		"desc": "A raised plateau haunted by dune wraiths."},
	"gate": {"name": "The Ancient Gate", "pos": Vector2(0, -56), "spawn": Vector2(0, -47), "radius": 14.0, "waystone": true,
		"desc": "A sealed gate of black stone. It wants three relic fragments."},
	"caravan": {"name": "The Lost Caravan", "pos": Vector2(0, -80), "spawn": Vector2(0, -62), "radius": 18.0, "waystone": true,
		"desc": "The wreck of the vanished caravan, guarded by the Hollow Warden."},
	"moonwell": {"name": "Moonwell", "pos": Vector2(34, 66), "spawn": Vector2(34, 61), "radius": 9.0, "waystone": false,
		"desc": "A still, glowing well. The water never warms."},
	"colossus": {"name": "Fallen Colossus", "pos": Vector2(-30, -42), "spawn": Vector2(-30, -36), "radius": 10.0, "waystone": false,
		"desc": "A statue of a forgotten king, toppled long ago."},
	"wreck": {"name": "Caravan Wreck", "pos": Vector2(-84, 20), "spawn": Vector2(-80, 26), "radius": 10.0, "waystone": false,
		"desc": "Splintered wagons half-buried in the dunes."},
}

# Sand roads (used for terrain tinting and for flattening dunes). Points are Vector2(x, z).
const PATHS := [
	[Vector2(-62, 61), Vector2(-48, 52), Vector2(-30, 42), Vector2(-14, 32), Vector2(-4, 24)],
	[Vector2(-4, 24), Vector2(10, 14), Vector2(24, 2), Vector2(32, -8), Vector2(40, -12)],
	[Vector2(-4, 24), Vector2(-3, 0), Vector2(-2, -24), Vector2(0, -46), Vector2(0, -60), Vector2(0, -80)],
	[Vector2(-4, 24), Vector2(-24, 6), Vector2(-42, -8), Vector2(-52, -14)],
	[Vector2(-14, 32), Vector2(8, 38), Vector2(24, 38)],
	[Vector2(24, 38), Vector2(32, 52), Vector2(34, 66)],
	[Vector2(-2, -24), Vector2(-16, -34), Vector2(-30, -42)],
	[Vector2(-62, 61), Vector2(-74, 38), Vector2(-84, 20)],
]

# Fixed world pickups: id -> {kind, pos}. Chests drop the listed loot.
const CHESTS := {
	"chest_camp": {"pos": Vector3(-71, 0, 41), "coins": 30, "items": {"healing_draught": 1}},
	"chest_ruins": {"pos": Vector3(9, 0, 40), "coins": 25, "items": {"dune_cloak": 1}},
	"chest_alcove": {"pos": Vector3(17, 0, -10), "coins": 60, "items": {"sand_glass": 2}},
	"chest_wreck": {"pos": Vector3(-86, 0, 23), "coins": 40, "items": {"wraith_dust": 2, "sand_glass": 1}},
	"chest_colossus": {"pos": Vector3(-27, 0, -46), "coins": 50, "items": {"healing_draught": 2}},
}

# Temple puzzle: rune indices 0 Sun, 1 Moon, 2 Eye, 3 Serpent. Dials start at [0, 0, 0].
const PUZZLE_SOLUTION := [1, 2, 0]
const PUZZLE_CLUE := "\"Night wakes first. The Watcher follows. The Sun comes last, and all is answered.\"\n- carved on the Weeping Stone"
const PUZZLE_HINT := "Three rune pillars stand in the Temple of Echoes. Tap a pillar's rune to turn it, set all three in the right order, then press Attune."

const XP_VALUES := {"scarab": 12, "wraith": 20, "boss": 150, "discovery": 15, "quest": 120}

static func item(id: String) -> Dictionary:
	return ITEMS.get(id, {"name": id, "type": "material", "icon": "shell", "desc": ""})

static func upgrade_cost(id: String, rank: int) -> Dictionary:
	match id:
		"vitality":
			return {"coins": 30 + 25 * rank, "items": {}}
		"blade":
			return {"coins": 40 + 30 * rank, "items": {"scarab_shell": 1 + rank}}
		"endurance":
			return {"coins": 35 + 25 * rank, "items": {}}
	return {"coins": 9999, "items": {}}

static func camp_upgrade_cost(level: int) -> Dictionary:
	if level == 1:
		return {"coins": 80, "items": {"wraith_dust": 3}}
	if level == 2:
		return {"coins": 160, "items": {"wraith_dust": 5, "sand_glass": 2}}
	return {"coins": 0, "items": {}}

static func xp_for_next(level: int) -> int:
	return 50 + 40 * (level - 1)
