extends RefCounted
## Screenshot hook: opens one UI screen of the game scene with a believable mid-game save.
## args: ui=hud|pause|inventory|journal|map|skills|settings|camp_rest|camp_craft|camp_upgrade|camp_storage|
##          puzzle|dialogue|defeat|quest|victory|confirm  (also takes the tour.gd args)

func run(tree: SceneTree, game: Node) -> void:
	var a := {}
	for s in OS.get_cmdline_user_args():
		var kv := s.split("=", true, 1)
		if kv.size() == 2:
			a[kv[0]] = kv[1]
	var GS: Node = tree.root.get_node("GameState")
	GS.quest_stage = 1
	GS.level = 4
	GS.xp = 70
	GS.coins = 137
	GS.hp = 74.0
	GS.fragments_found = 1
	GS.add_item("healing_draught", 3, true)
	GS.add_item("scarab_shell", 5, true)
	GS.add_item("wraith_dust", 2, true)
	GS.add_item("sand_glass", 1, true)
	GS.add_item("relic_fragment", 1, true)
	GS.add_item("sunsteel_blade", 1, true)
	GS.add_item("dune_cloak", 1, true)
	GS.stash["scarab_shell"] = 4
	for id in ["camp", "ruins", "tablet", "alcove"]:
		GS.discover(id, true)
	GS.clue_found = true
	GS.quest_changed.emit()
	GS.stats_changed.emit()
	game.cam_rig.snap_to_target()
	var ui: Node = game.ui
	var which: String = a.get("ui", "hud")
	match which:
		"pause", "inventory", "journal", "skills", "settings", "puzzle":
			ui.open_panel(which)
		"map":
			ui.open_panel("map")
		"camp_rest":
			ui.open_camp("rest")
		"camp_craft":
			ui.open_camp("craft")
		"camp_upgrade":
			ui.open_camp("upgrade")
		"camp_storage":
			ui.open_camp("storage")
		"dialogue":
			ui.show_dialogue("Elder Sahir", ["The caravan went north three nights ago, carrying the Sunken Idol. None have returned.", "Bring me the three fragments, and the Ancient Gate will answer."], "Accept the quest", func(): pass)
		"defeat", "quest", "victory":
			ui.show_end(which)
		"confirm":
			ui.open_panel("settings")
			ui.ask("Delete save?", "This permanently deletes your saved progress.", "Delete", func(): pass)
