extends RefCounted
## Screenshot hook for the main menu: open=credits|settings

func run(_tree: SceneTree, inst: Node) -> void:
	for s in OS.get_cmdline_user_args():
		var kv := s.split("=", true, 1)
		if kv.size() == 2 and kv[0] == "open":
			inst.get("_" + kv[1]).open()
