extends SceneTree
## Dev tool: renders a scene for N seconds and saves a PNG screenshot.
## godot --path . --rendering-driver opengl3 --resolution 1280x720 -s tests/shot.gd -- scene=res://scenes/main_menu.tscn out=/tmp/a.png wait=2.0

func _initialize() -> void:
	var args := {}
	for a in OS.get_cmdline_user_args():
		var kv := a.split("=", true, 1)
		if kv.size() == 2:
			args[kv[0]] = kv[1]
	var scene_path: String = args.get("scene", "res://scenes/main_menu.tscn")
	var out: String = args.get("out", "/tmp/shot.png")
	var wait: float = float(args.get("wait", "2.0"))
	var hook: String = args.get("hook", "")
	var packed: PackedScene = load(scene_path)
	var inst := packed.instantiate()
	root.add_child(inst)
	current_scene = inst
	if hook != "":
		await process_frame
		await process_frame
		var h: GDScript = load(hook)
		h.new().run(self, inst)
	await create_timer(wait).timeout
	await RenderingServer.frame_post_draw
	var img := root.get_texture().get_image()
	img.save_png(out)
	print("saved ", out, " ", img.get_size())
	quit()
