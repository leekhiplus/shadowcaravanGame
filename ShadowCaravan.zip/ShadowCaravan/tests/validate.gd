extends SceneTree
## Static project validation. Run headless:
##   godot --headless --path . -s tests/validate.gd
## Checks: every .gd compiles, every .tscn loads and instantiates, every res:// path referenced by
## scenes and scripts exists, every audio file loads, and every button in each UI screen has an action.
## Exit code 0 = pass, 1 = failures.

var failures: Array[String] = []
var checked := 0


func _initialize() -> void:
	await process_frame
	_check_scripts("res://")
	_check_scenes("res://scenes")
	_check_audio()
	await _check_buttons()
	print("")
	print("validated %d items, %d failure(s)" % [checked, failures.size()])
	for f in failures:
		print("  FAIL: ", f)
	quit(0 if failures.is_empty() else 1)


func _files(dir: String, ext: String, out: Array) -> void:
	var d := DirAccess.open(dir)
	if d == null:
		return
	d.list_dir_begin()
	var n := d.get_next()
	while n != "":
		if n.begins_with(".") or n == "build" or n == "tests" or n == "tools":
			n = d.get_next()
			continue
		var p := dir.path_join(n)
		if d.current_is_dir():
			_files(p, ext, out)
		elif n.ends_with(ext):
			out.append(p)
		n = d.get_next()
	d.list_dir_end()


func _check_scripts(root: String) -> void:
	var files: Array = []
	_files(root, ".gd", files)
	files.sort()
	var path_re := RegEx.new()
	path_re.compile("\"(res://[^\"]+)\"")
	for f in files:
		checked += 1
		var s: Variant = load(f)
		if s == null or not (s is GDScript) or not (s as GDScript).can_instantiate():
			failures.append("script does not compile: " + f)
			continue
		# every res:// literal in the script must resolve
		var text := FileAccess.get_file_as_string(f)
		for m in path_re.search_all(text):
			var rp: String = m.get_string(1)
			if rp.contains("%") or rp.ends_with("/") or rp.ends_with("_"):
				continue
			if not ResourceLoader.exists(rp) and not FileAccess.file_exists(rp):
				failures.append("%s references missing path %s" % [f, rp])


func _check_scenes(dir: String) -> void:
	var files: Array = []
	_files(dir, ".tscn", files)
	for f in files:
		checked += 1
		var ps: Variant = load(f)
		if ps == null or not (ps is PackedScene):
			failures.append("scene does not load: " + f)
			continue
		var inst: Node = (ps as PackedScene).instantiate()
		if inst == null:
			failures.append("scene does not instantiate: " + f)
		else:
			inst.free()


func _check_audio() -> void:
	var files: Array = []
	_files("res://assets/audio", ".wav", files)
	for f in files:
		checked += 1
		if not (load(f) is AudioStream):
			failures.append("audio does not load: " + f)
	for needed in ["ui_click", "sword_swing", "hit_enemy", "coin", "relic", "gate_rumble", "ambience", "music_world", "music_menu", "music_boss", "quest_done"]:
		if not ResourceLoader.exists("res://assets/audio/%s.wav" % needed):
			failures.append("missing required audio: " + needed)


func _walk_buttons(n: Node, out: Array) -> void:
	if n is BaseButton:
		out.append(n)
	for c in n.get_children():
		_walk_buttons(c, out)


func _has_action(b: BaseButton) -> bool:
	for sig_name in ["pressed", "toggled"]:
		for c in b.get_signal_connection_list(sig_name):
			var o: Object = c.callable.get_object()
			if o != null and o != root.get_node_or_null("AudioMgr"):  # the global click-sound hook does not count
				return true
	return false


func _check_buttons() -> void:
	# main menu, intro and (if present) every panel that can be built stand-alone
	for scene_path in ["res://scenes/main_menu.tscn", "res://scenes/intro.tscn"]:
		var inst: Node = (load(scene_path) as PackedScene).instantiate()
		root.add_child(inst)
		await process_frame
		await process_frame
		var btns: Array = []
		_walk_buttons(inst, btns)
		for b in btns:
			checked += 1
			if not _has_action(b):
				failures.append("%s: button '%s' has no action" % [scene_path, b.text])
		inst.queue_free()
		await process_frame
