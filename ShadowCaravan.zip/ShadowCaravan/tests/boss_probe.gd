extends SceneTree
## Diagnostic: drops a (invulnerable) player in the boss arena and logs what the Warden does.
##   godot --headless --path . -s tests/boss_probe.gd

const Terrain := preload("res://scripts/world/terrain.gd")


func _initialize() -> void:
	_run()


func _run() -> void:
	seed(777)
	var GS: Variant = root.get_node("GameState")
	GS.save_path = "user://probe_save.json"
	GS.delete_save()
	GS.new_game()
	var game: Variant = (load("res://scenes/game.tscn") as PackedScene).instantiate()
	root.add_child(game)
	current_scene = game
	for i in 5:
		await physics_frame
	var P: Node3D = game.player
	var B: Node3D = game.boss
	print("boss start state: ", B.state_name(), " at ", B.global_position)
	P.respawn(Vector3(0, Terrain.height_at(0, -64) + 0.3, -64))
	var hits: Array = [0]
	P.damaged.connect(func(_a: float) -> void: hits[0] += 1)
	var last := ""
	var attacks := {}
	var tele := false
	var t := 0.0
	for i in 3600:
		await physics_frame
		GS.hp = 99999.0
		t += 1.0 / 60.0
		var st: String = B.state_name()
		var key := "%s/%s" % [st, B._atk]
		if B._atk != "":
			attacks[B._atk] = attacks.get(B._atk, 0) + 1
		if B._tele != null:
			tele = true
		if key != last:
			last = key
			print("t=%.1f %s dist=%.1f bosspos=(%.1f,%.1f) player=(%.1f,%.1f) dmg=%d" % [t, key, B._dist, B.global_position.x, B.global_position.z, P.global_position.x, P.global_position.z, hits[0]])
	print("attacks: ", attacks, " tele=", tele, " dmg events=", hits[0])
	quit()
